extends Node2D
## 红衣纸人（小满）。没有眼睛，靠声音找人。

var world: Node
var state := "idle"   # idle / wander / investigate / search / chase / stand / follow
var path := PackedVector2Array()
var speed := 20.0
var timer := 0.0
var eyes := false
var aggression := 0.3   # 游荡时往玩家附近走的概率
var sprite: Sprite2D
var _bob := 0.0
var _last_bob_sign := 1.0
var _repath := 0.0
var _lost := 0.0
var _rustle := 2.0
var _alert_cool := 0.0
var _home := Vector2.ZERO

func _ready() -> void:
	sprite = Sprite2D.new()
	sprite.texture = Art.tex("girl")
	sprite.centered = false
	sprite.offset = Vector2(-8, -24)
	add_child(sprite)

func set_eyes(v: bool) -> void:
	eyes = v
	sprite.texture = Art.tex("girl_eyes" if v else "girl")

func set_state(s: String) -> void:
	state = s
	timer = 0.0
	path = PackedVector2Array()
	match s:
		"wander": speed = 20.0
		"investigate": speed = 36.0
		"search": speed = 16.0
		"chase": speed = 53.0
		"follow": speed = 48.0
		_: speed = 0.0

func hear(pos: Vector2, radius: float, kind: String) -> void:
	if state in ["idle", "stand", "follow"]:
		return
	var d := global_position.distance_to(pos)
	if d > radius:
		return
	var p: PlayerChar = world.player
	if kind == "step" and d < 64.0 and not p.is_hidden:
		_start_chase()
	elif state != "chase":
		if state != "investigate" and _alert_cool <= 0.0:
			Sfx.play_at("paper_rustle", global_position, -6.0, 0.8)
			_alert_cool = 4.0
		set_state("investigate")
		_go(pos)

func _start_chase() -> void:
	if state != "chase":
		world.on_girl_chase()
		set_state("chase")
	_lost = 0.0

func _go(pos: Vector2) -> void:
	path = world.find_path(global_position, pos)

func _physics_process(delta: float) -> void:
	if Game.frozen > 0 or state == "idle":
		return
	_alert_cool -= delta
	var p: PlayerChar = world.player
	var dp := global_position.distance_to(p.global_position)
	timer += delta
	match state:
		"stand":
			sprite.position.x = sin(Time.get_ticks_msec() * 0.0013) * 0.5
			return
		"wander":
			if path.is_empty():
				if timer > 1.5:
					_go(world.girl_wander_target(aggression))
					timer = 0.0
		"investigate":
			if path.is_empty():
				set_state("search")
		"search":
			if path.is_empty() and timer < 4.0:
				# 原地转圈"听"
				_rustle -= delta
				if _rustle <= 0.0:
					_rustle = 1.4
					Sfx.play_at("paper_rustle", global_position, -10.0, randf_range(0.8, 1.1))
			if timer > 4.5:
				set_state("wander")
		"chase":
			_repath -= delta
			if _repath <= 0.0:
				_repath = 0.35
				if p.is_hidden:
					_lost += 1.0
					if _lost > 1.0:
						set_state("search")
						_go(p.global_position)
						return
				elif p.mode == "sneak" and dp > 40.0:
					_lost += 0.35
				elif not p.moving and dp > 48.0:
					_lost += 0.25
				else:
					_lost = maxf(0.0, _lost - 0.2)
				if _lost > 2.6:
					set_state("search")
					_go(p.global_position)
					return
				_go(p.global_position)
		"follow":
			if dp > 22.0:
				_repath -= delta
				if _repath <= 0.0:
					_repath = 0.4
					_go(p.global_position)
			else:
				path = PackedVector2Array()
	# 近身感知
	if state in ["wander", "investigate", "search"] and not p.is_hidden and dp < 22.0 and p.moving and p.mode != "sneak":
		_start_chase()
	_move(delta)
	# 抓住
	if state in ["chase", "investigate", "wander", "search"] and not p.is_hidden and dp < 11.0 and not eyes:
		world.player_caught("girl")

func _move(delta: float) -> void:
	if path.is_empty() or speed <= 0.0:
		sprite.position.y = lerpf(sprite.position.y, 0.0, 0.3)
		return
	var tgt := path[0]
	world.girl_touch_door(tgt)
	var d := global_position.distance_to(tgt)
	var step := speed * delta
	if d <= step:
		global_position = tgt
		path.remove_at(0)
	else:
		global_position += (tgt - global_position) / d * step
	# 一跳一跳
	_bob += delta * (5.0 + speed * 0.08)
	var s := sin(_bob)
	sprite.position.y = -absf(s) * (2.0 if state == "chase" else 1.5)
	if sign(s) != _last_bob_sign:
		_last_bob_sign = sign(s)
		Sfx.play_at("step_paper", global_position, -16.0 if state != "chase" else -9.0, randf_range(0.85, 1.15))
	if state == "chase":
		sprite.position.x = randf_range(-0.6, 0.6)
	else:
		sprite.position.x = 0.0
