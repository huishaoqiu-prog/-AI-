// 极简静态文件服务器，只用于本地测试网页版：node serve_web.js <目录> <端口>
const http = require("http");
const fs = require("fs");
const path = require("path");
const root = path.resolve(process.argv[2] || "../_build/web");
const port = Number(process.env.PORT || process.argv[3] || 8765);
const mime = { ".html": "text/html; charset=utf-8", ".js": "application/javascript", ".wasm": "application/wasm",
	".pck": "application/octet-stream", ".png": "image/png", ".txt": "text/plain; charset=utf-8" };
http.createServer((req, res) => {
	let p = decodeURIComponent(new URL(req.url, "http://x").pathname);
	if (p === "/") p = "/index.html";
	const file = path.join(root, p);
	if (!file.startsWith(root)) { res.writeHead(403); return res.end(); }
	fs.readFile(file, (err, data) => {
		if (err) { res.writeHead(404); return res.end(); }
		res.writeHead(200, { "Content-Type": mime[path.extname(file).toLowerCase()] || "application/octet-stream" });
		res.end(data);
	});
}).listen(port, () => console.log(`Serving ${root} on http://localhost:${port}/`));
