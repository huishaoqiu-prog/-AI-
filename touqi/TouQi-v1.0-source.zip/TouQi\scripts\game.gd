extends Node
## 全局状态：章节、旗标、物品、灯油、存档点、结局记录

signal changed

const CHAPTERS := [
	{"name": "戌时", "title": "守灵", "clock": "20:00"},
	{"name": "亥时", "title": "纸扎", "clock": "22:00"},
	{"name": "子时", "title": "叫魂", "clock": "00:00"},
	{"name": "丑时", "title": "镜中", "clock": "01:00"},
	{"name": "寅时", "title": "旧事", "clock": "03:00"},
	{"name": "卯时", "title": "点睛", "clock": "05:00"},
]

const ITEM_NAMES := {
	"oil": "灯油",
	"key_east": "东厢钥匙",
	"brush": "小满的毛笔",
	"cinnabar": "朱砂",
	"photo": "旧照片",
	"rules": "奶奶的规矩",
}

const ENDINGS := {
	"true": {"name": "长明", "desc": "你点亮了她的眼睛，也点亮了回家的路。"},
	"substitute": {"name": "替身", "desc": "它带走了一个林默。镜子里站着另一个。"},
	"paper": {"name": "纸衣", "desc": "你守住了每一条规矩，也守住了它想要的一切。"},
}

const SAVE_PATH := "user://touqi_save.cfg"

# ---- 运行时状态
var chapter := 0
var flags := {}
var items := {}          # id -> count
var docs: Array = []     # 读过的文件 id（日记等），可在笔记里重看
var lamp := 100.0        # 手里油灯
var eternal := 100.0     # 长明灯
var player_pos := Vector2.ZERO
var deaths := 0
var playtime := 0.0
var torn_rule := -1      # 撕掉的规矩序号

var act_block := -10
var frozen := 0          # >0 时玩家/敌人停止（对话、过场）
var checkpoint := {}
var endings_seen := {}
var autotest := false
var settings := {"fullscreen": false, "volume": 0.8}

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_input()
	_load_persistent()
	var th := Theme.new()
	th.default_font = load("res://fonts/fusion12.woff2")
	th.default_font_size = 12
	get_tree().root.theme = th
	autotest = "--autotest" in OS.get_cmdline_user_args()
	AudioServer.set_bus_volume_db(0, linear_to_db(settings.volume))

func _process(delta: float) -> void:
	if frozen == 0 and not get_tree().paused:
		playtime += delta

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("fullscreen"):
		settings.fullscreen = not settings.fullscreen
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if settings.fullscreen else DisplayServer.WINDOW_MODE_WINDOWED)
		_save_persistent()

# ---------------------------------------------------------------- 输入
func _setup_input() -> void:
	var map := {
		"up": [KEY_W, KEY_UP],
		"down": [KEY_S, KEY_DOWN],
		"left": [KEY_A, KEY_LEFT],
		"right": [KEY_D, KEY_RIGHT],
		"run": [KEY_SHIFT],
		"sneak": [KEY_CTRL, KEY_C],
		"act": [KEY_E, KEY_SPACE, KEY_ENTER, KEY_KP_ENTER],
		"refill": [KEY_Q],
		"rules": [KEY_R],
		"notes": [KEY_TAB],
		"pause": [KEY_ESCAPE],
		"fullscreen": [KEY_F11],
	}
	for a in map:
		if not InputMap.has_action(a):
			InputMap.add_action(a)
		for k in map[a]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(a, ev)
	# 手柄
	var pad := {"act": JOY_BUTTON_A, "pause": JOY_BUTTON_START, "refill": JOY_BUTTON_X, "rules": JOY_BUTTON_Y, "notes": JOY_BUTTON_BACK, "run": JOY_BUTTON_RIGHT_SHOULDER, "sneak": JOY_BUTTON_LEFT_SHOULDER,
		"up": JOY_BUTTON_DPAD_UP, "down": JOY_BUTTON_DPAD_DOWN, "left": JOY_BUTTON_DPAD_LEFT, "right": JOY_BUTTON_DPAD_RIGHT}
	for a in pad:
		var jb := InputEventJoypadButton.new()
		jb.button_index = pad[a]
		InputMap.action_add_event(a, jb)
	for ax in [["left", JOY_AXIS_LEFT_X, -1.0], ["right", JOY_AXIS_LEFT_X, 1.0], ["up", JOY_AXIS_LEFT_Y, -1.0], ["down", JOY_AXIS_LEFT_Y, 1.0]]:
		var jm := InputEventJoypadMotion.new()
		jm.axis = ax[1]
		jm.axis_value = ax[2]
		InputMap.action_add_event(ax[0], jm)

# ---------------------------------------------------------------- 状态
func new_game() -> void:
	chapter = 0
	flags = {}
	items = {}
	docs = []
	lamp = 100.0
	eternal = 70.0
	deaths = 0
	playtime = 0.0
	torn_rule = -1
	player_pos = Vector2.ZERO
	frozen = 0
	save_checkpoint()

func flag(k: String) -> bool:
	return bool(flags.get(k, false))

func setf(k: String, v: Variant = true) -> void:
	flags[k] = v
	changed.emit()

func has(id: String) -> bool:
	return int(items.get(id, 0)) > 0

func count(id: String) -> int:
	return int(items.get(id, 0))

func give(id: String, n: int = 1) -> void:
	items[id] = int(items.get(id, 0)) + n
	if int(items[id]) <= 0:
		items.erase(id)
	changed.emit()

func take(id: String, n: int = 1) -> void:
	give(id, -n)

func add_doc(id: String) -> void:
	if not id in docs:
		docs.append(id)
	changed.emit()

func save_checkpoint() -> void:
	checkpoint = {
		"chapter": chapter, "flags": flags.duplicate(true), "items": items.duplicate(true), "docs": docs.duplicate(),
		"lamp": maxf(lamp, 60.0), "eternal": maxf(eternal, 55.0), "player_pos": player_pos, "torn_rule": torn_rule,
	}
	_save_persistent()

func load_checkpoint() -> void:
	if checkpoint.is_empty():
		new_game()
		return
	chapter = checkpoint.chapter
	flags = checkpoint.flags.duplicate(true)
	items = checkpoint.items.duplicate(true)
	docs = checkpoint.docs.duplicate()
	lamp = checkpoint.lamp
	eternal = checkpoint.eternal
	player_pos = checkpoint.player_pos
	torn_rule = checkpoint.torn_rule
	frozen = 0

func has_save() -> bool:
	return not checkpoint.is_empty() and int(checkpoint.get("chapter", 0)) > 0

func see_ending(id: String) -> void:
	endings_seen[id] = true
	checkpoint = {}
	_save_persistent()

# ---------------------------------------------------------------- 持久化
func _save_persistent() -> void:
	var cf := ConfigFile.new()
	cf.set_value("meta", "endings", endings_seen)
	cf.set_value("meta", "settings", settings)
	cf.set_value("meta", "checkpoint", checkpoint)
	cf.set_value("meta", "deaths", deaths)
	cf.save(SAVE_PATH)

func _load_persistent() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) != OK:
		return
	endings_seen = cf.get_value("meta", "endings", {})
	settings.merge(cf.get_value("meta", "settings", {}), true)
	checkpoint = cf.get_value("meta", "checkpoint", {})
	if settings.fullscreen:
		DisplayServer.window_set_mode.call_deferred(DisplayServer.WINDOW_MODE_FULLSCREEN)

# ---------------------------------------------------------------- 场景
func goto(path: String) -> void:
	frozen = 0
	get_tree().paused = false
	get_tree().change_scene_to_file(path)

func start_world() -> void:
	goto("res://scenes/world.tscn")

func chapter_info() -> Dictionary:
	return CHAPTERS[clampi(chapter, 0, CHAPTERS.size() - 1)]
