extends CanvasLayer
## 所有界面：HUD、对话、选项、文件、规矩、密码锁、笔记、提示、过场、暂停、失败

signal _advance

var world: Node
var root: Control
var hud: Control
var clock_lbl: Label
var obj_lbl: Label
var prompt_lbl: Label
var room_lbl: Label
var toast_box: VBoxContainer
var dlg: PanelContainer
var dlg_name: Label
var dlg_text: RichTextLabel
var dlg_arrow: Label
var choice_box: VBoxContainer
var fade: ColorRect
var card: Control
var card_title: Label
var card_sub: Label
var caption_lbl: Label
var paper: TextureRect
var paper_title: Label
var paper_text: RichTextLabel
var paper_hint: Label
var scare: TextureRect
var hide_lbl: Label
var pause_panel: PanelContainer
var pause_list: VBoxContainer

var objective := ""
var busy := false
var _pause_idx := 0
var _pause_open := false

const INK := Color("2a1e18")
const PALE := Color("c8c2b4")
const RED := Color("c83a3a")

func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.draw.connect(_draw_hud)
	root.add_child(hud)

	clock_lbl = _label(Vector2(6, 3), PALE)
	obj_lbl = _label(Vector2(6, 19), Color("8e887c"))
	prompt_lbl = _label(Vector2.ZERO, Color("f0e8d0"))
	prompt_lbl.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	prompt_lbl.add_theme_constant_override("outline_size", 4)
	prompt_lbl.visible = false
	room_lbl = _label(Vector2(0, 36), Color("b8b0a0"))
	room_lbl.size = Vector2(480, 14)
	room_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	room_lbl.modulate.a = 0.0

	toast_box = VBoxContainer.new()
	toast_box.position = Vector2(4, 150)
	toast_box.size = Vector2(472, 48)
	toast_box.alignment = BoxContainer.ALIGNMENT_END
	toast_box.add_theme_constant_override("separation", 0)
	root.add_child(toast_box)

	hide_lbl = _label(Vector2(0, 238), Color("8e887c"))
	hide_lbl.size = Vector2(480, 14)
	hide_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hide_lbl.visible = false

	# 对话框
	dlg = PanelContainer.new()
	dlg.position = Vector2(10, 202)
	dlg.size = Vector2(460, 62)
	dlg.add_theme_stylebox_override("panel", _box(Color(0.04, 0.035, 0.05, 0.92), Color("5a4a40")))
	root.add_child(dlg)
	var dv := Control.new()
	dv.custom_minimum_size = Vector2(448, 52)
	dlg.add_child(dv)
	dlg_name = _label(Vector2(2, -2), Color("d8a860"), dv)
	dlg_text = RichTextLabel.new()
	dlg_text.bbcode_enabled = true
	dlg_text.position = Vector2(2, 12)
	dlg_text.size = Vector2(444, 42)
	dlg_text.scroll_active = false
	dlg_text.add_theme_color_override("default_color", Color("e0d8c8"))
	dlg_text.add_theme_constant_override("line_separation", 2)
	dv.add_child(dlg_text)
	dlg_arrow = _label(Vector2(438, 40), Color("d8a860"), dv)
	dlg_arrow.text = "▼"
	dlg.visible = false

	choice_box = VBoxContainer.new()
	choice_box.position = Vector2(150, 120)
	choice_box.add_theme_constant_override("separation", 2)
	root.add_child(choice_box)

	# 文件
	paper = TextureRect.new()
	paper.texture = Art.tex("paper_bg")
	paper.position = Vector2(80, 26)
	paper.visible = false
	root.add_child(paper)
	paper_title = _label(Vector2(0, 8), Color("6a1a14"), paper)
	paper_title.size = Vector2(320, 14)
	paper_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	paper_text = RichTextLabel.new()
	paper_text.bbcode_enabled = true
	paper_text.position = Vector2(18, 28)
	paper_text.size = Vector2(286, 168)
	paper_text.scroll_active = false
	paper_text.add_theme_color_override("default_color", INK)
	paper_text.add_theme_constant_override("line_separation", 3)
	paper.add_child(paper_text)
	paper_hint = _label(Vector2(0, 222), Color("8e887c"))
	paper_hint.size = Vector2(480, 14)
	paper_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	paper_hint.visible = false

	scare = TextureRect.new()
	scare.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	scare.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	scare.set_anchors_preset(Control.PRESET_FULL_RECT)
	scare.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	scare.visible = false
	root.add_child(scare)

	caption_lbl = _label(Vector2(0, 118), Color("e8e0d0"))
	caption_lbl.size = Vector2(480, 30)
	caption_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	caption_lbl.modulate.a = 0.0

	fade = ColorRect.new()
	fade.color = Color.BLACK
	fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(fade)

	card = Control.new()
	card.set_anchors_preset(Control.PRESET_FULL_RECT)
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.modulate.a = 0.0
	root.add_child(card)
	card_title = _label(Vector2(0, 100), Color("e8e0d0"), card)
	card_title.add_theme_font_size_override("font_size", 36)
	card_title.size = Vector2(480, 40)
	card_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	card_sub = _label(Vector2(0, 146), Color("a89a88"), card)
	card_sub.size = Vector2(480, 14)
	card_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	# 暂停
	pause_panel = PanelContainer.new()
	pause_panel.add_theme_stylebox_override("panel", _box(Color(0.03, 0.03, 0.04, 0.95), Color("5a4a40")))
	pause_panel.position = Vector2(150, 60)
	pause_panel.size = Vector2(180, 150)
	pause_panel.visible = false
	root.add_child(pause_panel)
	pause_list = VBoxContainer.new()
	pause_list.add_theme_constant_override("separation", 3)
	pause_panel.add_child(pause_list)

	Game.changed.connect(hud.queue_redraw)

func _label(pos: Vector2, color: Color, parent: Node = null) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_color_override("font_color", color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	(parent if parent else root).add_child(l)
	return l

func _box(bg: Color, border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(1)
	s.set_content_margin_all(5)
	return s

# ================================================================ HUD
func _process(delta: float) -> void:
	hud.queue_redraw()
	var info := Game.chapter_info()
	clock_lbl.text = "%s · %s" % [info.name, info.title]
	obj_lbl.text = objective
	hud.visible = not paper.visible and not world._dead
	clock_lbl.visible = hud.visible
	obj_lbl.visible = hud.visible
	dlg_arrow.visible = int(Time.get_ticks_msec() / 400) % 2 == 0
	if Input.is_action_just_pressed("pause") and not busy and not world._dead:
		_toggle_pause()
	elif _pause_open:
		_pause_input()
	elif Game.frozen == 0 and not busy and not world._dead and not get_tree().paused and Engine.get_process_frames() > Game.act_block:
		if Input.is_action_just_pressed("rules") and Game.has("rules"):
			show_rules(false)
		elif Input.is_action_just_pressed("notes"):
			show_notes()

func _draw_hud() -> void:
	if world == null or world._dead or paper.visible:
		return
	var x := 474.0
	# 长明灯
	_bar(Vector2(x - 60, 6), Game.eternal / 100.0, Color("e8a040") if Game.eternal > 25.0 or int(Time.get_ticks_msec() / 250) % 2 == 0 else Color("c83a3a"), "长明")
	_bar(Vector2(x - 60, 18), Game.lamp / 100.0, Color("d8c890"), "油灯")
	hud.draw_texture(Art.tex("i_oil"), Vector2(x - 26, 30))
	hud.draw_string(get_theme_font(), Vector2(x - 13, 40), "×%d" % Game.count("oil"), HORIZONTAL_ALIGNMENT_LEFT, -1, 12, PALE)
	# 关键物品
	var ix := 6.0
	for id in ["rules", "key_east", "brush", "cinnabar", "photo"]:
		if Game.has(id):
			var icon: String = {"rules": "i_note", "key_east": "i_key", "brush": "i_brush", "cinnabar": "i_cinnabar", "photo": "i_photo"}[id]
			hud.draw_texture(Art.tex(icon), Vector2(ix, 252))
			ix += 15
	if Game.has("rules"):
		hud.draw_string(get_theme_font(), Vector2(ix + 2, 263), "R 规矩  Tab 笔记  Q 添油", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("5e584e"))

func get_theme_font() -> Font:
	return ThemeDB.fallback_font if root.get_theme_default_font() == null else root.get_theme_default_font()

func _bar(pos: Vector2, v: float, c: Color, label: String) -> void:
	hud.draw_string(get_theme_font(), pos + Vector2(-26, 9), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("8e887c"))
	hud.draw_rect(Rect2(pos + Vector2(0, 3), Vector2(52, 5)), Color(0, 0, 0, 0.7))
	hud.draw_rect(Rect2(pos + Vector2(1, 4), Vector2(50 * clampf(v, 0, 1), 3)), c)

func set_prompt(o: Node2D) -> void:
	if o == null or busy or Game.frozen > 0:
		prompt_lbl.visible = false
		return
	prompt_lbl.visible = true
	var verb: String = o.verb
	if o.is_door and o.locked:
		verb = "查看"
	prompt_lbl.text = "E %s · %s" % [verb, o.label]
	var sp: Vector2 = world.get_viewport().get_canvas_transform() * (o.rect.get_center() + Vector2(0, -o.rect.size.y / 2.0 - 18))
	var w := prompt_lbl.get_minimum_size().x
	prompt_lbl.position = Vector2(clampf(sp.x - w / 2.0, 4, 476 - w), clampf(sp.y, 30, 186)).round()

func set_objective(t: String) -> void:
	objective = t

func room_name(t: String) -> void:
	room_lbl.text = t
	var tw := create_tween()
	tw.tween_property(room_lbl, "modulate:a", 1.0, 0.4)
	tw.tween_interval(1.4)
	tw.tween_property(room_lbl, "modulate:a", 0.0, 0.8)

func toast(t: String) -> void:
	var l := Label.new()
	l.text = t
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	l.add_theme_color_override("font_color", Color("d8c8a8"))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	l.add_theme_constant_override("outline_size", 3)
	toast_box.add_child(l)
	while toast_box.get_child_count() > 3:
		toast_box.get_child(0).free()
	var tw := l.create_tween()
	tw.tween_interval(2.6)
	tw.tween_property(l, "modulate:a", 0.0, 0.6)
	tw.tween_callback(l.queue_free)

func hide_overlay(on: bool, verb: String = "") -> void:
	hide_lbl.visible = on
	hide_lbl.text = ["（屏住呼吸……  E 出来）", "（我是衣柜，我是衣柜……  E 出来）", "（主打一个隐身。  E 出来）", "（别喘，别喘……  E 出来）"][randi() % 4]

# ================================================================ 等待按键
func _wait_act() -> void:
	if Game.autotest:
		await get_tree().create_timer(0.03).timeout
		return
	while true:
		await get_tree().process_frame
		if Input.is_action_just_pressed("act"):
			return

# ================================================================ 对话
## lines: 每行 "名字|内容" 或 "内容"（旁白），"（内容）" 为内心独白
func say(lines: Array) -> void:
	busy = true
	Game.frozen += 1
	prompt_lbl.visible = false
	dlg.visible = true
	for raw in lines:
		var s: String = raw
		var who := ""
		if "|" in s:
			who = s.get_slice("|", 0)
			s = s.substr(who.length() + 1)
		dlg_name.text = who
		if who == "":
			if s.begins_with("（"):
				s = "[color=#a8b8c8]" + s + "[/color]"
			else:
				s = "[color=#b8b0a0]" + s + "[/color]"
		dlg_text.text = s
		dlg_text.visible_characters = 0
		var total := dlg_text.get_total_character_count()
		var shown := 0.0
		while shown < total:
			await get_tree().process_frame
			if Game.autotest:
				shown = total
			shown += get_process_delta_time() * 38.0
			if Input.is_action_just_pressed("act"):
				shown = total
				await get_tree().process_frame
			var n := int(shown)
			if n != dlg_text.visible_characters and n % 2 == 0:
				Sfx.play("type_blip", -24.0, randf_range(0.95, 1.05))
			dlg_text.visible_characters = n
		dlg_text.visible_characters = -1
		await _wait_act()
		Sfx.play("ui_ok", -18.0)
	dlg.visible = false
	Game.frozen -= 1
	busy = false
	Game.act_block = Engine.get_process_frames()

func choose(question: String, options: Array) -> int:
	busy = true
	Game.frozen += 1
	prompt_lbl.visible = false
	if question != "":
		dlg.visible = true
		dlg_name.text = ""
		dlg_text.text = "[color=#b8b0a0]" + question + "[/color]"
		dlg_text.visible_characters = -1
	var idx := 0
	var labels: Array = []
	for o in options:
		var l := Label.new()
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
		l.add_theme_constant_override("outline_size", 4)
		choice_box.add_child(l)
		labels.append(l)
	var w := 0.0
	for k in options.size():
		labels[k].text = "▶ " + options[k]
		w = maxf(w, labels[k].get_minimum_size().x)
	choice_box.position = Vector2(240 - w / 2.0, 186 - options.size() * 16).round()
	var result := -1
	if Game.autotest:
		result = world.get_node("Bot").next_choice(question, options) if world.has_node("Bot") else 0
	while result < 0:
		for k in labels.size():
			labels[k].text = ("▶ " if k == idx else "   ") + options[k]
			labels[k].add_theme_color_override("font_color", Color("f0d090") if k == idx else Color("8e887c"))
		await get_tree().process_frame
		if Input.is_action_just_pressed("up"):
			idx = (idx - 1 + options.size()) % options.size()
			Sfx.play("ui_move", -14.0)
		elif Input.is_action_just_pressed("down"):
			idx = (idx + 1) % options.size()
			Sfx.play("ui_move", -14.0)
		elif Input.is_action_just_pressed("act"):
			result = idx
	Sfx.play("ui_ok", -12.0)
	for l in labels:
		l.queue_free()
	dlg.visible = false
	Game.frozen -= 1
	busy = false
	Game.act_block = Engine.get_process_frames()
	return result

# ================================================================ 文件
## text 里用 "<pg>" 分页
func show_doc(title: String, text: String, title_color: Color = Color("6a1a14")) -> void:
	busy = true
	Game.frozen += 1
	prompt_lbl.visible = false
	Sfx.play("paper_page", -6.0)
	paper.visible = true
	paper_hint.visible = true
	paper_title.text = title
	paper_title.add_theme_color_override("font_color", title_color)
	var pages := text.split("<pg>")
	for i in pages.size():
		paper_text.text = pages[i].strip_edges()
		paper_hint.text = "E 继续（%d/%d）" % [i + 1, pages.size()] if pages.size() > 1 else "E 合上"
		await _wait_act()
		if i < pages.size() - 1:
			Sfx.play("paper_page", -8.0)
	paper.visible = false
	paper_hint.visible = false
	Game.frozen -= 1
	busy = false
	Game.act_block = Engine.get_process_frames()

## 规矩。tear=true 时可选择撕掉一条，返回序号（-1 为取消）
func show_rules(tear: bool) -> int:
	busy = true
	Game.frozen += 1
	prompt_lbl.visible = false
	Sfx.play("paper_page", -6.0)
	paper.visible = true
	paper_hint.visible = true
	paper_title.text = "规　矩"
	paper_title.add_theme_color_override("font_color", Color("6a1a14"))
	var rules: Array = world.story.RULES
	var idx := 0
	var result := -2
	var can_tear: bool = tear or world.story.can_tear()
	if Game.autotest:
		await get_tree().create_timer(0.05).timeout
		result = (world.get_node("Bot").next_tear() if world.has_node("Bot") else -1) if can_tear else -1
	while result == -2:
		var t := "[color=#4a3a30]默儿：今夜守灵，照着做，莫问为什么。[/color]\n\n"
		for k in rules.size():
			var line: String = rules[k]
			if k == Game.torn_rule:
				line = "[color=#9a8a78]（这一条已经被撕掉了）[/color]"
			elif can_tear and k == idx:
				line = "[color=#8a1a14]▶ " + line + "[/color]"
			else:
				line = "   " + line
			t += line + "\n"
		t += "\n[right][color=#4a3a30]——奶奶[/color][/right]"
		paper_text.text = t
		paper_hint.text = ("↑↓ 选择  E 撕掉这一条  R 收起" if can_tear else "E 收起")
		await get_tree().process_frame
		if can_tear:
			if Input.is_action_just_pressed("up"):
				idx = (idx - 1 + rules.size()) % rules.size()
				Sfx.play("ui_move", -14.0)
			elif Input.is_action_just_pressed("down"):
				idx = (idx + 1) % rules.size()
				Sfx.play("ui_move", -14.0)
			elif Input.is_action_just_pressed("act") and idx != Game.torn_rule:
				result = idx
			elif Input.is_action_just_pressed("rules") or Input.is_action_just_pressed("pause"):
				result = -1
		elif Input.is_action_just_pressed("act") or Input.is_action_just_pressed("rules"):
			result = -1
	paper.visible = false
	paper_hint.visible = false
	Game.frozen -= 1
	busy = false
	Game.act_block = Engine.get_process_frames()
	if result >= 0:
		await world.story.on_tear(result)
	return result

func show_notes() -> void:
	if Game.docs.is_empty():
		toast("还没有可以重看的东西")
		return
	busy = true
	Game.frozen += 1
	var docs: Array = world.story.DOCS
	var ids: Array = Game.docs
	var idx := 0
	paper.visible = true
	paper_hint.visible = true
	paper_title.text = "笔　记"
	var chosen := -1
	while true:
		var t := ""
		for k in ids.size():
			var title: String = docs[ids[k]].title
			t += ("[color=#8a1a14]▶ " + title + "[/color]" if k == idx else "   " + title) + "\n"
		paper_text.text = t
		paper_hint.text = "↑↓ 选择  E 阅读  Tab 收起"
		await get_tree().process_frame
		if Input.is_action_just_pressed("up"):
			idx = (idx - 1 + ids.size()) % ids.size()
			Sfx.play("ui_move", -14.0)
		elif Input.is_action_just_pressed("down"):
			idx = (idx + 1) % ids.size()
			Sfx.play("ui_move", -14.0)
		elif Input.is_action_just_pressed("act"):
			chosen = idx
			break
		elif Input.is_action_just_pressed("notes") or Input.is_action_just_pressed("pause"):
			break
	paper.visible = false
	paper_hint.visible = false
	Game.frozen -= 1
	busy = false
	Game.act_block = Engine.get_process_frames()
	if chosen >= 0:
		var d: Dictionary = docs[ids[chosen]]
		await show_doc(d.title, d.text)

## 四位密码锁，返回输入的字符串（取消返回 ""）
func keypad(title: String) -> String:
	busy = true
	Game.frozen += 1
	prompt_lbl.visible = false
	var digits := [0, 0, 0, 0]
	var idx := 0
	paper.visible = true
	paper_hint.visible = true
	paper_title.text = title
	var res := ""
	if Game.autotest:
		res = world.get_node("Bot").next_code() if world.has_node("Bot") else ""
		paper.visible = false
		paper_hint.visible = false
		Game.frozen -= 1
		busy = false
		return res
	while true:
		var t := "\n\n\n[center]"
		for k in 4:
			var d := str(digits[k])
			t += ("[color=#8a1a14][ %s ][/color]" % d) if k == idx else ("  %s  " % d)
		t += "[/center]\n\n[center][color=#6a5a4a]一把老铜锁，转轮上刻着数字。[/color][/center]"
		paper_text.text = t
		paper_hint.text = "←→ 选位  ↑↓ 拨动  E 确定  Esc 放弃"
		await get_tree().process_frame
		if Input.is_action_just_pressed("left"):
			idx = (idx + 3) % 4
			Sfx.play("ui_move", -14.0)
		elif Input.is_action_just_pressed("right"):
			idx = (idx + 1) % 4
			Sfx.play("ui_move", -14.0)
		elif Input.is_action_just_pressed("up"):
			digits[idx] = (digits[idx] + 1) % 10
			Sfx.play("door_locked", -18.0, 2.0)
		elif Input.is_action_just_pressed("down"):
			digits[idx] = (digits[idx] + 9) % 10
			Sfx.play("door_locked", -18.0, 2.0)
		elif Input.is_action_just_pressed("act"):
			res = "%d%d%d%d" % digits
			break
		elif Input.is_action_just_pressed("pause"):
			break
	paper.visible = false
	paper_hint.visible = false
	Game.frozen -= 1
	busy = false
	Game.act_block = Engine.get_process_frames()
	return res

# ================================================================ 过场
func fade_to(a: float, t: float = 0.6) -> void:
	var tw := create_tween()
	tw.tween_property(fade, "color:a", a, t)
	await tw.finished

func show_card(title: String, sub: String, hold: float = 2.2) -> void:
	card_title.text = title
	card_sub.text = sub
	var tw := create_tween()
	tw.tween_property(card, "modulate:a", 1.0, 0.8)
	tw.tween_interval(hold if not Game.autotest else 0.2)
	tw.tween_property(card, "modulate:a", 0.0, 0.8)
	await tw.finished

func caption(text: String, hold: float = 2.0, color: Color = Color("e8e0d0")) -> void:
	caption_lbl.text = text
	caption_lbl.add_theme_color_override("font_color", color)
	var tw := create_tween()
	tw.tween_property(caption_lbl, "modulate:a", 1.0, 0.3)
	tw.tween_interval(hold if not Game.autotest else 0.1)
	tw.tween_property(caption_lbl, "modulate:a", 0.0, 0.6)
	await tw.finished

func jumpscare(art: String, dur: float = 0.9) -> void:
	scare.texture = Art.tex(art)
	scare.visible = true
	scare.modulate = Color(1.3, 1.0, 1.0)
	world.do_shake(1.5)
	world.do_flash(0.8)
	Sfx.play("sting", 0.0)
	var tw := create_tween()
	scare.scale = Vector2(0.85, 0.85)
	scare.pivot_offset = Vector2(240, 135)
	tw.tween_property(scare, "scale", Vector2(1.15, 1.15), dur).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	await tw.finished
	scare.visible = false

func game_over(title: String, text: String) -> void:
	busy = true
	await fade_to(1.0, 0.4)
	card_title.text = title
	card_title.add_theme_color_override("font_color", RED)
	card_sub.text = text
	var tw := create_tween()
	tw.tween_property(card, "modulate:a", 1.0, 1.0)
	await tw.finished
	var hint := _label(Vector2(0, 200), Color("6e685e"))
	hint.size = Vector2(480, 14)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.text = "E 从本时辰重来　　Esc 回到标题"
	if Game.autotest:
		await get_tree().create_timer(0.3).timeout
		world.retry()
		return
	while true:
		await get_tree().process_frame
		if Input.is_action_just_pressed("act"):
			Sfx.play("ui_ok")
			world.retry()
			return
		if Input.is_action_just_pressed("pause"):
			Sfx.stop_all_loops()
			Game.goto("res://scenes/title.tscn")
			return

# ================================================================ 暂停
func _toggle_pause() -> void:
	_pause_open = not _pause_open
	get_tree().paused = _pause_open
	pause_panel.visible = _pause_open
	_pause_idx = 0
	Sfx.play("ui_back" if not _pause_open else "ui_ok", -10.0)
	_render_pause()

func _pause_items() -> Array:
	return ["继续", "全屏：%s" % ("开" if Game.settings.fullscreen else "关"), "音量：%d%%" % int(Game.settings.volume * 100), "回到标题"]

func _render_pause() -> void:
	for c in pause_list.get_children():
		c.queue_free()
	var head := Label.new()
	head.text = "—— 暂停 ——"
	head.add_theme_color_override("font_color", Color("8e887c"))
	head.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pause_list.add_child(head)
	var items := _pause_items()
	for k in items.size():
		var l := Label.new()
		l.text = ("▶ " if k == _pause_idx else "   ") + items[k]
		l.add_theme_color_override("font_color", Color("f0d090") if k == _pause_idx else PALE)
		pause_list.add_child(l)
	var help := Label.new()
	help.text = "\nWASD 移动　Shift 跑\nCtrl 潜行　E 调查\nQ 添油　R 规矩　Tab 笔记\n（暂停只对你有效，对它无效）"
	help.add_theme_color_override("font_color", Color("6e685e"))
	pause_list.add_child(help)

func _pause_input() -> void:
	var n := _pause_items().size()
	if Input.is_action_just_pressed("up"):
		_pause_idx = (_pause_idx - 1 + n) % n
	elif Input.is_action_just_pressed("down"):
		_pause_idx = (_pause_idx + 1) % n
	elif Input.is_action_just_pressed("act") or Input.is_action_just_pressed("left") or Input.is_action_just_pressed("right"):
		match _pause_idx:
			0:
				if Input.is_action_just_pressed("act"):
					_toggle_pause()
					return
			1:
				Game.settings.fullscreen = not Game.settings.fullscreen
				DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if Game.settings.fullscreen else DisplayServer.WINDOW_MODE_WINDOWED)
			2:
				var dv := -0.1 if Input.is_action_just_pressed("left") else 0.1
				Game.settings.volume = wrapf(snappedf(Game.settings.volume + dv, 0.1), 0.0, 1.01)
				AudioServer.set_bus_volume_db(0, linear_to_db(maxf(Game.settings.volume, 0.001)))
			3:
				if Input.is_action_just_pressed("act"):
					Game.save_checkpoint()
					Sfx.stop_all_loops()
					Game.goto("res://scenes/title.tscn")
					return
		Game._save_persistent()
	else:
		return
	Sfx.play("ui_move", -12.0)
	_render_pause()
