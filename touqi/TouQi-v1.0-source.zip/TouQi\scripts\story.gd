extends Node
## 剧情与事件。所有文本、章节推进、互动逻辑都在这里。

var world: Node

const RULES := [
	"一、长明灯不能灭。灯在，她就认得回家的路。",
	"二、夜里有人叫你的名字，不要应。",
	"三、子时以后，不要照镜子。",
	"四、纸人的眼睛，不能点。",
	"五、鸡叫以前，不要开后门。",
]
const FAKE_RULE := 3
const CODE := "1208"

var DOCS := {
	"diary1": {"title": "奶奶的日记（一）", "text": """腊月廿三　阴

身子一天不如一天了。
默儿在城里，三年没回来。也好，离这院子远些好。
他上回打电话说，城里都在「内卷」。我问老三啥叫内卷，老三说，就是大家都不睡觉。

满儿的纸衣今年还没换。红纸是托人从镇上捎的，颜色不正，她怕是要嫌。
<pg>
腊月廿六

夜里又听见后门有人叫。
我没应。二十年了，我一回也没应过。

它还在等。
等我走。"""},
	"diary2": {"title": "奶奶的日记（二）", "text": """（字迹很乱，像是躺在床上写的）

给默儿写了规矩，压在枕头底下，等老三交给他。
就四条。四不吉利，可多一条，我也想不出来了。

[color=#8a1a14]灯不能灭，名不能应，镜不能照，鸡叫前后门不能开。[/color]

记住了，就这四条。
<pg>
满儿生在腊月初八，喝腊八粥那天。
祠堂那把锁，我用她的生日锁的。
她九岁那年的腊八粥，一口也没喝上。"""},
	"diary3": {"title": "奶奶的日记（三）", "text": """二十年前，老头子头七那夜，默儿应了门外的一声。
它要讨个替身，记下的是默儿的名字。

我连夜扎了个纸人，要在纸人身上写默儿的名，让它把纸人领走。

第二天一早，纸人身上写的是……满儿的名字。
<pg>
满儿把弟弟的名字划了，写上了自己的。
她才九岁，字还写不周正。

它领走了满儿。我拼了老命，把她的魂扣在那个纸人里，没让它带出这个院子。
纸人没点眼睛，走不了，也看不见。

我对不住她。
<pg>
我手指上的朱砂，洗不掉了。
这些年，我几回拿起笔，又放下。

点了睛，纸人就活了。她能看见，也就能走了。

我舍不得。"""},
	"xiaoman": {"title": "压在枕头下的字条", "text": """（铅笔写的，字歪歪扭扭，有好几个错字）

弟弟：

奶奶说，纸人身上要写名字，它才肯走。
我把你的名字划掉了，写了我的。

我是姐姐，我不怕。

你别哭。
等我回来，给你带镇上的糖。

　　　　　　　　　　　　　　——满"""},
	"photo": {"title": "旧照片", "text": """一张发黄的黑白照片。

一个扎两个小髻的女孩，牵着一个比她矮一头的男孩。
女孩笑得眯起了眼，男孩手里攥着一根糖葫芦。

背面用钢笔写着：
[color=#4a3a30]满九岁，默六岁。腊月初七，摄于镇上。[/color]

（第二天，就是她的生日。）"""},
	"last": {"title": "压在供桌上的信", "text": """默儿：

你要是看见这张纸，奶奶已经走了。

那东西会穿着我的衣裳，用我的声音叫你。别认它。

我给你扎了一个替身，就站在这儿，写着你的名。
还差一双眼睛。朱砂在牌位跟前。
给它点了睛，它就替你去。
<pg>
……还有满儿。

她在院里站了二十年。
奶奶没本事，送不走她，也舍不得她走。

你自己拿主意吧。

　　　　　　　　　　　　　　——奶奶"""},
	"drawing": {"title": "墙上的蜡笔画", "text": """一张蜡笔画，用图钉钉在墙上。

一个穿红衣服的小女孩，牵着一个小男孩。
旁边写着：[color=#8a1a14]我和弟弟[/color]

小女孩的脸上，没有画眼睛。

纸的背面还有一行字，被橡皮擦过，看不太清：
[color=#7a6a5a]奶奶说纸人不能点眼睛，点了就会走[/color]"""},
}

var _t := 0.0
var _scare_t := 40.0
var _rooster := 210.0
var _girl_seen_t := -1.0
var _musicbox_t := 0.0
var uncle: Sprite2D
var girl_proxy: Node2D
var _sister_hold := false

# ================================================================ 搭建
func setup() -> void:
	var ch := Game.chapter
	# 门
	if Game.flag("east_open"):
		world.set_door_locked("door_east", false)
		world.open_door("door_east", true)
	if Game.flag("west_open"):
		world.set_door_locked("door_west", false)
		world.open_door("door_west", true)
	else:
		var s: Sprite2D = world.decal("seal", world.objs["door_west"].global_position + Vector2(0, -9), "seal")
		s.z_index = 1
	if Game.flag("shrine_open"):
		world.set_door_locked("door_shrine", false)
		world.open_door("door_shrine", true)
	if Game.flag("backgate_open"):
		world.open_door("backgate", true)
	spawn_items()
	if not Game.has("brush") and not Game.flag("took_brush"):
		var b: Node2D = world.add("brush_obj", "brush", Vector2i(5, 9), {"solid": false, "dy": -7, "label": "毛笔", "verb": "拿起"})
		b.z_index = 1
		b.rotation = -1.2
	# 章节外观
	if ch >= 3:
		world.obj("portrait").set_art("portrait_turned")
		world.set_light("candle_l", false)
		world.set_light("candle_r", false)
	if ch >= 2 and ch <= 4:
		for k in 9:
			var p := Vector2(7 * 16 + 4 + k * 3, 5 * 16 + 6 + k * 10)
			if k > 3:
				p = Vector2(12 * 16 + 6 + (k % 2) * 6, 6 * 16 + (k - 3) * 18)
			var fp: Sprite2D = world.decal("footprint", p)
			fp.modulate.a = 0.8
	if ch == 5:
		world.obj("coffin").set_art("coffin_open")
	if ch >= 5 and Game.flag("dawn"):
		world.modulate_node.color = Color("4a4c5a")
	# 三叔
	if ch == 0 and not Game.flag("intro0"):
		uncle = Sprite2D.new()
		uncle.texture = Art.tex("uncle_sheet")
		uncle.hframes = 4
		uncle.vframes = 3
		uncle.frame = 4
		uncle.centered = false
		uncle.offset = Vector2(-8, -24)
		uncle.position = Vector2(22 * 16, 34 * 16 + 8)
		world.ysort.add_child(uncle)
	# 纸人
	_setup_girl()
	# 影子
	if ch == 5 and not Game.flag("shadow_dead") and Game.flag("intro5"):
		world.shadow.global_position = world.obj("coffin").global_position + Vector2(0, 6)
		world.shadow.activate()
	# 玩家初始位置
	if Game.player_pos == Vector2.ZERO:
		Game.player_pos = Vector2(22 * 16, 32 * 16)
	world.player.facing = Vector2.UP
	if ch == 5 and Game.flag("intro5"):
		_rooster = float(Game.flags.get("rooster", 210.0))
	refresh_objective()

func spawn_items() -> void:
	var ch := Game.chapter
	var jars := [["jar_shop", Vector2i(9, 32), 1], ["jar_back", Vector2i(24, 2), 2], ["jar_east", Vector2i(41, 16), 3],
		["jar_west", Vector2i(2, 15), 4], ["jar_shrine", Vector2i(31, 6), 4], ["jar_gate", Vector2i(19, 32), 2]]
	for j in jars:
		if ch >= j[2] and not Game.flag(j[0]) and world.obj(j[0]) == null:
			world.add(j[0], "jar", j[1], {"solid": false, "label": "灯油", "verb": "拿起"})
	if ch >= 4 and not Game.has("cinnabar") and not Game.flag("took_cinnabar") and world.obj("cinnabar") == null:
		var o: Node2D = world.add("cinnabar", "bowl_red", Vector2i(35, 2), {"solid": false, "label": "朱砂", "verb": "拿起"})
		o.z_index = 1

func _setup_girl() -> void:
	var g: Node2D = world.girl
	var ch := Game.chapter
	g.visible = false
	g.set_state("idle")
	if ch >= 2 and ch <= 4:
		g.visible = true
		g.aggression = [0, 0, 0.22, 0.32, 0.42][ch]
		# 出生在离玩家最远的房间
		var far := "shop"
		var best := 0.0
		for r in ["shop", "kitchen", "back", "yard", "gatehall"]:
			var c: Vector2 = world.tile_center((world.ROOMS[r] as Rect2i).get_center())
			var d := c.distance_to(Game.player_pos)
			if d > best:
				best = d
				far = r
		g.global_position = world.tile_center(world.random_open_tile_in(far))
		g.set_state("wander")
	elif ch == 5:
		g.visible = true
		if Game.flag("eyes"):
			g.set_eyes(true)
			g.global_position = Game.player_pos + Vector2(12, 4)
			g.set_state("follow")
		else:
			g.global_position = Vector2(10 * 16 + 8, 25 * 16 + 4)
			g.set_state("stand")
			girl_proxy = world.add("girl_proxy", "", Vector2i(10, 24), {"solid": false, "label": "红衣纸人", "verb": "靠近"})

func girl_rooms() -> Array:
	match Game.chapter:
		2: return ["yard", "shop", "kitchen", "gatehall", "alley", "back", "yard"]
		3: return ["yard", "shop", "kitchen", "hall", "back", "east", "yard", "alley"]
		_: return ["yard", "hall", "west", "east", "back", "kitchen", "shop", "yard", "alley"] if Game.flag("west_open") else ["yard", "hall", "east", "back", "kitchen", "shop", "yard", "alley"]

func can_tear() -> bool:
	return Game.flag("know_four") and Game.torn_rule != FAKE_RULE

# ================================================================ 目标
func refresh_objective() -> void:
	var t := ""
	match Game.chapter:
		0: t = "去堂屋，给长明灯添油"
		1:
			if not (Game.flag("v_kitchen") and Game.flag("v_shop") and Game.flag("saw_stand")):
				var left := []
				if not Game.flag("v_kitchen"):
					left.append("灶屋")
				if not Game.flag("v_shop") or not Game.flag("saw_stand"):
					left.append("扎纸铺")
				t = "四处看看：" + "、".join(left)
			else:
				t = "回灵堂，给长明灯添油"
		2:
			if not Game.flag("knocked"):
				t = "去院子里看看"
			elif not Game.has("key_east") and not Game.flag("east_open"):
				t = "找到东厢的钥匙"
			elif not Game.flag("east_open"):
				t = "打开东厢的门"
			else:
				t = "在奶奶屋里找找线索"
		3:
			if not Game.flag("know_four"):
				t = "读奶奶的日记（床、梳妆台）"
			else:
				t = "规矩里有一条是假的——按 R 撕掉它"
		4:
			if not Game.flag("west_open"):
				t = "去小满的屋子（西厢）"
			elif not (Game.flag("took_brush") and Game.flag("read_xiaoman")):
				t = "在小满的屋里找找（床、书桌）"
			elif not Game.flag("shrine_open"):
				t = "打开祠堂的锁（后院东边）"
			elif not (Game.has("cinnabar") and Game.has("brush")):
				t = "在祠堂里找朱砂" if not Game.has("cinnabar") else "去西厢找一支笔"
			else:
				t = "读祠堂供桌上的信"
		5:
			if Game.flag("dawn"):
				t = "打开后门，送她走"
			elif Game.flag("eyes"):
				t = "把灯油倒进长明灯！" if Game.has("oil") else "去灶屋舀油，倒进长明灯！"
			else:
				var s := int(_rooster)
				t = "点睛？小满（槐树下）/ 替身（祠堂）   鸡叫 %d:%02d" % [s / 60, s % 60]
	world.ui.set_objective(t)

# ================================================================ 开场
func begin() -> void:
	var ui = world.ui
	match Game.chapter:
		0:
			if not Game.flag("intro0"):
				await _intro0()
			else:
				await ui.fade_to(0.0, 1.0)
		1, 2, 3, 4, 5:
			var key := "intro%d" % Game.chapter
			if not Game.flag(key):
				await _chapter_intro()
			else:
				ui.fade_to(0.0, 1.0)
				var info := Game.chapter_info()
				await ui.show_card(info.name, info.title, 1.2)
	refresh_objective()

func _intro0() -> void:
	var ui = world.ui
	Game.frozen += 1
	ui.fade.color.a = 1.0
	Sfx.loop("music", "music_lullaby", -16.0, 2.0)
	await get_tree().create_timer(0.8).timeout
	await ui.caption("二〇〇三年，腊月。槐荫村。", 2.2)
	await ui.caption("奶奶走了七天。", 2.0)
	await ui.caption("按村里的老规矩，头七这一夜，要留一个孝孙守灵。", 2.8)
	await ui.show_card("头　七", "戌时 · 守灵", 1.8)
	Sfx.stop_loop("music", 3.0)
	await ui.fade_to(0.0, 1.5)
	Game.frozen -= 1
	await ui.say([
		"三叔|默儿，就送你到这儿了。",
		"三叔|你奶奶咽气前交代过，头七夜里，院子里只能留你一个。",
		"林默|三叔，这都什么年代了……",
		"三叔|你就当是加个班。守一夜，主打一个陪伴。",
		"三叔|（压低了声音）别问。照着做就是。",
		"三叔|这是你奶奶写的规矩，压在她枕头底下的。你收好。",
	])
	Game.give("rules")
	Sfx.play("paper_page")
	await ui.show_rules(false)
	await ui.say([
		"三叔|还有这罐灯油。长明灯一夜都不能灭，油不够就去灶屋，油缸里舀。",
	])
	Game.give("oil")
	ui.toast("获得：灯油 ×1")
	Sfx.play("pickup", -6.0)
	await ui.say([
		"三叔|天亮，鸡一叫，我就来开门。",
		"三叔|……默儿。",
		"三叔|不管谁叫你，都别应。",
	])
	# 三叔离开
	var tw := create_tween()
	tw.tween_property(uncle, "position", Vector2(22 * 16, 35 * 16 + 14), 1.2)
	tw.parallel().tween_property(uncle, "modulate:a", 0.0, 1.2)
	await tw.finished
	uncle.queue_free()
	Sfx.play("door_open", -4.0, 0.7)
	await get_tree().create_timer(0.7).timeout
	Sfx.play("door_locked", -2.0, 0.8)
	world.do_shake(0.4)
	await ui.say([
		"（「咔哒」一声。门从外面锁上了。）",
		"（院子里只剩下风声。）",
		"（……好家伙，直接锁门。）",
	])
	ui.toast("WASD 移动 · E 调查 · R 查看规矩")
	Game.setf("intro0")
	Game.save_checkpoint()

func _chapter_intro() -> void:
	var ui = world.ui
	var ch := Game.chapter
	Game.frozen += 1
	Sfx.play("bell_deep", -4.0)
	await ui.fade_to(1.0, 0.8)
	var info := Game.chapter_info()
	await ui.show_card(info.name, info.title, 1.8)
	await ui.fade_to(0.0, 1.2)
	Game.frozen -= 1
	match ch:
		1:
			await ui.say([
				"（远处传来打更的梆子声。亥时了。）",
				"（三叔说过，长明灯要一直添油。我得弄清楚这院子里都有些什么。）",
			])
		2:
			Sfx.stop_loop("amb3", 2.0)
			Sfx.loop("amb2", "amb_drone", -11.0, 3.0)
			await ui.say([
				"（虫子不叫了。）",
				"（院子里有什么在动——沙……沙……像是纸片擦着地面。）",
			])
			await ui.caption("她看不见你。但她听得见。", 2.4, Color("c8a0a0"))
			ui.toast("按住 Ctrl 潜行，几乎没有声音")
			ui.toast("Shift 跑步很快，但很吵")
			ui.toast("被追时，躲进衣柜、柴堆、供桌底下")
		3:
			await ui.say([
				"（堂屋那边的白蜡烛……灭了。）",
				"（只剩长明灯那一点火。）",
			])
		4:
			await ui.say([
				"（风停了。）",
				"（奶奶的日记里说，西厢封了二十年。小满的东西，都在那间屋里。）",
			])
		5:
			await _intro5()
	Game.setf("intro%d" % ch)
	Game.save_checkpoint()
	refresh_objective()

func next_chapter() -> void:
	Game.chapter += 1
	Game.save_checkpoint()
	spawn_items()
	if Game.chapter >= 2 and Game.chapter <= 4:
		_setup_girl()
	if Game.chapter == 3:
		world.obj("portrait").set_art("portrait_turned")
		world.set_light("candle_l", false)
		world.set_light("candle_r", false)
		Sfx.play("breath", -6.0)
	await _chapter_intro()

# ================================================================ 每帧
func tick(delta: float) -> void:
	_t += delta
	var ch := Game.chapter
	# 随机惊吓
	if ch >= 2 and ch <= 4:
		_scare_t -= delta
		if _scare_t <= 0.0:
			_scare_t = randf_range(35.0, 70.0)
			_random_scare()
	# 八音盒：纸人停下来听
	if _musicbox_t > 0.0:
		_musicbox_t -= delta
		var g: Node2D = world.girl
		var mb: Vector2 = world.obj("musicbox").global_position
		if g.global_position.distance_to(mb) < 40.0 and g.state != "stand":
			g.set_state("stand")
			world.ui.toast("她……在听")
		if _musicbox_t <= 0.0:
			Sfx.stop_loop("music", 2.0)
			if g.state == "stand":
				g.set_state("wander")
	# 第五章：鸡叫倒计时 / 小满拖住它
	if ch == 5 and Game.flag("intro5") and not Game.flag("dawn"):
		if not Game.flag("eyes"):
			_rooster -= delta
			Game.flags["rooster"] = _rooster
			if int(_rooster * 4.0) % 4 == 0:
				refresh_objective()
			if _rooster <= 0.0:
				_ending_paper()
		else:
			var g: Node2D = world.girl
			var s: Node2D = world.shadow
			var near := g.global_position.distance_to(s.global_position) < 48.0
			s.held_by_sister = near
			if near and not _sister_hold:
				world.ui.toast("小满拖住了它！")
				Sfx.play_at("paper_rustle", g.global_position, 0.0)
			_sister_hold = near

func _random_scare() -> void:
	var p: Vector2 = world.player.global_position
	var r := randi() % 5
	match r:
		0:
			Sfx.play_at("whisper", p + Vector2(randf_range(-40, 40), -30), -6.0)
		1:
			for k in 4:
				get_tree().create_timer(k * 0.45).timeout.connect(func(): Sfx.play_at("step_wood", p + Vector2(-60 + k * 30, -70), -6.0, 0.7))
		2:
			Sfx.play_at("knock", Vector2(22 * 16, 36 * 16), -6.0)
		3:
			for id in ["lantern1", "lantern2", "gate_lantern1", "gate_lantern2"]:
				world.set_light(id, false)
			get_tree().create_timer(1.6).timeout.connect(func():
				for id in ["lantern1", "lantern2", "gate_lantern1", "gate_lantern2"]:
					world.set_light(id, true))
			Sfx.play("breath", -8.0)
		4:
			Sfx.play_at("laugh", p + Vector2(randf_range(-80, 80), randf_range(-60, 60)), -10.0)

func on_tile(t: Vector2i, room: String) -> void:
	var ch := Game.chapter
	var ui = world.ui
	match ch:
		0:
			if room == "hall" and not Game.flag("hall_seen"):
				Game.setf("hall_seen")
				await ui.say([
					"（灵堂里点着两根白蜡烛。奶奶的遗像挂在正当中，黑框，白花。）",
					"（棺材横在堂屋中间。长明灯就在供桌上，火苗只剩黄豆那么大。）",
				])
		1:
			if room == "kitchen" and not Game.flag("v_kitchen"):
				Game.setf("v_kitchen")
				await ui.say(["（灶屋。灶膛里还有一点余火。）", "（油缸就在灶台边上。以后没油了，就来这儿舀。）"])
				refresh_objective()
			elif room == "shop" and not Game.flag("v_shop"):
				Game.setf("v_shop")
				Sfx.play("sting_soft", -12.0)
				await ui.say([
					"（奶奶的扎纸铺。）",
					"（纸童、纸马、纸老太太……架子上、地上，站满了纸人。）",
					"（它们的脸，全都朝着门口。）",
				])
				refresh_objective()
			elif room == "yard" and Game.flag("v_kitchen") and Game.flag("v_shop") and Game.flag("saw_stand") and not Game.flag("girl_seen"):
				_first_sighting()
		2:
			if room == "yard" and not Game.flag("knocked") and Game.flag("intro2"):
				_knock_event()
			elif room == "east" and Game.flag("east_open") and not Game.flag("east_seen"):
				Game.setf("east_seen")
				await ui.say(["（奶奶的屋子。一股樟脑和旧棉絮的味道。）", "（桌上摊着一个本子。）"])
		3:
			if room == "hall" and not Game.flag("coffin_knock"):
				Game.setf("coffin_knock")
				Game.frozen += 1
				await get_tree().create_timer(0.6).timeout
				Game.frozen -= 1
				Sfx.play_at("knock", world.obj("coffin").global_position, 2.0, 0.8)
				world.do_shake(0.5)
				await ui.say([
					"（咚。咚。咚。）",
					"（声音……是从棺材里传出来的。）",
				])
				await get_tree().create_timer(0.4).timeout
				await ui.say(["（遗像……被翻了过去，面朝着墙。）"])
		4:
			if room == "shrine" and not Game.flag("shrine_seen"):
				Game.setf("shrine_seen")
				await ui.say([
					"（祠堂里供着林家祖宗的牌位。）",
					"（最新的一块盖着红布，是奶奶的。）",
					"（墙角站着一个纸人。它的个头，和我一般高。）",
				])

func _first_sighting() -> void:
	Game.setf("girl_seen")
	var g: Node2D = world.girl
	var ui = world.ui
	g.visible = true
	g.set_state("stand")
	g.global_position = Vector2(10 * 16 + 8, 25 * 16 + 4)
	Game.frozen += 1
	await get_tree().create_timer(0.3).timeout
	Game.frozen -= 1
	Sfx.play("sting_soft", -2.0)
	world.focus_obj = g
	await ui.say([
		"（槐树底下……）",
		"（站着一个穿红衣服的小孩。）",
	])
	world.focus_obj = null
	await get_tree().create_timer(1.2).timeout
	for id in ["lantern1", "lantern2"]:
		world.set_light(id, false)
	world.modulate_node.color = Color("050408")
	Sfx.play("paper_rustle", -2.0)
	await get_tree().create_timer(0.5).timeout
	g.visible = false
	g.set_state("idle")
	world.modulate_node.color = Color("0e0d16")
	for id in ["lantern1", "lantern2"]:
		world.set_light(id, true)
	await ui.say(["（……不见了。）", "（是纸人。红纸衣服，白脸蛋，两团胭脂。和扎纸铺里那些一模一样。）", "（那个空架子上，原本站的就是她吧。）"])
	refresh_objective()

func _knock_event() -> void:
	Game.setf("knocked")
	var ui = world.ui
	var g: Node2D = world.girl
	var prev: String = g.state
	g.set_state("idle")
	Game.frozen += 1
	Sfx.play_at("knock", Vector2(22 * 16, 36 * 16), 2.0)
	await get_tree().create_timer(1.6 if not Game.autotest else 0.1).timeout
	Game.frozen -= 1
	await ui.say([
		"（咚、咚、咚。有人在拍大门。）",
		"门外|默儿？默儿，开门，是我。",
		"门外|我落了点东西在里头，你开一下门。",
		"（是三叔的声音。）",
		"门外|默儿？你在不在？",
		"门外|你应一声啊。",
	])
	var c: int = await ui.choose("（门外的人在等你回答。）", ["应一声", "不出声"])
	if c == 0:
		await ui.say(["林默|三叔，我在——"])
		Sfx.stop_all_loops(0.1)
		await get_tree().create_timer(1.2).timeout
		await ui.say(["（门外安静了。）", "（过了很久，门缝底下，慢慢伸进来一只惨白的手。）"])
		Game.frozen += 1
		world.player_caught("answer")
		return
	Game.frozen += 1
	await get_tree().create_timer(2.5 if not Game.autotest else 0.1).timeout
	Game.frozen -= 1
	await ui.say([
		"门外|……默儿。",
		"门外|是奶奶啊。默儿，奶奶冷……给奶奶开开门……",
	])
	Sfx.play("whisper", -2.0, 0.8)
	await get_tree().create_timer(1.0).timeout
	Sfx.play("laugh", -6.0)
	await ui.say([
		"（不是三叔。也不是奶奶。）",
		"（家人们谁懂啊，门外那个东西还会变声。）",
		"（门外的东西低低地笑了一声，脚步声绕着院墙，往后院去了。）",
		"（奶奶的钥匙从不离身，一向挂在她腰上。东厢……或许有什么。）",
	])
	g.set_state(prev if prev != "idle" else "wander")
	refresh_objective()

# ================================================================ 互动
func interact(o: Node2D) -> void:
	var ui = world.ui
	var ch := Game.chapter
	var id: String = o.id
	if id.begins_with("jar_"):
		Game.setf(id)
		Game.give("oil")
		Sfx.play("pickup", -6.0)
		ui.toast("获得：灯油 ×1（Q 给油灯添油）")
		world.remove_obj(id)
		return
	if o.hide_spot and ch >= 2 and not (id == "altar" and ch == 5 and false):
		world.hide_player(o)
		return
	match id:
		"eternal":
			await _eternal()
		"portrait":
			if ch >= 3:
				await ui.say(["（遗像面朝着墙。我不敢把它翻过来。）"])
			else:
				await ui.say(["（奶奶在相片里笑着。）", "（我已经记不清，她笑起来是什么样子了。）"])
		"altar":
			var merit: int = int(Game.flags.get("merit", 0)) + 1
			Game.flags["merit"] = merit
			if merit == 1:
				await ui.say(["（供桌上摆着倒头饭，一双筷子直直插在饭中间。）", "（白布垂到地上。底下能藏一个人。）"])
			Sfx.play("knock", -16.0, 2.2)
			ui.toast("我对着供桌拜了拜。功德 +1（%d）" % merit)
			if merit == 10:
				await ui.say(["（……奶奶，功德应该够了吧。）"])
		"coffin":
			await _coffin()
		"wreath1", "wreath3":
			await ui.say(["（挽联上写着：沉痛悼念林秀英老人千古。）"])
		"wreath2":
			await ui.say(["（落款：村口小卖部 王哥。）", "（挽联背面用圆珠笔补了一行：秀英婶，欠的两块钱不用还了。）"])
		"wreath4":
			await ui.say(["（落款：孙子 林默。）", "（是三叔替我订的。字写错了一个，我也没脸让人改。）"])
		"tree":
			await ui.say(["（老槐树。小时候姐姐常把我抱上那根最低的树杈。）", "（树上系着几条白布，风一吹，像是有人在招手。）"])
		"yard_vat", "kitchen_vat":
			await ui.say(["（一缸水，黑沉沉的，照不出人影。）"])
		"stove":
			await ui.say(["（灶膛里的火快熄了。锅里有半锅凉了的粥。）", "（灶台上贴着一张褪色的灶王爷，旁边是小满歪歪扭扭的字：干饭人，干饭魂。）"])
		"oilvat":
			await _scoop()
		"firewood", "back_wood":
			await ui.say(["（码得整整齐齐的柴火。后面有个空当，蹲得下一个人。）"])
		"kitchen_shelf":
			await ui.say(["（碗柜里摞着白瓷碗。最底下有一只小小的搪瓷碗，碗沿上印着一朵红花。）"])
		"kitchen_table":
			await ui.say(["（饭桌上摆着三副碗筷。）", "（……三副？）"])
		"shop_boy", "shop_old", "shop_boy2", "shop_old2":
			await ui.say(["（纸人的脸是白的，两腮各点一团胭脂。）", "（没有画眼睛。奶奶扎的纸人，从来都不画眼睛。）"])
		"shop_rack":
			await ui.say(["（还没糊纸的竹篾骨架。奶奶走之前，还在扎这个。）"])
		"horse":
			await ui.say(["（纸马。给死人骑的。马肚子上贴着金纸剪的花。）", "（马屁股上还贴了张红纸：马上有钱。）"])
		"stand":
			await ui.say([
				"（一个空架子。架子上挂着一张红纸条，写着一个字——）",
				"（满。）",
				"（……小满？）",
				"（我姐姐的名字。二十年前，爷爷头七那夜，她不见了。）",
				"（村里人都说，她掉进了后院的井里。可井里什么也没捞上来。）",
			])
			Game.setf("saw_stand")
			refresh_objective()
		"workbench":
			await ui.say(["（工作台上散着剪刀、浆糊和红纸。旁边压着一张订单——）", "（「纸扎别墅一套，要带电梯和游泳池。纸手机两部，要最新款。——王家」）", "（纸手机背面，奶奶工工整整写了四个字：遥遥领先。）", "（……下面也卷起来了吗。）", "（工作台另一头，一张红纸剪了一半，是件小孩的衣裳。）"])
		"shop_shelf":
			await ui.say(["（颜料架。红、绿、金……还有一个空碗，碗底结着一层暗红色的东西。）", "（架子上贴着奶奶的字：本店纸扎，概不退换。）"])
		"shop_pile":
			await ui.say(["（一堆纸人挤在墙角。钻进去，大概分不出谁是谁。）"])
		"well":
			if ch >= 2:
				Sfx.play("drip", -2.0)
				await ui.say(["（井口压着一块石板……没压严。）", "（井里……有人在哼歌。）"])
				Sfx.play("music_box_open", -14.0, 0.7)
				await get_tree().create_timer(1.5).timeout
				await ui.say(["（是小时候姐姐哄我睡觉的那首。）"])
			else:
				await ui.say(["（井口压着一块石板。我小时候，奶奶从来不让我靠近这口井。）"])
		"backgate":
			if Game.flag("dawn"):
				await _ending_true()
			else:
				Sfx.play("door_locked", -6.0)
				await ui.say(["（后门上着门闩。）", "（规矩第五条：鸡叫以前，不要开后门。）"])
				if ch >= 2:
					Sfx.play_at("knock", o.global_position + Vector2(0, -10), -4.0, 1.2)
					await ui.say(["（门的那一边，有什么东西轻轻挠了两下。）"])
		"gate":
			Sfx.play("door_locked", -6.0)
			await ui.say(["（大门从外面锁上了。三叔说，鸡叫了才来开门。）"])
		"door_west":
			await _door_west()
		"door_east":
			if Game.has("key_east"):
				Sfx.play("door_locked", -4.0, 1.3)
				world.set_door_locked("door_east", false)
				world.open_door("door_east")
				Game.setf("east_open")
				Game.take("key_east")
				refresh_objective()
			else:
				Sfx.play("door_locked", -6.0)
				await ui.say(["（东厢锁着。奶奶的屋子。）"] if ch < 2 else ["（东厢锁着。钥匙……奶奶的钥匙一向挂在她腰上。）"])
		"door_shrine":
			await _door_shrine()
		"door_shop", "door_kitchen":
			pass
		# ---- 西厢
		"west_bed":
			if ch >= 4:
				if not Game.flag("read_xiaoman"):
					await ui.say(["（小床上铺着粉色的褥子，叠得整整齐齐，二十年没人睡过。）", "（枕头底下压着一张纸条。）"])
					Game.add_doc("xiaoman")
					await ui.show_doc(DOCS.xiaoman.title, DOCS.xiaoman.text)
					Game.setf("read_xiaoman")
					Sfx.loop("music", "music_lullaby", -20.0, 3.0)
					await ui.say(["（……）", "（姐姐。）", "（那天早上我醒来，奶奶抱着我哭。她说，姐姐去镇上了。）", "（我等了她一整个冬天。）"])
					Sfx.stop_loop("music", 4.0)
				else:
					await ui.show_doc(DOCS.xiaoman.title, DOCS.xiaoman.text)
			else:
				await ui.say(["（小床上铺着粉色的褥子。）"])
		"west_desk":
			if not Game.flag("got_photo"):
				Game.setf("got_photo")
				Game.give("photo")
				Game.add_doc("photo")
				Sfx.play("pickup", -8.0)
				await ui.say(["（书桌的抽屉里有一张照片。）"])
				await ui.show_doc(DOCS.photo.title, DOCS.photo.text)
			else:
				await ui.show_doc(DOCS.photo.title, DOCS.photo.text)
		"brush_obj":
			Game.setf("took_brush")
			Game.give("brush")
			world.remove_obj("brush_obj")
			Sfx.play("pickup", -6.0)
			await ui.say(["（一支小毛笔，笔杆上刻着一个「满」字。笔头早就干透了。）"])
			refresh_objective()
		"musicbox":
			await _musicbox()
		"west_shelf":
			await ui.say(["（架子上摆着布老虎、拨浪鼓，还有一包没拆开的糖。）", "（糖纸上印着：镇供销社。保质期十二个月。）", "（……过期十九年了。）"])
		"drawing":
			Game.add_doc("drawing")
			await ui.show_doc(DOCS.drawing.title, DOCS.drawing.text)
		"west_chair":
			pass
		# ---- 东厢
		"east_desk":
			Game.add_doc("diary1")
			await ui.show_doc(DOCS.diary1.title, DOCS.diary1.text)
			if ch == 2 and not Game.flag("read_d1"):
				Game.setf("read_d1")
				await get_tree().create_timer(0.5).timeout
				Sfx.play("breath", -4.0)
				await ui.say(["（屋外，有什么东西从窗户底下慢慢走了过去。）", "（还有两本……日记应该不止这一页。）"])
				await next_chapter()
		"east_bed":
			if ch >= 3:
				Game.add_doc("diary2")
				await ui.say(["（枕头底下压着一叠写满字的纸。）"] if not Game.flag("know_four") else [])
				await ui.show_doc(DOCS.diary2.title, DOCS.diary2.text)
				if not Game.flag("know_four"):
					Game.setf("know_four")
					Sfx.play("sting_soft", -6.0)
					await ui.say([
						"（四条？）",
						"（可三叔交给我的这张纸上……写的是五条。）",
						"（多出来的那一条，是谁写的？）",
					])
					ui.toast("R 打开规矩，撕掉假的那一条")
					refresh_objective()
			else:
				await ui.say(["（奶奶的床。被子叠好了，枕头还有一个浅浅的窝。）"])
		"dresser":
			await _dresser()
		"east_table":
			await ui.say(["（八仙桌上摆着一碗凉透了的药。）"])
		"east_shelf":
			await ui.say(["（针线架上挂满了红纸剪的小衣裳。一年一件，从小到大。）", "（我数了数。二十件。）"])
		"east_wardrobe", "west_wardrobe":
			await ui.say(["（一个旧衣柜，躲得下一个人。）"])
		# ---- 祠堂
		"tablets":
			await ui.say([
				"（一排排黑漆牌位，金字已经暗了。）",
				"（最边上一块小小的牌位：林小满之位。）",
				"（没有写生卒年月。）",
				"（奶奶不承认她死了。）",
			])
		"shrine_table":
			Game.add_doc("last")
			await ui.show_doc(DOCS.last.title, DOCS.last.text)
			if not Game.flag("read_last"):
				Game.setf("read_last")
				refresh_objective()
				_check_ch5()
		"cinnabar":
			Game.setf("took_cinnabar")
			Game.give("cinnabar")
			world.remove_obj("cinnabar")
			Sfx.play("pickup", -6.0)
			await ui.say(["（一碗朱砂，红得像血。奶奶指尖上的，就是这个。）"])
			refresh_objective()
			_check_ch5()
		"effigy_me":
			await _effigy_me()
		"girl_proxy":
			await _girl_proxy()
		_:
			if o.label != "":
				await ui.say(["（%s。）" % o.label])

func _check_ch5() -> void:
	if Game.chapter == 4 and Game.has("cinnabar") and Game.has("brush") and Game.flag("read_last"):
		await get_tree().create_timer(0.8).timeout
		await world.ui.say(["（朱砂，毛笔。都齐了。）", "（替身……还是姐姐？）"])
		await next_chapter()
	elif Game.chapter == 4 and Game.has("cinnabar") and not Game.has("brush"):
		await world.ui.say(["（还缺一支笔。西厢书桌上好像有一支。）"])

func _eternal() -> void:
	var ui = world.ui
	if Game.chapter == 5 and Game.flag("eyes") and not Game.flag("dawn"):
		if Game.has("oil"):
			await _final_burn()
		else:
			await ui.say(["（没有油了！去灶屋！）"])
		return
	if not Game.has("oil"):
		await ui.say(["（长明灯的火苗跳了跳。）", "（我身上没有灯油了。灶屋的油缸里能舀。）"])
		return
	var explored: bool = Game.flag("v_kitchen") and Game.flag("v_shop") and Game.flag("saw_stand")
	if Game.chapter == 1 and explored and not Game.flag("girl_seen"):
		# 兜底：没在院子里触发目击，就在这里补上
		await _first_sighting()
	var advance: bool = Game.chapter == 0 or (Game.chapter == 1 and Game.flag("girl_seen"))
	if Game.chapter == 1 and not explored:
		var left := []
		if not Game.flag("v_kitchen"):
			left.append("灶屋")
		if not Game.flag("v_shop") or not Game.flag("saw_stand"):
			left.append("扎纸铺（看看那个空架子）")
		await ui.say(["（火还旺着，暂时不用添。）", "（先去%s看看吧。）" % "、".join(left)])
		return
	if Game.eternal > 97.0 and not advance:
		await ui.say([["（长明灯烧得正旺，等火小一些再来添。）", "（长明灯烧得正旺。稳住，我们能赢。等火小一些再来。）", "（火苗很稳，比我稳。等它小一些再来添。）"][randi() % 3]])
		ui.toast("长明灯会慢慢变小，右上角「长明」条降下来再添")
		return
	Game.take("oil")
	Sfx.play("oil_pour", -2.0)
	Game.eternal = minf(100.0, Game.eternal + 50.0)
	ui.toast("长明灯添了油")
	await ui.say(["（灯芯「噼」地一跳，火苗旺了起来。）"])
	if Game.chapter == 0:
		await next_chapter()
	elif Game.chapter == 1 and Game.flag("girl_seen"):
		await get_tree().create_timer(0.6).timeout
		await ui.say(["（我盯着那团火看了很久。）", "（槐树底下那个红衣服的纸人……我好像在哪儿见过她。）"])
		await next_chapter()

func _scoop() -> void:
	var ui = world.ui
	if Game.count("oil") >= 3:
		await ui.say(["（拿不下了。两只手，三个罐，我已经是极限了。）"])
		return
	Game.frozen += 1
	Sfx.play("oil_pour", -4.0, 0.9)
	world.noise(world.player.global_position, 70.0, "scoop")
	await get_tree().create_timer(1.1 if not Game.autotest else 0.05).timeout
	Game.frozen -= 1
	Game.give("oil")
	ui.toast("舀了一罐灯油（×%d）" % Game.count("oil"))

func _coffin() -> void:
	var ui = world.ui
	var ch := Game.chapter
	if ch < 2:
		await ui.say(["（黑漆棺材。棺盖上钉着七颗钉子……）", "（不对，只有六颗。）"])
		return
	if ch == 2 and not Game.has("key_east") and not Game.flag("east_open"):
		var c: int = await ui.choose("（奶奶的钥匙……在她腰上。）", ["推开棺盖", "算了"])
		if c != 0:
			return
		Sfx.play("scrape", 0.0)
		world.do_shake(0.6)
		world.noise(world.obj("coffin").global_position, 140.0, "coffin")
		await ui.say([
			"（棺盖很沉。我推开了一道缝。）",
			"（奶奶穿着深蓝色的寿衣，脸上盖着一张黄纸。）",
			"（腰上……挂着一串铜钥匙。）",
		])
		Sfx.play("pickup", -8.0)
		Game.give("key_east")
		await ui.say([
			"（钥匙冰凉。）",
			"（奶奶的手指……指尖是红的。）",
			"（像是朱砂。）",
		])
		Sfx.play("scrape", -4.0, 1.2)
		await ui.say(["（我把棺盖推了回去。黄纸底下，好像动了一下。）"])
		ui.toast("获得：东厢钥匙")
		refresh_objective()
		return
	if ch == 5:
		await ui.say(["（棺材空了。）"])
		return
	await ui.say(["（我不敢再碰它。）"])

func _door_west() -> void:
	var ui = world.ui
	if Game.chapter < 4:
		await ui.say(["（西厢门上贴着一道黄符，符纸已经褪色了。）", "（小满的屋子。奶奶封了二十年。）"])
		return
	var c: int = await ui.choose("（门上的黄符。）", ["撕掉封条", "算了"])
	if c != 0:
		return
	Sfx.play("tear", 0.0)
	var s: Sprite2D = world.decals.get_node_or_null("seal")
	if s:
		s.texture = Art.tex("seal_torn")
	world.set_door_locked("door_west", false)
	world.open_door("door_west")
	Game.setf("west_open")
	world.noise(world.player.global_position, 900.0, "seal")
	world.do_shake(0.5)
	await ui.caption("哗啦——", 0.8, Color("c8a0a0"))
	await ui.say(["（太响了。）", "（整个院子都听见了。）"])
	ui.toast("她来了——躲进西厢的衣柜！")
	var g: Node2D = world.girl
	g.global_position = world.tile_center(Vector2i(34, 22)) if g.global_position.distance_to(world.player.global_position) < 200.0 else g.global_position
	g.set_state("investigate")
	g.path = world.find_path(g.global_position, world.tile_center(Vector2i(6, 14)))
	refresh_objective()

func _door_shrine() -> void:
	var ui = world.ui
	if Game.chapter < 4 and not Game.flag("know_four"):
		Sfx.play("door_locked", -6.0)
		await ui.say(["（祠堂门上挂着一把铜锁，有四个转轮。）", "（密码……我不知道。）"])
		return
	var code: String = await ui.keypad("祠堂的铜锁")
	if code == "":
		return
	if code == CODE:
		Sfx.play("door_locked", -2.0, 1.4)
		world.set_door_locked("door_shrine", false)
		world.open_door("door_shrine")
		Game.setf("shrine_open")
		await ui.say(["（「咔」。锁开了。腊月初八。）"])
		refresh_objective()
	else:
		Sfx.play("door_locked", -4.0)
		await ui.say(["（锁纹丝不动。）"] if Game.flag("know_four") else ["（锁纹丝不动。）", "（奶奶会用什么当密码？）"])

func _musicbox() -> void:
	var ui = world.ui
	if Game.chapter < 4:
		return
	await ui.say(["（一个红漆八音盒。我记得它。姐姐不让我碰。）"])
	var c: int = await ui.choose("", ["打开", "不了"])
	if c != 0:
		return
	Sfx.play("music_box_open", 0.0)
	Sfx.loop("music", "music_lullaby", -6.0, 0.5)
	world.noise(world.obj("musicbox").global_position, 600.0, "music")
	_musicbox_t = 16.0
	var g: Node2D = world.girl
	if g.visible and g.state != "idle":
		g.set_state("investigate")
		g.path = world.find_path(g.global_position, world.obj("musicbox").global_position + Vector2(0, 14))
	await ui.say(["（叮叮咚咚，是那首摇篮曲。）", "（……有什么在往这边来。）"])

func _dresser() -> void:
	var ui = world.ui
	var ch := Game.chapter
	if ch < 3:
		await ui.say(["（梳妆台。镜子用白布蒙着。）", "（家里有人过世，镜子都要蒙上。）"])
		return
	var opts := ["拉开抽屉", "掀开白布", "算了"]
	if Game.flag("mirror_seen"):
		opts = ["拉开抽屉", "算了"]
	var c: int = await ui.choose("（梳妆台。镜子蒙着白布。）", opts)
	if c == 0:
		Game.add_doc("diary3")
		await ui.say(["（抽屉里压着几页日记，纸都黄了。）"] if not Game.flag("read_d3") else [])
		await ui.show_doc(DOCS.diary3.title, DOCS.diary3.text)
		if not Game.flag("read_d3"):
			Game.setf("read_d3")
			await ui.say(["（……）", "（原来那天夜里，应声的是我。）"])
	elif c == 1 and opts.size() == 3:
		var c2: int = await ui.choose("（规矩第三条：子时以后，不要照镜子。）", ["掀开", "不掀"])
		if c2 != 0:
			return
		Game.setf("mirror_seen")
		Sfx.play("cloth", -2.0)
		world.obj("dresser").set_art("dresser_open")
		await ui.say(["（镜子里是我自己。脸色惨白。）"])
		await get_tree().create_timer(0.8).timeout
		Sfx.play("sting", -2.0)
		world.do_flash(0.6)
		world.do_shake(0.8)
		await ui.say([
			"（我身后——站着一个穿深蓝寿衣的人。）",
			"（她背对着我，弯着腰，拿着一支笔，在一张纸上写着什么。）",
			"（纸上的字，一笔一画，是第四条。）",
		])
		Sfx.play("glass", -2.0)
		await ui.say(["（我猛地回过头——身后什么都没有。）", "（手里的油灯一下子暗了。）"])
		Game.lamp = maxf(5.0, Game.lamp - 45.0)
		world.noise(world.player.global_position, 400.0, "mirror")

func on_tear(idx: int) -> void:
	var ui = world.ui
	if idx == FAKE_RULE:
		Game.torn_rule = idx
		Sfx.play("tear", 0.0)
		await ui.say(["（「四、纸人的眼睛，不能点。」）", "（我把这一条撕了下来。）"])
		Sfx.play("burn", -2.0)
		world.do_flash(0.3)
		await ui.say(["（纸条在我手里自己烧了起来，连灰都没剩下。）"])
		Sfx.play("whisper", 0.0, 1.1)
		await ui.caption("……你找到了。", 2.0, Color("c8a0a0"))
		await ui.say(["（不是那个东西的声音。）", "（是个小女孩。）"])
		Game.setf("tore_fake")
		if Game.chapter == 3:
			await next_chapter()
	else:
		Sfx.play("tear", 0.0)
		await ui.say(["（我撕下了第%s条。）" % ["一", "二", "三", "四", "五"][idx]])
		await get_tree().create_timer(0.6).timeout
		Sfx.play("laugh", 0.0)
		world.do_flash(0.5)
		world.do_shake(0.7)
		Game.lamp = maxf(5.0, Game.lamp - 40.0)
		Game.eternal = maxf(8.0, Game.eternal - 20.0)
		await ui.caption("嘻嘻……", 1.4, Color("c83a3a"))
		await ui.say(["（低头一看——撕掉的那一条，又长回了纸上。）", "（墨迹是湿的。）", "（油灯和长明灯，都暗了一截。）"])
		var g: Node2D = world.girl
		if g.visible and g.state != "idle":
			g.set_state("investigate")
			g.path = world.find_path(g.global_position, world.player.global_position)

func _effigy_me() -> void:
	var ui = world.ui
	var ch := Game.chapter
	if ch < 5:
		await ui.say(["（一个纸人。蓝纸衣，白脸，两团胭脂。）", "（胸前的红纸条上写着两个字：林默。）", "（它也没有眼睛。）"])
		return
	if not (Game.has("brush") and Game.has("cinnabar")):
		await ui.say(["（写着我名字的纸人。）"])
		return
	var c: int = await ui.choose("（写着「林默」的替身。点了睛，它就替你去。）", ["给它点上眼睛", "再想想"])
	if c == 0:
		await _ending_substitute()

func _girl_proxy() -> void:
	var ui = world.ui
	if not (Game.has("brush") and Game.has("cinnabar")):
		await ui.say(["（她站在槐树底下，一动不动。）"])
		return
	if Game.torn_rule != FAKE_RULE:
		await ui.say(["（「纸人的眼睛，不能点。」）", "（规矩上写着……我的手在发抖。）"])
		var c0: int = await ui.choose("", ["还是要点", "算了"])
		if c0 != 0:
			return
	var c: int = await ui.choose("（小满。她在等。）", ["给她点上眼睛", "再想想"])
	if c != 0:
		return
	await _sister_awake()

# ================================================================ 第五章
func _intro5() -> void:
	var ui = world.ui
	Sfx.play("scrape", 2.0, 0.8)
	world.do_shake(1.0)
	await get_tree().create_timer(1.2).timeout
	world.obj("coffin").set_art("coffin_open")
	Sfx.play("whisper", 2.0, 0.7)
	await ui.say([
		"（堂屋那边，传来一声很长的、木头摩擦的声音。）",
		"（棺材……开了。）",
		"门外|默儿……",
		"门外|默儿，奶奶起来了。过来，让奶奶看看你。",
	])
	world.shadow.global_position = world.obj("coffin").global_position + Vector2(0, 8)
	world.shadow.activate()
	Sfx.loop("music", "music_tension", -10.0, 2.0)
	var g: Node2D = world.girl
	g.visible = true
	g.set_state("stand")
	g.global_position = Vector2(10 * 16 + 8, 25 * 16 + 4)
	if world.obj("girl_proxy") == null:
		girl_proxy = world.add("girl_proxy", "", Vector2i(10, 24), {"solid": false, "label": "红衣纸人", "verb": "靠近"})
	await ui.say([
		"（院子里，那个红衣服的纸人站在槐树底下，一动不动。）",
		"（像是在等谁。）",
	])
	ui.toast("它看得见你——但它怕光。用油灯照着它")
	_rooster = 210.0

func _sister_awake() -> void:
	var ui = world.ui
	var g: Node2D = world.girl
	Game.frozen += 1
	Sfx.stop_loop("music", 1.0)
	world.focus_obj = g
	await ui.say(["（我蘸了朱砂，在她白纸糊的脸上，点了两下。）"])
	Sfx.play("chime", 0.0)
	g.set_eyes(true)
	world.do_flash(0.4)
	Game.setf("eyes")
	Game.take("cinnabar")
	await get_tree().create_timer(1.0 if not Game.autotest else 0.05).timeout
	Sfx.loop("music", "music_lullaby", -14.0, 2.0)
	Game.frozen -= 1
	await ui.say([
		"（纸人的眼睛，眨了一下。）",
		"小满|……弟弟？",
		"小满|默儿，是你吗？你长这么高了。",
		"小满|我一直听得见你。就是看不见。",
		"林默|姐……",
		"小满|别哭。你小时候就爱哭。",
	])
	Sfx.play("whisper", 0.0, 0.7)
	await ui.say([
		"小满|它来了。",
		"小满|默儿，长明灯！把灯油全倒进去——它最怕那个火！",
		"小满|我拖住它。快去！",
	])
	world.focus_obj = null
	Sfx.loop("music", "music_tension", -8.0, 1.0)
	world.remove_obj("girl_proxy")
	g.set_state("follow")
	Game.save_checkpoint()
	refresh_objective()

func _final_burn() -> void:
	var ui = world.ui
	Game.frozen += 1
	Game.take("oil")
	Sfx.play("oil_pour", 0.0)
	await get_tree().create_timer(0.8).timeout
	Sfx.play("fire_whoosh", 2.0)
	world.do_flash(1.0)
	world.do_shake(1.2)
	Game.eternal = 100.0
	var tw := create_tween()
	tw.tween_property(world.eternal_light, "texture_scale", 6.0, 0.6)
	var s: Node2D = world.shadow
	s.state = "burn"
	Sfx.play("sting", -2.0, 0.7)
	var tw2 := create_tween()
	tw2.tween_property(s, "modulate", Color(3, 1.5, 0.5, 0), 2.0)
	await ui.say(["（火「轰」地蹿上了房梁。）", "（那个穿寿衣的东西在火光里扭成一团，发出一声不像人的尖叫。）"])
	await tw2.finished
	s.visible = false
	Game.setf("shadow_dead")
	Sfx.stop_loop("music", 2.0)
	await get_tree().create_timer(1.5 if not Game.autotest else 0.05).timeout
	Sfx.play("rooster", 0.0)
	var tw3 := create_tween()
	tw3.tween_property(world.modulate_node, "color", Color("4a4c5a"), 4.0)
	await ui.say(["（……鸡叫了。）", "（这一嗓子，叫得是真有点太美了。）"])
	Game.setf("dawn")
	world.set_door_locked("backgate", false)
	Game.frozen -= 1
	var g: Node2D = world.girl
	await ui.say([
		"小满|天亮了。",
		"小满|默儿，帮我开一下后门吧。",
		"小满|奶奶等我好久了。",
	])
	Sfx.loop("music", "music_ending", -10.0, 3.0)
	refresh_objective()
	g.set_state("follow")

func _ending_true() -> void:
	var ui = world.ui
	var g: Node2D = world.girl
	Game.frozen += 1
	Sfx.play("door_open", 0.0, 0.8)
	world.obj("backgate").set_art("backgate_open")
	world.set_light("lantern1", false)
	var l: PointLight2D = world._mk_light(world.obj("backgate").global_position + Vector2(0, 10), Color(0.9, 0.9, 1.0), 1.2, 2.5, false, "light_soft")
	l.visible = true
	g.set_state("idle")
	var tw := create_tween()
	tw.tween_property(g, "global_position", world.obj("backgate").global_position + Vector2(0, 14), 2.0)
	await tw.finished
	Game.frozen -= 1
	await ui.say([
		"（门外是一片白茫茫的雾。）",
		"小满|默儿。",
		"小满|这回，换你记得我了。",
		"林默|姐，你还没给我带糖呢。",
		"小满|（她笑了，眯起眼睛，和照片上一模一样。）",
		"小满|糖在架子上，那包我一直没舍得吃。",
		"小满|你要好好的。",
	])
	Game.frozen += 1
	var tw2 := create_tween()
	tw2.tween_property(g, "global_position", world.obj("backgate").global_position + Vector2(0, -6), 2.5)
	tw2.parallel().tween_property(g, "modulate:a", 0.0, 2.5)
	await tw2.finished
	await ui.fade_to(1.0, 2.0)
	_finish("true")

func _ending_substitute() -> void:
	var ui = world.ui
	Game.frozen += 1
	Sfx.stop_loop("music", 1.0)
	world.focus_obj = world.obj("effigy_me")
	await ui.say(["（我蘸了朱砂，在写着自己名字的纸人脸上，点了两下。）"])
	world.obj("effigy_me").set_art("effigy_eyes")
	Sfx.play("chime", 0.0, 0.8)
	world.do_flash(0.4)
	await get_tree().create_timer(1.2 if not Game.autotest else 0.05).timeout
	await ui.say(["（纸人睁开了眼睛。）", "（它看着我，慢慢地笑了。笑得和我一模一样。）"])
	world.shadow.state = "idle"
	var tw := create_tween()
	tw.tween_property(world.obj("effigy_me"), "modulate:a", 0.0, 2.0)
	tw.parallel().tween_property(world.shadow, "modulate:a", 0.0, 2.0)
	await tw.finished
	world.girl.visible = false
	Sfx.play("rooster", 0.0)
	await ui.say(["（鸡叫了。）"])
	await ui.fade_to(1.0, 1.5)
	Game.frozen -= 1
	_finish("substitute")

func _ending_paper() -> void:
	if Game.flag("ending_started"):
		return
	Game.setf("ending_started")
	var ui = world.ui
	Game.frozen += 1
	world.shadow.state = "idle"
	Sfx.stop_loop("music", 1.0)
	Sfx.play("rooster", 0.0)
	var tw := create_tween()
	tw.tween_property(world.shadow, "modulate:a", 0.0, 1.5)
	tw.parallel().tween_property(world.modulate_node, "color", Color("4a4c5a"), 4.0)
	await ui.say(["（鸡叫了。）", "（那个东西不见了。槐树底下，红衣服的纸人也不见了。）"])
	Sfx.play("door_open", 0.0, 0.7)
	await ui.say([
		"三叔|默儿！默儿你没事吧？",
		"三叔|好，好……熬过来就好……",
		"三叔|……",
		"三叔|默儿，你、你身上穿的这是什么？",
	])
	Sfx.play("paper_rustle", 0.0)
	await ui.say(["（我低下头。）", "（身上的孝服沙沙作响。）", "（是纸糊的。）"])
	await ui.fade_to(1.0, 1.0)
	Game.frozen -= 1
	_finish("paper")

func _finish(id: String) -> void:
	Sfx.stop_all_loops(1.5)
	Game.see_ending(id)
	Game.flags["ending"] = id
	Game.goto("res://scenes/ending.tscn")

# ================================================================ 失败
func on_caught(kind: String) -> void:
	var ui = world.ui
	Sfx.stop_all_loops(0.2)
	var titles := {
		"girl": ["纸　手", "冰凉的纸手捂住了你的嘴。\n她贴着你的耳朵，轻轻地说：\"……找到你了。\""],
		"shadow": ["寿　衣", "它用奶奶的声音说：\"默儿，跟奶奶走。\""],
		"eternal": ["长　夜", "长明灯灭了。\n黑暗里，有什么东西从棺材里坐了起来。"],
		"answer": ["应　声", "你应了。\n它记住了你的名字。"],
	}
	var art: String = {"girl": "girl", "shadow": "shadow_0", "eternal": "shadow_1", "answer": "shadow_0"}[kind]
	await ui.jumpscare(art)
	var t: Array = titles[kind]
	var tips := ["提示：按住 Ctrl 潜行，她几乎听不见你。", "提示：跑步很快，但整个院子都听得见。", "提示：衣柜、柴堆、纸人堆、供桌底下都能躲。", "提示：长明灯不能灭。灶屋的油缸可以一直舀。", "已老实，求放过。", "人在衣柜，刚躲进去，她就到了。", "心态崩了？没关系，天还没亮。"]
	await ui.game_over(t[0], t[1] + "\n\n" + tips[randi() % tips.size()])
