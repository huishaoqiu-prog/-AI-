extends Node2D
## 场景中的可交互物件 / 家具 / 门

var id := ""
var label := ""            # 显示名
var verb := "调查"
var interact := true
var hide_spot := false
var rect := Rect2()        # 世界坐标下的占地（用于交互距离）
var tiles: Array = []      # 阻挡的格子
var sprite: Sprite2D
var art := ""

# 门
var is_door := false
var vertical := false
var locked := false
var is_open := false
var door_tile := Vector2i.ZERO
var occluder: LightOccluder2D
var body: StaticBody2D

func set_art(name: String) -> void:
	art = name
	if sprite == null:
		sprite = Sprite2D.new()
		sprite.centered = false
		add_child(sprite)
	sprite.texture = Art.tex(name)
	var s := sprite.texture.get_size()
	sprite.offset = Vector2(-floor(s.x / 2.0), -s.y)

func open_door(silent: bool = false) -> void:
	if is_open:
		return
	is_open = true
	set_art(("door_v_open" if vertical else "door_h_open") if art.begins_with("door") else art)
	if occluder:
		occluder.visible = false
	if body:
		body.process_mode = Node.PROCESS_MODE_DISABLED
		for c in body.get_children():
			(c as CollisionShape2D).set_deferred("disabled", true)
	if not silent:
		Sfx.play_at("door_open", global_position, -2.0, randf_range(0.9, 1.1))
