extends Node2D
## 声音的涟漪（淡淡的一圈，提示玩家"你发出了声音"）

var max_r := 30.0
var t := 0.0

func _ready() -> void:
	z_index = 5

func _process(delta: float) -> void:
	t += delta
	if t > 0.7:
		queue_free()
	queue_redraw()

func _draw() -> void:
	var k := t / 0.7
	var r := lerpf(4.0, max_r, k)
	var a := (1.0 - k) * 0.35
	var n := int(r * 1.2) + 8
	for i in n:
		if i % 2 == 0:
			var ang := float(i) / n * TAU
			draw_rect(Rect2(Vector2(cos(ang) * r, sin(ang) * r * 0.6).round(), Vector2.ONE), Color(0.85, 0.85, 1.0, a))
