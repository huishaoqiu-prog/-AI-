extends Node
## 全部美术资源在运行时用代码逐像素生成。
## Art.tex(name) -> Texture2D；Art.img(name) -> Image

const T := 16

var _tex := {}
var _img := {}

# ---------------------------------------------------------------- 调色板
const C := {
	"k": "140f14", # 描边
	"h": "231c24", "H": "3a3040", # 头发
	"s": "e2b896", "S": "b88a6a", # 皮肤
	"w": "d6d2c4", "W": "9e9a8e", # 孝服
	"b": "f2f0e8", # 孝带
	"m": "8a7650", # 麻绳
	"p": "34303c", "P": "26222c", # 裤
	"f": "1e1a1e", # 鞋
	"e": "140f14", # 眼
	"v": "f2ece0", "V": "cfc6b2", # 纸白
	"c": "e0607a", # 胭脂
	"r": "b81e2c", "R": "7e1220", # 纸红
	"g": "2f8a5a", "G": "1f5e3e", # 纸绿
	"u": "3a5aa8", "U": "263c78", # 纸蓝
	"y": "d8b040", # 金
	"x": "6a6a72", # 灰发
	"o": "ffffff",
}

func col(k: String) -> Color:
	return Color.html(C[k])

# ---------------------------------------------------------------- 接口
func tex(name: String) -> Texture2D:
	if _tex.has(name):
		return _tex[name]
	var t := ImageTexture.create_from_image(img(name))
	_tex[name] = t
	return t

func img(name: String) -> Image:
	if _img.has(name):
		return _img[name]
	var i: Image = _make(name)
	if i == null:
		push_error("Art: unknown image " + name)
		i = Image.create(8, 8, false, Image.FORMAT_RGBA8)
		i.fill(Color.MAGENTA)
	_img[name] = i
	return i

# ---------------------------------------------------------------- 工具
static func hsh(x: int, y: int, s: int = 0) -> float:
	var n: int = x * 374761393 + y * 668265263 + s * 2147483647
	n = (n ^ (n >> 13)) * 1274126177
	n = n ^ (n >> 16)
	return float(n & 0xFFFF) / 65535.0

static func new_img(w: int, h: int) -> Image:
	return Image.create(w, h, false, Image.FORMAT_RGBA8)

static func px(i: Image, x: int, y: int, c: Color) -> void:
	if x >= 0 and y >= 0 and x < i.get_width() and y < i.get_height():
		if c.a >= 1.0:
			i.set_pixel(x, y, c)
		else:
			i.set_pixel(x, y, i.get_pixel(x, y).blend(c))

static func rect(i: Image, x: int, y: int, w: int, h: int, c: Color) -> void:
	for yy in range(y, y + h):
		for xx in range(x, x + w):
			px(i, xx, yy, c)

static func hline(i: Image, x: int, y: int, w: int, c: Color) -> void:
	rect(i, x, y, w, 1, c)

static func vline(i: Image, x: int, y: int, h: int, c: Color) -> void:
	rect(i, x, y, 1, h, c)

static func ellipse(i: Image, cx: float, cy: float, rx: float, ry: float, c: Color) -> void:
	for yy in range(int(cy - ry) - 1, int(cy + ry) + 2):
		for xx in range(int(cx - rx) - 1, int(cx + rx) + 2):
			var dx := (xx + 0.5 - cx) / rx
			var dy := (yy + 0.5 - cy) / ry
			if dx * dx + dy * dy <= 1.0:
				px(i, xx, yy, c)

## 给所有不透明像素加 1px 描边（只往外描）
static func outline(i: Image, c: Color = Color("140f14")) -> void:
	var w := i.get_width()
	var h := i.get_height()
	var src := i.duplicate()
	for y in h:
		for x in w:
			if src.get_pixel(x, y).a > 0.0:
				continue
			for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				var nx: int = x + d.x
				var ny: int = y + d.y
				if nx >= 0 and ny >= 0 and nx < w and ny < h and src.get_pixel(nx, ny).a > 0.5:
					i.set_pixel(x, y, c)
					break

static func shade(c: Color, f: float) -> Color:
	return Color(c.r * f, c.g * f, c.b * f, c.a)

## 字符画 -> Image
func from_rows(rows: Array, pal: Dictionary = {}) -> Image:
	var w := 0
	for r in rows:
		w = max(w, (r as String).length())
	var i := new_img(w, rows.size())
	for y in rows.size():
		var r: String = rows[y]
		for x in r.length():
			var ch := r[x]
			if ch == "." or ch == " ":
				continue
			var hexs: String = pal.get(ch, C.get(ch, ""))
			if hexs == "":
				continue
			i.set_pixel(x, y, Color.html(hexs))
	return i

# ---------------------------------------------------------------- 分派
func _make(name: String) -> Image:
	if name.begins_with("player_") or name.begins_with("uncle_"):
		return _char_sheet(name)
	if name.begins_with("girl"):
		return _girl(name)
	if name.begins_with("effigy"):
		return _effigy(name)
	if name.begins_with("shadow"):
		return _shadow(int(name.get_slice("_", 1)) if name.contains("_") else 0)
	if name.begins_with("i_"):
		return _icon(name)
	if name.begins_with("light_"):
		return _light(name)
	if has_method("_d_" + name):
		return call("_d_" + name)
	return null

# ================================================================ 角色
const PLAYER_DOWN := [
	"................",
	"................",
	"....kkkkkkkk....",
	"...khhhhhhhhk...",
	"...khhHHhhhhk...",
	"...kbbbbbbbbk...",
	"...khsssssshk...",
	"...kssessessk...",
	"...kSssssssSk...",
	"....kSSssSSk....",
	".....kkSSkk.....",
	"....kwwwwwwk....",
	"...kwwwbbwwwk...",
	"..kwWwwwwwwWwk..",
	"..kwWwwwwwwWwk..",
	"..kWmmmmmmmmWk..",
	"..kwWwwwwwwWwk..",
	"..ksWwwwwwwWsk..",
	"...kwwwwwwwwk...",
	"...kWwwwwwwWk...",
]
const PLAYER_UP := [
	"................",
	"................",
	"....kkkkkkkk....",
	"...khhhhhhhhk...",
	"...khhHhhHhhk...",
	"...kbbbbbbbbk...",
	"...khhhhhhhhk...",
	"...khhhbbhhhk...",
	"...kShhbbhhSk...",
	"....kShbbhSk....",
	".....kkSSkk.....",
	"....kwwwwwwk....",
	"...kwwwwwwwwk...",
	"..kwWwwwwwwWwk..",
	"..kwWwwwwwwWwk..",
	"..kWmmmmmmmmWk..",
	"..kwWwwWwwwWwk..",
	"..ksWwwwwwwWsk..",
	"...kwwwwwwwwk...",
	"...kWwwwwwwWk...",
]
const PLAYER_SIDE := [
	"................",
	"................",
	".....kkkkkk.....",
	"....khhhhhhk....",
	"...khhhHHhhhk...",
	"...kbbbbbbbbk...",
	"...khhhhssssk...",
	"...khhhsssesk...",
	"...khhSsssssk...",
	"....kShSsssk....",
	".....kkSSk......",
	"....kwwwwwk.....",
	"....kwwwwwwk....",
	"...kwWwwwwwk....",
	"...kwWwwwwwk....",
	"...kWmmmmmmk....",
	"...kwWwwwwwk....",
	"...kwWwsswwk....",
	"...kwwwwwwwk....",
	"....kWwwwwk.....",
]
const LEGS_FRONT := [
	["....kppkkppk....", "....kppkkppk....", "....kffkkffk....", ".....kk..kk....."],
	["....kppkkppk....", "....kppk.kffk...", "....kffk..kk....", ".....kk........."],
	["....kppkkppk....", "....kppkkppk....", "....kffkkffk....", ".....kk..kk....."],
	["....kppkkppk....", "...kffk.kppk....", "....kk..kffk....", ".........kk....."],
]
const LEGS_SIDE := [
	[".....kpppk......", ".....kpppk......", ".....kffffk.....", "......kkkk......"],
	["....kpppppk.....", "...kpk...kpk....", "..kffk...kffk...", "...kk.....kk...."],
	[".....kpppk......", ".....kpppk......", ".....kffffk.....", "......kkkk......"],
	["....kpppppk.....", "....kpk.kpk.....", "...kffk.kffk....", "....kk...kk....."],
]

## 角色图集：4 列(帧) x 3 行(下/上/侧)，每帧 16x24
func _char_sheet(name: String) -> Image:
	var pal := {}
	if name.begins_with("uncle_"):
		pal = {"h": "3c3a40", "H": "5a5860", "w": "4a4a52", "W": "343438", "b": "e8e6de", "m": "e8e6de", "p": "2a2830", "s": "c8a080", "S": "9e7458"}
	var sheet := new_img(64, 72)
	var bodies := [PLAYER_DOWN, PLAYER_UP, PLAYER_SIDE]
	for row in 3:
		for f in 4:
			var legs: Array = (LEGS_SIDE if row == 2 else LEGS_FRONT)[f]
			var rows: Array = (bodies[row] as Array).duplicate()
			var bob := 1 if (f == 1 or f == 3) else 0
			if bob == 1:
				rows.pop_front()
				rows.append(rows[rows.size() - 1])
			rows = rows.slice(0, 20)
			rows.append_array(legs)
			var fr := from_rows(rows, pal)
			sheet.blit_rect(fr, Rect2i(0, 0, 16, 24), Vector2i(f * 16, row * 24))
	return sheet

const GIRL := [
	"................",
	"...kk......kk...",
	"..khhk....khhk..",
	"..khhkkkkkkhhk..",
	"...khhhhhhhhk...",
	"...khHhhhhhhk...",
	"...khvvvvvvhk...",
	"...kvvvvvvvvk...",
	"...kvcvvvvcvk...",
	"....kvvrrvvk....",
	".....kkvvkk.....",
	"....krrggrrk....",
	"...krrrggrrrk...",
	"..krRrrggrrRrk..",
	"..krRrrrrrrRrk..",
	"..kggggggggggk..",
	"..krRrrrrrrRrk..",
	"..kvRrrrrrrRvk..",
	"..krRrRrrRrRrk..",
	"..krrrrrrrrrrk..",
	".kRrrrrrrrrrrRk.",
	".kggggggggggggk.",
	"..kkkkkkkkkkkk..",
	"....kk....kk....",
]

## girl / girl_eyes / girl_back
func _girl(name: String) -> Image:
	var rows: Array = GIRL.duplicate()
	if name == "girl_eyes":
		rows[7] = "...kvkevvekvk..."
	elif name == "girl_back":
		rows[6] = "...khhhhhhhhk..."
		rows[7] = "...khhhhhhhhk..."
		rows[8] = "...khhhhhhhhk..."
		rows[9] = "....khhhhhhk...."
	var i := from_rows(rows)
	# 纸面折痕
	for y in range(12, 21):
		if hsh(7, y, 3) > 0.6:
			px(i, 7, y, Color(0, 0, 0, 0.12))
	return i

## 纸扎替身：effigy(林默) / effigy_eyes / effigy_boy(装饰) / effigy_old
func _effigy(name: String) -> Image:
	var rows := [
		"................",
		"................",
		"....kkkkkkkk....",
		"...khhhhhhhhk...",
		"...khhhhhhhhk...",
		"...khvvvvvvhk...",
		"...kvvvvvvvvk...",
		"...kvvvvvvvvk...",
		"...kvcvvvvcvk...",
		"....kvvrrvvk....",
		".....kkvvkk.....",
		"....kuuyyuuk....",
		"...kuuuyyuuuk...",
		"..kuUuuyyuuUuk..",
		"..kuUuuyyuuUuk..",
		"..kuUuuyyuuUuk..",
		"..kvUuuuuuuUvk..",
		"..kuUuuuuuuUuk..",
		"..kuuuuuuuuuuk..",
		"..kUuuuuuuuuUk..",
		"..kyyyyyyyyyyk..",
		"..kkkkkkkkkkkk..",
		"....km....mk....",
		"....kk....kk....",
	]
	var pal := {}
	if name == "effigy_eyes":
		rows[7] = "...kvkevvekvk..."
	if name == "effigy_boy":
		pal = {"u": "2f8a5a", "U": "1f5e3e"}
	if name == "effigy_old":
		pal = {"u": "8a6a9a", "U": "5e4870", "h": "6a6a72"}
	var i := from_rows(rows, pal)
	if name == "effigy" or name == "effigy_eyes":
		# 胸前的名字红条
		rect(i, 7, 12, 2, 8, col("r"))
		for y in [13, 15, 17]:
			px(i, 7, y, col("k"))
			px(i, 8, y + 1, col("k"))
	return i

## 那个东西：16x32，穿寿衣，无脸
func _shadow(frame: int) -> Image:
	var i := new_img(16, 32)
	var robe := Color("1a2140")
	var robe2 := Color("121730")
	var trim := Color("7a6430")
	var voidc := Color("050307")
	var grey := Color("8a8890")
	var sway: int = [0, 1, 0, -1][frame % 4]
	# 发髻
	ellipse(i, 8, 2.5, 2.5, 2, grey)
	ellipse(i, 8, 6, 4, 4, Color("6a6870"))
	# 脸是一团黑
	ellipse(i, 8, 7, 3, 3.2, voidc)
	px(i, 6, 7, Color("8a1818"))
	px(i, 10, 7, Color("8a1818"))
	# 身子（寿衣，下摆渐宽）
	for y in range(10, 31):
		var t := float(y - 10) / 20.0
		var half := 3.0 + t * 3.5
		var cx := 8.0 + sway * t
		for x in range(int(cx - half), int(cx + half) + 1):
			var c := robe if x < cx else robe2
			if abs(x - cx) < 0.6 or y == 30:
				c = trim
			px(i, x, y, c)
	hline(i, 5, 11, 6, trim)
	# 长手臂
	for y in range(12, 26):
		px(i, 3 + (1 if y > 20 else 0), y, robe2)
		px(i, 12 - (1 if y > 20 else 0), y, robe2)
	for y in range(26, 29):
		px(i, 4, y, Color("c8c4bc"))
		px(i, 11, y, Color("c8c4bc"))
		px(i, 3, y + 1, Color("a8a49c"))
		px(i, 12, y + 1, Color("a8a49c"))
	outline(i, Color("000000"))
	return i

# ================================================================ 光照纹理
func _light(name: String) -> Image:
	var s := 128
	var i := new_img(s, s)
	var bands := 7.0
	var bayer := [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5]
	var soft := name == "light_soft"
	for y in s:
		for x in s:
			var dx := (x + 0.5 - s / 2.0) / (s / 2.0)
			var dy := (y + 0.5 - s / 2.0) / (s / 2.0)
			var d := sqrt(dx * dx + dy * dy)
			var v := clampf(1.0 - d, 0.0, 1.0)
			v = pow(v, 1.6)
			if not soft:
				var q := v * bands
				var fl := floorf(q)
				var fr := q - fl
				var th: float = (bayer[(y % 4) * 4 + (x % 4)] + 0.5) / 16.0
				if fr > th:
					fl += 1.0
				v = fl / bands
			i.set_pixel(x, y, Color(1, 1, 1, v))
	return i

# ================================================================ 地图背景
## grid: Array[String]，返回整张地面 + 墙体图
var roof_img: Image

func build_map(grid: Array) -> Image:
	var H := grid.size()
	var W := (grid[0] as String).length()
	var i := new_img(W * T, H * T)
	roof_img = new_img(W * T, H * T)
	for ty in H:
		for tx in W:
			var ch := _g(grid, tx, ty)
			if ch == "#":
				_wall_tile(i, grid, tx, ty)
			else:
				_floor_tile(i, _floor_kind(grid, tx, ty), tx, ty)
	# 屋脊描边：屋顶与地面交界处提亮，夜里也能看清房屋轮廓
	var rim := Color("6a6878")
	for ty in H:
		for tx in W:
			if _g(grid, tx, ty) != "#":
				continue
			for x in T:
				if _g(grid, tx, ty - 1) != "#" and ty > 0:
					roof_img.set_pixel(tx * T + x, ty * T, rim)
			for y in T:
				var yy := ty * T + y
				if roof_img.get_pixel(tx * T, yy).a > 0 and _g(grid, tx - 1, ty) != "#" and tx > 0:
					roof_img.set_pixel(tx * T, yy, rim)
				if roof_img.get_pixel(tx * T + T - 1, yy).a > 0 and _g(grid, tx + 1, ty) != "#" and tx < W - 1:
					roof_img.set_pixel(tx * T + T - 1, yy, rim)
	# 墙脚阴影（地面上紧贴墙的那一行压暗）
	for ty in H:
		for tx in W:
			if _g(grid, tx, ty) != "#" and _g(grid, tx, ty - 1) == "#":
				for x in T:
					px(i, tx * T + x, ty * T, Color(0, 0, 0, 0.45))
					px(i, tx * T + x, ty * T + 1, Color(0, 0, 0, 0.25))
					px(i, tx * T + x, ty * T + 2, Color(0, 0, 0, 0.1))
			if _g(grid, tx, ty) != "#" and _g(grid, tx - 1, ty) == "#":
				for y in T:
					px(i, tx * T, ty * T + y, Color(0, 0, 0, 0.3))
	return i

func _g(grid: Array, x: int, y: int) -> String:
	if y < 0 or y >= grid.size():
		return "#"
	var r: String = grid[y]
	if x < 0 or x >= r.length():
		return "#"
	return r[x]

func _floor_kind(grid: Array, x: int, y: int) -> String:
	var ch := _g(grid, x, y)
	match ch:
		".": return "wood"
		",": return "stone"
		";": return "dirt"
		":": return "slab"
		_:
			# 门洞等：取左右邻居的地面
			for d in [Vector2i(0, 1), Vector2i(0, -1), Vector2i(1, 0), Vector2i(-1, 0)]:
				var n := _g(grid, x + d.x, y + d.y)
				if n in [".", ",", ";", ":"]:
					return _floor_kind(grid, x + d.x, y + d.y)
			return "stone"

func _floor_tile(i: Image, kind: String, tx: int, ty: int) -> void:
	var ox := tx * T
	var oy := ty * T
	match kind:
		"wood":
			var base := [Color("4e3626"), Color("553b29"), Color("4a3224"), Color("5a4030")]
			for p in 4:
				var row := ty * 4 + p
				var seam := int(hsh(row, tx, 11) * 16.0)
				var c: Color = base[int(hsh(row, tx, 5) * 4.0) % 4]
				for y in 4:
					for x in T:
						var cc := c
						if y == 3:
							cc = Color("33231a")
						elif x == seam and hsh(row, tx, 13) > 0.35:
							cc = Color("33231a")
						else:
							var n := hsh(ox + x, oy + p * 4 + y, 2)
							if n > 0.92:
								cc = shade(c, 0.85)
							elif n < 0.05:
								cc = shade(c, 1.12)
							if (x + row * 3) % 7 == 0 and y == 1 and n > 0.5:
								cc = shade(c, 0.9)
						i.set_pixel(ox + x, oy + p * 4 + y, cc)
		"stone":
			for y in T:
				for x in T:
					var gy := oy + y
					var gx := ox + x
					var brow := gy / 4
					var off := 4 if (brow % 2) == 1 else 0
					var bx := (gx + off) / 8
					var c := Color("4e5058")
					var v := hsh(bx, brow, 7)
					c = c.lerp(Color("5c5e66"), v)
					if v > 0.93:
						c = Color("4a4e44")
					var mort := (gy % 4 == 3) or ((gx + off) % 8 == 7)
					if mort:
						c = Color("33353c")
					else:
						var n := hsh(gx, gy, 9)
						if n > 0.9:
							c = shade(c, 1.1)
						elif n < 0.08:
							c = shade(c, 0.88)
						if hsh(gx, gy, 21) > 0.985:
							c = Color("3e4a36")
					i.set_pixel(gx, gy, c)
		"dirt":
			for y in T:
				for x in T:
					var gx := ox + x
					var gy := oy + y
					var n := hsh(gx, gy, 4)
					var big := hsh(gx / 5, gy / 5, 8)
					var c := Color("3a3326").lerp(Color("443b2c"), big)
					if n > 0.94:
						c = Color("5a5040")
					elif n < 0.04:
						c = Color("2c2620")
					i.set_pixel(gx, gy, c)
			# 草丛
			if hsh(tx, ty, 31) > 0.55:
				var gx := ox + int(hsh(tx, ty, 32) * 12.0) + 2
				var gy := oy + int(hsh(tx, ty, 33) * 10.0) + 4
				for k in 4:
					var hgt := 2 + int(hsh(tx, k, 34) * 3.0)
					vline(i, gx + k - 1, gy - hgt, hgt, Color("3c4a2c") if k % 2 == 0 else Color("4c5c34"))
		"slab":
			for y in T:
				for x in T:
					var gx := ox + x
					var gy := oy + y
					var c := Color("34303a").lerp(Color("3c3842"), hsh(tx, ty, 3))
					if x == 0 or y == 0:
						c = Color("26222a")
					var n := hsh(gx, gy, 6)
					if n > 0.95:
						c = shade(c, 1.15)
					i.set_pixel(gx, gy, c)
			if hsh(tx, ty, 40) > 0.7:
				var x0 := ox + 3 + int(hsh(tx, ty, 41) * 8.0)
				var y0 := oy + 3
				for k in 8:
					px(i, x0 + int(sin(k * 1.3) * 1.5), y0 + k, Color("221e26"))

func _wall_tile(i: Image, grid: Array, tx: int, ty: int) -> void:
	var ox := tx * T
	var oy := ty * T
	var south_open := _g(grid, tx, ty + 1) != "#"
	# 屋顶灰瓦
	for y in T:
		for x in T:
			var gx := ox + x
			var gy := oy + y
			var lane := gx % 4
			var c := Color("2a2832")
			if lane == 0:
				c = Color("1c1a22")
			elif lane == 1 or lane == 2:
				c = Color("34323d")
				if (gy + (gx / 4) * 2) % 5 == 0:
					c = Color("24222a")
			var n := hsh(gx, gy, 17)
			if n > 0.96:
				c = Color("3e3c48")
			if not south_open or y < 5:
				roof_img.set_pixel(gx, gy, c)
	if not south_open:
		return
	# 檐口 + 墙面
	var cap := 5
	for x in T:
		var gx := ox + x
		for y in range(cap, T):
			var gy := oy + y
			var c := Color("8a857a")
			var n := hsh(gx, gy, 23)
			c = c.lerp(Color("948f84"), hsh(gx / 3, gy / 4, 24))
			if n > 0.93:
				c = Color("6e6a60")
			# 霉斑/水渍从上往下流
			if hsh(gx, 0, 25) > 0.82 and y < 9 + int(hsh(gx, 1, 26) * 5):
				c = shade(c, 0.86)
			if y >= T - 3:
				c = Color("4a4448") if (gx + (1 if y == T - 2 else 0) * 4) % 8 != 0 else Color("38343a")
				if y == T - 3:
					c = Color("5a5458")
			i.set_pixel(gx, gy, c)
		# 瓦当
		var e := Color("1a1820")
		roof_img.set_pixel(gx, oy + cap - 1, e)
		i.set_pixel(gx, oy + cap, Color("3a3844") if gx % 4 != 0 else e)
		if gx % 4 == 1 or gx % 4 == 2:
			i.set_pixel(gx, oy + cap + 1, Color("2c2a34"))
		i.set_pixel(gx, oy + cap + 2, Color(0, 0, 0, 0.35))

## 在墙面上画窗户（world 调用）
func draw_window(i: Image, tx: int, ty: int, lit: bool) -> void:
	var ox := tx * T + 3
	var oy := ty * T + 7
	var fr := Color("3a281c")
	var paper := Color("e8c27a") if lit else Color("6a665c")
	rect(i, ox, oy, 10, 7, fr)
	rect(i, ox + 1, oy + 1, 8, 5, paper)
	for k in [3, 6]:
		vline(i, ox + k, oy + 1, 5, fr)
	hline(i, ox + 1, oy + 3, 8, fr)
	if lit:
		px(i, ox + 2, oy + 2, Color("f4dca0"))
		px(i, ox + 7, oy + 4, Color("c89850"))

# ================================================================ 家具与物件
func _d_coffin() -> Image:
	var i := new_img(36, 22)
	var lid := Color("2a2226")
	var lidh := Color("3a3036")
	var side := Color("1a1416")
	# 长凳
	for bx in [7, 26]:
		rect(i, bx, 16, 3, 6, Color("4a3020"))
		rect(i, bx - 1, 15, 5, 2, Color("5c3c28"))
	# 侧面
	for x in range(3, 34):
		var t := float(x - 3) / 31.0
		var top := int(lerpf(12, 11, t))
		var bot := int(lerpf(18, 16, t))
		for y in range(top, bot):
			px(i, x, y, side)
	# 棺盖
	for x in range(2, 34):
		var t := float(x - 2) / 32.0
		var top := int(lerpf(2, 4, t))
		var bot := int(lerpf(12, 11, t))
		for y in range(top, bot):
			var c := lid
			if y == top:
				c = lidh
			elif y == top + 1 and x % 6 != 0:
				c = Color("332a2e")
			px(i, x, y, c)
	# 棺头
	rect(i, 0, 1, 4, 18, Color("221a1c"))
	rect(i, 1, 2, 2, 16, Color("2e2428"))
	ellipse(i, 2, 10, 1.6, 3.5, Color("b89838"))
	px(i, 2, 10, Color("8a1c1c"))
	px(i, 2, 9, Color("8a1c1c"))
	# 盖上的红布条
	for x in range(10, 26):
		px(i, x, 6, Color("7a1418"))
		px(i, x, 7, Color("9a2024"))
	outline(i)
	return i

func _d_coffin_open() -> Image:
	var i: Image = _d_coffin().duplicate()
	# 棺盖滑开一截，露出黑洞
	for x in range(18, 34):
		for y in range(3, 11):
			i.set_pixel(x, y, Color("050305"))
	for x in range(20, 36):
		px(i, x, 1, Color("3a3036"))
		px(i, x, 2, Color("2a2226"))
	return i

func _d_altar() -> Image:
	var i := new_img(40, 26)
	var wood := Color("5a1e18")
	var woodh := Color("7a2a20")
	# 桌面
	rect(i, 0, 8, 40, 4, woodh)
	hline(i, 0, 8, 40, Color("8e3828"))
	# 白布幔
	for x in range(1, 39):
		var drop := 22 + (1 if (x / 3) % 2 == 0 else 0)
		for y in range(12, drop):
			var c := Color("dedad0")
			if (x % 6) == 0:
				c = Color("bcb8ae")
			px(i, x, y, c)
	# 布上的黑色"奠"字简化
	rect(i, 17, 14, 6, 1, Color("1a1416"))
	rect(i, 19, 13, 2, 7, Color("1a1416"))
	rect(i, 17, 17, 6, 1, Color("1a1416"))
	px(i, 17, 19, Color("1a1416"))
	px(i, 22, 19, Color("1a1416"))
	# 桌腿
	rect(i, 1, 12, 2, 13, wood)
	rect(i, 37, 12, 2, 13, wood)
	# 香炉
	rect(i, 17, 4, 6, 4, Color("8a7030"))
	hline(i, 16, 4, 8, Color("a88a40"))
	for k in 3:
		vline(i, 18 + k * 2, 0, 4, Color("6a4a30"))
		px(i, 18 + k * 2, 0, Color("e05020"))
	# 倒头饭：碗里插一双筷子
	rect(i, 27, 5, 5, 3, Color("d8d4c8"))
	hline(i, 27, 5, 5, Color("f4f2ea"))
	vline(i, 28, 1, 4, Color("6a4428"))
	vline(i, 30, 1, 4, Color("6a4428"))
	# 果盘
	ellipse(i, 9, 6.5, 3.5, 1.5, Color("c8c0b0"))
	ellipse(i, 8, 5, 1.5, 1.5, Color("c8902a"))
	ellipse(i, 10.5, 5, 1.5, 1.5, Color("b8402a"))
	outline(i)
	return i

func _d_portrait() -> Image:
	var i := new_img(14, 18)
	rect(i, 0, 3, 14, 15, Color("141014"))
	rect(i, 2, 5, 10, 11, Color("8a8682"))
	# 照片里的老人
	ellipse(i, 7, 9, 3, 3.5, Color("b0aaa0"))
	ellipse(i, 7, 6.5, 3.5, 2, Color("d8d6d2"))
	px(i, 6, 9, Color("3a3836"))
	px(i, 8, 9, Color("3a3836"))
	hline(i, 6, 11, 3, Color("6a6662"))
	rect(i, 3, 13, 8, 3, Color("4a4846"))
	# 黑纱花
	ellipse(i, 7, 2, 3, 2, Color("1e1a1e"))
	px(i, 3, 3, Color("1e1a1e"))
	px(i, 11, 3, Color("1e1a1e"))
	return i

func _d_portrait_turned() -> Image:
	var i := new_img(14, 18)
	rect(i, 0, 3, 14, 15, Color("3a2a1e"))
	rect(i, 1, 4, 12, 13, Color("4e3a28"))
	vline(i, 7, 4, 13, Color("2e2016"))
	ellipse(i, 7, 2, 3, 2, Color("1e1a1e"))
	return i

func _d_candle() -> Image:
	var i := new_img(5, 11)
	rect(i, 1, 2, 3, 7, Color("e8e4da"))
	vline(i, 3, 2, 7, Color("bcb6aa"))
	px(i, 2, 1, Color("2a2224"))
	rect(i, 0, 9, 5, 2, Color("8a7030"))
	outline(i)
	return i

func _d_lamp() -> Image:
	# 长明灯：铜灯盏
	var i := new_img(9, 9)
	ellipse(i, 4.5, 3.5, 4, 1.6, Color("a8843a"))
	hline(i, 1, 3, 7, Color("3a2a10"))
	hline(i, 2, 3, 5, Color("5a3a10"))
	rect(i, 4, 5, 1, 2, Color("8a6a2a"))
	rect(i, 2, 7, 5, 2, Color("8a6a2a"))
	hline(i, 2, 7, 5, Color("b8944a"))
	outline(i)
	return i

func _d_handlamp() -> Image:
	var i := new_img(6, 7)
	rect(i, 1, 3, 4, 3, Color("8a6a2a"))
	hline(i, 0, 3, 6, Color("b8944a"))
	px(i, 2, 6, Color("6a4a1a"))
	px(i, 3, 6, Color("6a4a1a"))
	vline(i, 0, 0, 3, Color("4a3a20"))
	hline(i, 0, 0, 3, Color("4a3a20"))
	return i

func _d_flame0() -> Image:
	return from_rows(["..o..", ".oyo.", ".yry.", "..r.."], {"o": "fff4c0", "y": "ffc040", "r": "e05018"})

func _d_flame1() -> Image:
	return from_rows([".o...", ".oy..", ".yry.", "..r.."], {"o": "fff4c0", "y": "ffc040", "r": "e05018"})

func _d_wreath() -> Image:
	var i := new_img(18, 26)
	# 三脚架
	for k in 3:
		var bx: int = [3, 9, 14][k]
		for y in range(14, 26):
			px(i, bx + (y - 14) / 4 * (k - 1), y, Color("6a5030"))
	# 花环
	for a in 40:
		var ang := a / 40.0 * TAU
		var cx := 9.0 + cos(ang) * 6.0
		var cy := 9.0 + sin(ang) * 6.0
		var c: Color = [Color("f0eee8"), Color("dcdad4"), Color("c8d4e8"), Color("e8e0b8")][a % 4]
		ellipse(i, cx, cy, 1.8, 1.8, c)
	ellipse(i, 9, 9, 3.3, 3.3, Color("141014"))
	# 白字"奠"示意
	vline(i, 9, 7, 4, Color("e8e6de"))
	hline(i, 7, 8, 5, Color("e8e6de"))
	# 挽联飘带
	for y in range(13, 24):
		px(i, 4 - (y - 13) / 5, y, Color("e8e6de"))
		px(i, 14 + (y - 13) / 5, y, Color("e8e6de"))
	outline(i)
	return i

func _d_banner() -> Image:
	var i := new_img(9, 30)
	vline(i, 1, 0, 30, Color("6a5a38"))
	for y in range(2, 26):
		var w := 5 + (1 if (y / 3) % 2 == 0 else 0)
		for x in range(2, 2 + w):
			var c := Color("e8e6dc") if x < 6 else Color("c8c6bc")
			px(i, x, y, c)
	for x in range(2, 8):
		if x % 2 == 0:
			for y in range(26, 29):
				px(i, x, y, Color("d8d6cc"))
	outline(i)
	return i

func _d_money() -> Image:
	var i := new_img(16, 16)
	for k in 7:
		var x := int(hsh(k, 1, 50) * 13.0)
		var y := int(hsh(k, 2, 50) * 13.0)
		var c := Color("d8c890") if k % 2 == 0 else Color("e8e0c0")
		if k % 3 == 0:
			ellipse(i, x + 1.5, y + 1.5, 1.6, 1.6, c)
			px(i, x + 1, y + 1, Color("8a7a50"))
		else:
			rect(i, x, y, 3, 2, c)
	return i

func _d_bed() -> Image:
	var i := new_img(34, 34)
	var wood := Color("4a2418")
	var woodh := Color("6a3424")
	# 架子床顶
	rect(i, 0, 0, 34, 4, wood)
	hline(i, 0, 0, 34, woodh)
	for x in range(2, 32, 4):
		px(i, x, 2, Color("8a5a30"))
	# 立柱
	rect(i, 0, 4, 2, 30, wood)
	rect(i, 32, 4, 2, 30, wood)
	# 帐子
	for y in range(4, 12):
		for x in range(2, 32):
			var c := Color("44506a") if (x / 2) % 2 == 0 else Color("3a4560")
			if y > 9:
				c = shade(c, 0.85)
			px(i, x, y, c)
	# 床铺/被子
	rect(i, 2, 12, 30, 16, Color("2a1a14"))
	rect(i, 4, 13, 26, 13, Color("6a2a2a"))
	for y in range(13, 26):
		for x in range(4, 30):
			if (x + y) % 6 == 0:
				px(i, x, y, Color("7e3a32"))
	rect(i, 4, 13, 8, 4, Color("d8d0c0"))
	hline(i, 4, 17, 26, Color("4a1a1a"))
	# 床沿
	rect(i, 2, 28, 30, 6, wood)
	hline(i, 2, 28, 30, woodh)
	rect(i, 6, 30, 8, 2, Color("3a1a10"))
	rect(i, 20, 30, 8, 2, Color("3a1a10"))
	outline(i)
	return i

func _d_bed_small() -> Image:
	var i := new_img(26, 24)
	var wood := Color("5a3a24")
	rect(i, 0, 2, 26, 22, wood)
	hline(i, 0, 2, 26, Color("7a5434"))
	rect(i, 2, 4, 22, 14, Color("c88a9a"))
	for y in range(4, 18):
		for x in range(2, 24):
			if (x * 3 + y * 2) % 7 == 0:
				px(i, x, y, Color("e8b0b8"))
	rect(i, 3, 5, 7, 4, Color("e8e2d4"))
	rect(i, 2, 18, 22, 4, Color("4a2e1c"))
	# 一只布老虎
	rect(i, 14, 7, 5, 3, Color("d8902a"))
	px(i, 15, 8, Color("1a1416"))
	outline(i)
	return i

func _d_wardrobe() -> Image:
	var i := new_img(18, 28)
	var wood := Color("4e2016")
	var woodh := Color("6a2e20")
	rect(i, 0, 0, 18, 28, wood)
	rect(i, 0, 0, 18, 3, woodh)
	hline(i, 0, 0, 18, Color("8a4230"))
	rect(i, 2, 4, 6, 20, Color("5a261a"))
	rect(i, 10, 4, 6, 20, Color("5a261a"))
	vline(i, 9, 4, 20, Color("2a0e0a"))
	for door in [2, 10]:
		rect(i, door + 1, 6, 4, 5, Color("4a1c12"))
		rect(i, door + 1, 14, 4, 8, Color("4a1c12"))
	px(i, 7, 13, Color("c8a040"))
	px(i, 10, 13, Color("c8a040"))
	rect(i, 0, 24, 18, 4, Color("3a160e"))
	rect(i, 1, 26, 2, 2, Color("2a0e0a"))
	rect(i, 15, 26, 2, 2, Color("2a0e0a"))
	outline(i)
	return i

func _d_table() -> Image:
	var i := new_img(22, 16)
	rect(i, 0, 0, 22, 8, Color("5a3420"))
	hline(i, 0, 0, 22, Color("7a4a2e"))
	rect(i, 0, 8, 22, 2, Color("3e2214"))
	rect(i, 1, 10, 2, 6, Color("3e2214"))
	rect(i, 19, 10, 2, 6, Color("3e2214"))
	# 茶壶茶碗
	ellipse(i, 8, 4, 2.5, 2, Color("c8c4b8"))
	px(i, 11, 4, Color("c8c4b8"))
	ellipse(i, 14, 5, 1.2, 1, Color("d8d4c8"))
	outline(i)
	return i

func _d_chair() -> Image:
	var i := new_img(10, 14)
	rect(i, 1, 0, 8, 6, Color("4a2a18"))
	rect(i, 2, 1, 6, 4, Color("5e3620"))
	rect(i, 0, 6, 10, 3, Color("6a3e24"))
	rect(i, 0, 9, 2, 5, Color("3a2014"))
	rect(i, 8, 9, 2, 5, Color("3a2014"))
	outline(i)
	return i

func _d_desk() -> Image:
	var i := new_img(26, 16)
	rect(i, 0, 0, 26, 7, Color("5a3a24"))
	hline(i, 0, 0, 26, Color("7a5434"))
	rect(i, 0, 7, 26, 3, Color("3e2618"))
	rect(i, 2, 8, 8, 1, Color("8a6a40"))
	rect(i, 1, 10, 2, 6, Color("3e2618"))
	rect(i, 23, 10, 2, 6, Color("3e2618"))
	# 砚台和纸
	rect(i, 3, 2, 4, 3, Color("1e1c22"))
	rect(i, 10, 1, 8, 5, Color("e0d8c4"))
	for y in [2, 4]:
		hline(i, 11, y, 5, Color("4a4448"))
	outline(i)
	return i

func _d_dresser() -> Image:
	var i := new_img(18, 26)
	rect(i, 0, 12, 18, 14, Color("5a2a1c"))
	hline(i, 0, 12, 18, Color("7a3e2a"))
	rect(i, 2, 15, 14, 4, Color("4a2014"))
	px(i, 9, 17, Color("c8a040"))
	rect(i, 2, 20, 14, 4, Color("4a2014"))
	px(i, 9, 22, Color("c8a040"))
	# 镜框
	ellipse(i, 9, 6, 6, 6, Color("6a3a20"))
	# 盖镜白布
	for y in range(0, 14):
		for x in range(3, 15):
			var dx := x - 9.0
			if y < 2 and abs(dx) > 3:
				continue
			var c := Color("e4e0d6") if (x + y / 3) % 4 != 0 else Color("c8c4ba")
			px(i, x, y, c)
	outline(i)
	return i

func _d_dresser_open() -> Image:
	var i := new_img(18, 26)
	rect(i, 0, 12, 18, 14, Color("5a2a1c"))
	hline(i, 0, 12, 18, Color("7a3e2a"))
	rect(i, 2, 15, 14, 4, Color("4a2014"))
	px(i, 9, 17, Color("c8a040"))
	rect(i, 2, 20, 14, 4, Color("4a2014"))
	px(i, 9, 22, Color("c8a040"))
	ellipse(i, 9, 6, 6, 6, Color("6a3a20"))
	ellipse(i, 9, 6, 5, 5, Color("3a4450"))
	ellipse(i, 7.5, 4.5, 1.5, 2, Color("6a7888"))
	px(i, 11, 8, Color("8a98a8"))
	# 布掉在地上
	rect(i, 13, 23, 6, 3, Color("d8d4ca"))
	outline(i)
	return i

func _d_stove() -> Image:
	var i := new_img(34, 24)
	var brick := Color("6a4a3a")
	rect(i, 0, 4, 34, 20, brick)
	for y in range(4, 24):
		for x in 34:
			if y % 4 == 3 or (x + (4 if (y / 4) % 2 == 0 else 0)) % 8 == 7:
				px(i, x, y, Color("4a3228"))
	rect(i, 0, 4, 34, 8, Color("7a6a5a"))
	hline(i, 0, 4, 34, Color("8e7e6e"))
	ellipse(i, 9, 8, 6, 3, Color("1a1618"))
	ellipse(i, 25, 8, 6, 3, Color("1a1618"))
	ellipse(i, 9, 7.5, 4, 1.5, Color("2a2628"))
	# 灶膛
	rect(i, 6, 16, 7, 6, Color("120a08"))
	px(i, 8, 20, Color("a83010"))
	px(i, 10, 21, Color("e05018"))
	rect(i, 22, 16, 7, 6, Color("120a08"))
	# 烟囱
	rect(i, 30, 0, 4, 6, Color("5a4034"))
	outline(i)
	return i

func _d_vat() -> Image:
	var i := new_img(16, 16)
	ellipse(i, 8, 9, 7, 6.5, Color("5a3a24"))
	ellipse(i, 6, 8, 3, 4, Color("6e4a30"))
	ellipse(i, 8, 4, 6, 2.5, Color("3a2416"))
	ellipse(i, 8, 4, 4.5, 1.5, Color("1a2630"))
	px(i, 6, 4, Color("4a6070"))
	outline(i)
	return i

func _d_oilvat() -> Image:
	var i := new_img(16, 16)
	ellipse(i, 8, 9, 7, 6.5, Color("6a4a20"))
	ellipse(i, 6, 8, 3, 4, Color("8a6430"))
	ellipse(i, 8, 4, 6, 2.5, Color("7a5a34"))
	hline(i, 3, 4, 10, Color("5a4024"))
	# 木勺
	vline(i, 11, 0, 5, Color("a88a5a"))
	ellipse(i, 11, 4, 1.5, 1, Color("8a6a40"))
	# 红纸"油"
	rect(i, 6, 9, 4, 4, Color("a82020"))
	px(i, 7, 10, Color("e0c060"))
	px(i, 8, 11, Color("e0c060"))
	outline(i)
	return i

func _d_firewood() -> Image:
	var i := new_img(20, 14)
	for row in 3:
		for k in 4 - row:
			var cx := 4.0 + k * 4.0 + row * 2.0
			var cy := 11.0 - row * 3.5
			ellipse(i, cx, cy, 2.2, 2.2, Color("6a4a2a"))
			ellipse(i, cx, cy, 1.2, 1.2, Color("a88050"))
			px(i, int(cx), int(cy), Color("6a4a2a"))
	outline(i)
	return i

func _d_shelf() -> Image:
	var i := new_img(18, 26)
	var wood := Color("4a3020")
	rect(i, 0, 0, 2, 26, wood)
	rect(i, 16, 0, 2, 26, wood)
	for y in [0, 8, 16, 24]:
		rect(i, 0, y, 18, 2, Color("6a4a30"))
	# 瓶瓶罐罐
	var cols := [Color("8a7a5a"), Color("4a5a6a"), Color("6a3a2a"), Color("c8c0a8")]
	for sh in 3:
		for k in 3:
			var c: Color = cols[int(hsh(sh, k, 60) * 4.0) % 4]
			var hh := 3 + int(hsh(sh, k, 61) * 3.0)
			rect(i, 3 + k * 4, sh * 8 + 8 - hh, 3, hh, c)
	outline(i)
	return i

func _d_well() -> Image:
	var i := new_img(24, 26)
	# 井架
	vline(i, 2, 0, 16, Color("5a4028"))
	vline(i, 21, 0, 16, Color("5a4028"))
	hline(i, 1, 1, 22, Color("6a4a30"))
	vline(i, 12, 2, 6, Color("8a7a5a"))
	rect(i, 10, 7, 5, 4, Color("5a4a34"))
	# 井沿
	ellipse(i, 12, 17, 11, 7, Color("5a5c62"))
	ellipse(i, 12, 16, 11, 6, Color("6a6c72"))
	ellipse(i, 12, 16, 7.5, 3.5, Color("08080a"))
	ellipse(i, 12, 17, 5, 2, Color("101418"))
	for x in range(1, 23, 3):
		px(i, x, 20, Color("44464c"))
	outline(i)
	return i

func _d_tree() -> Image:
	var i := new_img(64, 72)
	# 树干
	for y in range(30, 72):
		var w := 4.0 + (y - 30) * 0.04
		if y > 64:
			w += (y - 64) * 0.9
		for x in range(int(32 - w), int(32 + w) + 1):
			var c := Color("2a2018") if x < 32 else Color("1e1612")
			if hsh(x, y, 70) > 0.85:
				c = Color("3a2e22")
			px(i, x, y, c)
	# 枝杈
	for k in 4:
		var sx := 32
		var sy := 40 - k * 4
		var dir := -1 if k % 2 == 0 else 1
		for t in 14:
			px(i, sx + dir * t, sy - t / 2, Color("241a14"))
			px(i, sx + dir * t, sy - t / 2 + 1, Color("241a14"))
	# 树冠：深墨绿，块状
	var blobs := [[32, 22, 22, 15], [18, 28, 12, 9], [46, 27, 13, 10], [26, 12, 12, 9], [40, 13, 11, 8], [32, 32, 16, 7]]
	for b in blobs:
		ellipse(i, b[0], b[1], b[2], b[3], Color("16201a"))
	for b in blobs:
		ellipse(i, b[0] - 2, b[1] - 3, b[2] * 0.7, b[3] * 0.6, Color("1e2c22"))
	for y in 72:
		for x in 64:
			var c := i.get_pixel(x, y)
			if c.a > 0 and y < 42 and hsh(x, y, 71) > 0.9:
				i.set_pixel(x, y, Color("2a3a2c"))
			if c.a > 0 and y < 42 and hsh(x / 2, y / 2, 72) > 0.94:
				i.set_pixel(x, y, Color("0e1410"))
	# 挂着的白布条
	for y in range(30, 40):
		px(i, 14, y, Color("d8d6cc"))
		px(i, 50, y + 2, Color("d8d6cc"))
	outline(i, Color("08080a"))
	return i

func _d_horse() -> Image:
	var i := new_img(26, 22)
	var white := Color("eee8da")
	var red := Color("b81e2c")
	rect(i, 5, 7, 14, 7, white)
	rect(i, 17, 2, 4, 8, white)
	rect(i, 18, 0, 6, 4, white)
	px(i, 22, 1, Color("1a1416"))
	for x in [6, 9, 15, 18]:
		vline(i, x, 14, 7, white)
	rect(i, 8, 7, 8, 3, red)
	hline(i, 5, 10, 14, Color("2f8a5a"))
	for y in range(4, 10):
		px(i, 16, y, Color("1a1416"))
	vline(i, 4, 7, 6, Color("1a1416"))
	rect(i, 2, 20, 22, 2, Color("6a5030"))
	outline(i)
	return i

func _d_stand() -> Image:
	var i := new_img(16, 24)
	rect(i, 2, 22, 12, 2, Color("6a5030"))
	vline(i, 7, 6, 16, Color("8a7048"))
	vline(i, 8, 6, 16, Color("6a5030"))
	hline(i, 3, 8, 10, Color("8a7048"))
	# 红标签"满"
	rect(i, 10, 12, 5, 7, Color("a82020"))
	hline(i, 11, 14, 3, Color("e8d080"))
	vline(i, 12, 13, 5, Color("e8d080"))
	hline(i, 11, 16, 3, Color("e8d080"))
	outline(i)
	return i

func _d_tablets() -> Image:
	var i := new_img(36, 28)
	var wood := Color("3a1410")
	rect(i, 0, 14, 36, 14, wood)
	rect(i, 2, 8, 32, 6, Color("4a1a14"))
	hline(i, 0, 14, 36, Color("6a2a1c"))
	hline(i, 2, 8, 32, Color("6a2a1c"))
	for k in 7:
		var x := 3 + k * 4 + (0 if k != 3 else 0)
		var hh := 9 if k == 3 else 7
		var by := 14 if k % 2 == 0 else 8
		rect(i, x, by - hh, 3, hh, Color("141014"))
		vline(i, x + 1, by - hh + 1, hh - 2, Color("c8a040"))
		px(i, x + 1, by - hh, Color("c8a040"))
	# 新的一块红布盖着（奶奶）
	rect(i, 15, 3, 5, 5, Color("a82020"))
	# 供碗
	ellipse(i, 8, 19, 3, 1.5, Color("c8c4b8"))
	ellipse(i, 28, 19, 3, 1.5, Color("c8c4b8"))
	rect(i, 16, 17, 4, 3, Color("8a7030"))
	outline(i)
	return i

func _d_musicbox() -> Image:
	var i := new_img(10, 8)
	rect(i, 0, 2, 10, 6, Color("8a3a3a"))
	rect(i, 0, 0, 10, 3, Color("a84a48"))
	hline(i, 0, 2, 10, Color("e0c060"))
	px(i, 5, 5, Color("e0c060"))
	outline(i)
	return i

func _d_lantern() -> Image:
	var i := new_img(12, 18)
	vline(i, 6, 0, 3, Color("3a3030"))
	rect(i, 3, 2, 7, 2, Color("2a2224"))
	ellipse(i, 6.5, 9, 5.5, 6, Color("ece8dc"))
	for y in range(4, 15):
		if y % 3 == 0:
			hline(i, 2, y, 10, Color("c8c4b8"))
	vline(i, 6, 7, 5, Color("1a1416"))
	hline(i, 4, 8, 6, Color("1a1416"))
	rect(i, 3, 14, 7, 2, Color("2a2224"))
	vline(i, 6, 16, 2, Color("e8e6dc"))
	outline(i)
	return i

func _d_lantern_big() -> Image:
	var i := new_img(44, 64)
	vline(i, 22, 0, 6, Color("3a3030"))
	rect(i, 12, 5, 21, 4, Color("2a2224"))
	ellipse(i, 22.5, 30, 18, 21, Color("ece8dc"))
	for y in range(10, 52):
		if y % 5 == 0:
			for x in 44:
				if i.get_pixel(x, y).a > 0:
					px(i, x, y, Color("c8c4b8"))
	for x in 44:
		for y in 64:
			var c := i.get_pixel(x, y)
			if c.a > 0 and x > 30:
				i.set_pixel(x, y, shade(c, 0.85))
	# 奠
	var k := Color("1a1416")
	hline(i, 15, 20, 15, k)
	vline(i, 19, 17, 3, k)
	vline(i, 26, 17, 3, k)
	rect(i, 16, 23, 13, 9, k)
	rect(i, 18, 25, 9, 5, Color("ece8dc"))
	hline(i, 18, 27, 9, k)
	vline(i, 22, 23, 9, k)
	hline(i, 13, 35, 19, k)
	for t in 6:
		px(i, 21 - t, 36 + t, k)
		px(i, 24 + t, 36 + t, k)
	rect(i, 12, 51, 21, 4, Color("2a2224"))
	for x in range(15, 31, 3):
		vline(i, x, 55, 6, Color("a82020"))
	outline(i)
	return i

func _d_door_h() -> Image:
	var i := new_img(16, 16)
	rect(i, 1, 4, 14, 12, Color("4a2418"))
	rect(i, 1, 4, 14, 2, Color("2e140c"))
	vline(i, 8, 5, 11, Color("2a1008"))
	for x in [3, 11]:
		rect(i, x, 7, 3, 3, Color("3a1a10"))
		rect(i, x, 12, 3, 3, Color("3a1a10"))
	px(i, 6, 10, Color("c8a040"))
	px(i, 9, 10, Color("c8a040"))
	vline(i, 0, 4, 12, Color("1a0e08"))
	vline(i, 15, 4, 12, Color("1a0e08"))
	return i

func _d_door_h_open() -> Image:
	var i := new_img(16, 16)
	rect(i, 1, 4, 14, 12, Color("0a0708"))
	rect(i, 1, 4, 2, 12, Color("4a2418"))
	rect(i, 13, 4, 2, 12, Color("4a2418"))
	vline(i, 0, 4, 12, Color("1a0e08"))
	vline(i, 15, 4, 12, Color("1a0e08"))
	return i

func _d_door_v() -> Image:
	var i := new_img(16, 16)
	rect(i, 5, 0, 6, 16, Color("4a2418"))
	vline(i, 5, 0, 16, Color("2a1008"))
	vline(i, 10, 0, 16, Color("2a1008"))
	px(i, 8, 8, Color("c8a040"))
	return i

func _d_door_v_open() -> Image:
	var i := new_img(16, 16)
	rect(i, 5, 0, 6, 2, Color("4a2418"))
	rect(i, 5, 14, 6, 2, Color("4a2418"))
	return i

func _d_gate() -> Image:
	var i := new_img(32, 16)
	rect(i, 0, 2, 32, 14, Color("5a1410"))
	rect(i, 0, 2, 32, 2, Color("2a0806"))
	vline(i, 16, 2, 14, Color("1a0404"))
	for y in [6, 9, 12]:
		for x in range(3, 30, 4):
			if x != 15 and x != 17:
				px(i, x, y, Color("b8943a"))
	ellipse(i, 13, 9, 1.5, 1.5, Color("c8a040"))
	ellipse(i, 19, 9, 1.5, 1.5, Color("c8a040"))
	# 门上贴的白纸
	rect(i, 5, 4, 4, 6, Color("e8e6dc"))
	rect(i, 23, 4, 4, 6, Color("e8e6dc"))
	return i

func _d_backgate() -> Image:
	var i := new_img(16, 16)
	rect(i, 1, 3, 14, 13, Color("3a2a20"))
	for x in [4, 8, 12]:
		vline(i, x, 3, 13, Color("2a1c14"))
	hline(i, 1, 8, 14, Color("5a4a3a"))
	hline(i, 1, 9, 14, Color("2a1c14"))
	# 横木门闩
	rect(i, 0, 10, 16, 2, Color("6a5038"))
	return i

func _d_backgate_open() -> Image:
	var i := new_img(16, 16)
	rect(i, 1, 3, 14, 13, Color("c8c8d0"))
	for y in range(3, 16):
		for x in range(1, 15):
			if hsh(x, y, 90) > 0.6:
				px(i, x, y, Color("e0e0e8"))
	rect(i, 1, 3, 2, 13, Color("3a2a20"))
	rect(i, 13, 3, 2, 13, Color("3a2a20"))
	return i

func _d_seal() -> Image:
	var i := new_img(6, 12)
	rect(i, 0, 0, 6, 12, Color("e0c050"))
	for y in range(1, 11):
		px(i, 2 + (y % 3) - 1, y, Color("b82020"))
	hline(i, 1, 3, 4, Color("b82020"))
	hline(i, 1, 8, 4, Color("b82020"))
	return i

func _d_seal_torn() -> Image:
	var i := new_img(6, 12)
	rect(i, 0, 0, 6, 4, Color("e0c050"))
	rect(i, 0, 9, 6, 3, Color("e0c050"))
	px(i, 2, 1, Color("b82020"))
	return i

func _d_footprint() -> Image:
	var i := new_img(5, 7)
	var c := Color(0.1, 0.16, 0.2, 0.6)
	ellipse(i, 2.5, 2.5, 2, 2.5, c)
	ellipse(i, 2.5, 6, 1.5, 1.2, c)
	return i

func _d_jar() -> Image:
	var i := new_img(9, 11)
	ellipse(i, 4.5, 6.5, 4, 4, Color("7a5a34"))
	ellipse(i, 3.5, 6, 1.5, 2.5, Color("9a7444"))
	rect(i, 3, 1, 3, 2, Color("5a4024"))
	rect(i, 2, 0, 5, 1, Color("c8b890"))
	rect(i, 3, 6, 3, 3, Color("a82020"))
	outline(i)
	return i

func _d_brush() -> Image:
	var i := new_img(4, 12)
	vline(i, 1, 0, 9, Color("8a6a3a"))
	vline(i, 2, 0, 9, Color("6a4a2a"))
	rect(i, 1, 9, 2, 3, Color("1a1416"))
	px(i, 1, 11, Color("1a1416"))
	outline(i)
	return i

func _d_bowl_red() -> Image:
	var i := new_img(10, 6)
	ellipse(i, 5, 3, 4.5, 2.5, Color("d8d4c8"))
	ellipse(i, 5, 2, 3.5, 1.2, Color("c81818"))
	outline(i)
	return i

func _d_page() -> Image:
	var i := new_img(9, 7)
	rect(i, 0, 0, 9, 7, Color("e0d6bc"))
	for y in [2, 4]:
		hline(i, 1, y, 6, Color("5a5048"))
	px(i, 8, 0, Color(0, 0, 0, 0))
	outline(i)
	return i

func _d_photo() -> Image:
	var i := new_img(8, 6)
	rect(i, 0, 0, 8, 6, Color("d8d0b8"))
	rect(i, 1, 1, 6, 4, Color("7a7068"))
	px(i, 2, 2, Color("d8d0b8"))
	px(i, 5, 2, Color("d8d0b8"))
	outline(i)
	return i

func _d_lock() -> Image:
	var i := new_img(8, 9)
	rect(i, 1, 3, 6, 6, Color("8a7a40"))
	hline(i, 1, 3, 6, Color("b8a050"))
	vline(i, 2, 0, 3, Color("6a6060"))
	vline(i, 5, 0, 3, Color("6a6060"))
	hline(i, 2, 0, 4, Color("6a6060"))
	rect(i, 3, 5, 2, 2, Color("2a2420"))
	outline(i)
	return i

func _d_cloth_rag() -> Image:
	var i := new_img(12, 6)
	ellipse(i, 6, 3, 6, 2.5, Color("d8d4ca"))
	outline(i)
	return i

func _d_paper_pile() -> Image:
	# 扎纸铺地上的彩纸、竹篾
	var i := new_img(20, 12)
	var cols := [Color("b81e2c"), Color("2f8a5a"), Color("e8e2d0"), Color("d8b040"), Color("3a5aa8")]
	for k in 9:
		var x := int(hsh(k, 3, 80) * 15.0)
		var y := int(hsh(k, 4, 80) * 8.0)
		rect(i, x, y, 4, 3, cols[k % 5])
	for k in 3:
		hline(i, 2 + k * 3, 9 + k % 2, 10, Color("a8905a"))
	outline(i)
	return i

func _d_rack() -> Image:
	# 竹篾骨架（没糊纸的纸人）
	var i := new_img(16, 24)
	var b := Color("a8905a")
	ellipse(i, 8, 5, 3.5, 3.5, Color(0, 0, 0, 0))
	for a in 16:
		var ang := a / 16.0 * TAU
		px(i, int(8 + cos(ang) * 3.5), int(5 + sin(ang) * 3.5), b)
	vline(i, 8, 9, 13, b)
	hline(i, 3, 12, 10, b)
	for y in range(12, 22):
		px(i, 8 - (y - 12) / 2, y, b)
		px(i, 8 + (y - 12) / 2, y, b)
	hline(i, 3, 22, 11, b)
	return i

func _d_paper_bg() -> Image:
	# 文件/日记的纸背景 300x200
	var w := 320
	var h := 210
	var i := new_img(w, h)
	for y in h:
		for x in w:
			var c := Color("d8ceb4").lerp(Color("cfc3a4"), hsh(x / 6, y / 6, 91))
			var n := hsh(x, y, 92)
			if n > 0.97:
				c = shade(c, 0.92)
			var ex: int = mini(mini(x, w - 1 - x), mini(y, h - 1 - y))
			if ex < 6:
				c = shade(c, 0.8 + ex * 0.03)
			i.set_pixel(x, y, c)
	# 水渍
	for k in 3:
		var cx := hsh(k, 1, 93) * w
		var cy := hsh(k, 2, 93) * h
		var r := 12.0 + hsh(k, 3, 93) * 20.0
		for a in 80:
			var ang := a / 80.0 * TAU
			px(i, int(cx + cos(ang) * r), int(cy + sin(ang) * r * 0.8), Color(0.4, 0.3, 0.2, 0.15))
	# 竖格线
	for x in range(20, w - 10, 22):
		for y in range(10, h - 10):
			if y % 2 == 0:
				px(i, x, y, Color(0.6, 0.2, 0.15, 0.12))
	return i

func _d_noise() -> Image:
	var i := new_img(128, 128)
	for y in 128:
		for x in 128:
			var v := hsh(x, y, 99)
			i.set_pixel(x, y, Color(v, v, v, 1))
	return i

# ================================================================ 物品图标 12x12
func _icon(name: String) -> Image:
	var i := new_img(12, 12)
	match name:
		"i_oil":
			i.blit_rect(img("jar"), Rect2i(0, 0, 9, 11), Vector2i(1, 0))
		"i_key":
			ellipse(i, 3.5, 3.5, 2.5, 2.5, Color("c8a040"))
			px(i, 3, 3, Color(0, 0, 0, 0))
			px(i, 4, 3, Color(0, 0, 0, 0))
			for t in 6:
				px(i, 5 + t, 5 + t, Color("c8a040"))
			px(i, 9, 7, Color("c8a040"))
			px(i, 8, 9, Color("c8a040"))
			outline(i)
		"i_page":
			i.blit_rect(img("page"), Rect2i(0, 0, 9, 7), Vector2i(1, 2))
		"i_brush":
			i.blit_rect(img("brush"), Rect2i(0, 0, 4, 12), Vector2i(4, 0))
		"i_cinnabar":
			i.blit_rect(img("bowl_red"), Rect2i(0, 0, 10, 6), Vector2i(1, 4))
		"i_photo":
			i.blit_rect(img("photo"), Rect2i(0, 0, 8, 6), Vector2i(2, 3))
		"i_note":
			rect(i, 3, 0, 6, 12, Color("e8e0c8"))
			for y in [2, 4, 6, 8, 10]:
				hline(i, 4, y, 4, Color("3a3034"))
			outline(i)
		"i_seal":
			i.blit_rect(img("seal"), Rect2i(0, 0, 6, 12), Vector2i(3, 0))
		_:
			rect(i, 2, 2, 8, 8, Color.MAGENTA)
	return i
