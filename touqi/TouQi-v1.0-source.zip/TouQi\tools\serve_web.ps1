param([string]$Root = "F:\RenPyProject\QuieEveryday\_build\web", [int]$Port = 8765)
# 极简静态文件服务器，只用于本地测试网页版
$mime = @{ ".html"="text/html; charset=utf-8"; ".js"="application/javascript"; ".wasm"="application/wasm"; ".pck"="application/octet-stream"; ".png"="image/png"; ".txt"="text/plain; charset=utf-8" }
$l = New-Object System.Net.HttpListener
$l.Prefixes.Add("http://localhost:$Port/")
$l.Start()
Write-Host "Serving $Root on http://localhost:$Port/"
while ($l.IsListening) {
	$ctx = $l.GetContext()
	$path = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart('/'))
	if ($path -eq "") { $path = "index.html" }
	$file = Join-Path $Root $path
	$res = $ctx.Response
	try {
		if (Test-Path $file -PathType Leaf) {
			$bytes = [IO.File]::ReadAllBytes($file)
			$ext = [IO.Path]::GetExtension($file).ToLower()
			$res.ContentType = $(if ($mime.ContainsKey($ext)) { $mime[$ext] } else { "application/octet-stream" })
			$res.ContentLength64 = $bytes.Length
			$res.OutputStream.Write($bytes, 0, $bytes.Length)
		} else { $res.StatusCode = 404 }
	} catch {} finally { $res.Close() }
}
