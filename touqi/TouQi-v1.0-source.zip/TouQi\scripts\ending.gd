extends Control
## 结局画面

const EPILOGUE := {
	"true": [
		"天亮以后，三叔开了大门。",
		"灵堂里，长明灯还亮着。",
		"出殡那天，我在奶奶的棺材里，放了一包镇上供销社的糖。",
		"槐树底下，再也没有站过什么人。",
		"后来每年腊月初八，我都回来，煮一锅腊八粥。",
		"盛两碗。",
	],
	"substitute": [
		"天亮以后，三叔开了门，看见我坐在灵堂里，松了口气。",
		"出殡那天，我回头看了一眼。",
		"槐树底下，站着一个穿红衣服的小孩。没有眼睛，脸朝着我。",
		"后来我回了城里。",
		"每天早上刷牙的时候，",
		"镜子里的那个人，总要比我晚一点点眨眼。",
	],
	"paper": [
		"三叔说，那天他打开大门，灵堂里只坐着一个纸人。",
		"穿着孝服，胸口的红纸条上写着：林默。",
		"村里人把它和奶奶一起烧了。",
		"火烧起来的时候，有人听见里面在喊三叔。",
		"……没有人应。",
	],
}

var lines: Array = []
var box: VBoxContainer
var done := false

func _ready() -> void:
	var bg := ColorRect.new()
	bg.color = Color.BLACK
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var id: String = Game.flags.get("ending", "paper")
	var e: Dictionary = Game.ENDINGS[id]
	Sfx.stop_all_loops(0.5)
	Sfx.loop("music", "music_ending" if id == "true" else "music_lullaby", -10.0, 3.0)
	box = VBoxContainer.new()
	box.position = Vector2(40, 24)
	box.size = Vector2(400, 180)
	box.add_theme_constant_override("separation", 6)
	add_child(box)
	await get_tree().create_timer(1.0).timeout
	for s in EPILOGUE[id]:
		var l := Label.new()
		l.text = s
		l.add_theme_color_override("font_color", Color("c8c2b4"))
		l.modulate.a = 0.0
		box.add_child(l)
		var tw := create_tween()
		tw.tween_property(l, "modulate:a", 1.0, 1.2)
		await get_tree().create_timer(2.4 if not Game.autotest else 0.05).timeout
	await get_tree().create_timer(1.0 if not Game.autotest else 0.05).timeout
	var t := Label.new()
	t.text = "结局 · %s" % e.name
	t.add_theme_font_size_override("font_size", 24)
	t.add_theme_color_override("font_color", Color("e8e2d4") if id == "true" else Color("c83a3a"))
	t.position = Vector2(40, 172)
	t.modulate.a = 0.0
	add_child(t)
	create_tween().tween_property(t, "modulate:a", 1.0, 1.5)
	Sfx.play("chime", -4.0)
	var info := Label.new()
	info.position = Vector2(40, 202)
	info.add_theme_color_override("font_color", Color("6e685e"))
	var hint := ""
	if Game.deaths == 0:
		hint += "\n一次都没被抓。你是懂守灵的。"
	elif Game.deaths >= 10:
		hint += "\n被抓了 %d 次……建议明天去庙里拜拜。" % Game.deaths
	if int(Game.flags.get("merit", 0)) >= 10:
		hint += "\n功德：%d。奶奶说，够了够了。" % int(Game.flags.get("merit", 0))
	if not Game.endings_seen.has("true"):
		hint = "\n提示：五条规矩里，有一条不是奶奶写的。"
	var mins := int(Game.playtime / 60.0)
	info.text = "已达成结局 %d/3　　用时 %d 分钟　　被抓 %d 次%s" % [Game.endings_seen.size(), mins, Game.deaths, hint]
	add_child(info)
	var credit := Label.new()
	credit.position = Vector2(300, 252)
	credit.add_theme_color_override("font_color", Color("4e4840"))
	credit.text = "E 回到标题"
	add_child(credit)
	done = true
	if Game.autotest:
		await get_tree().create_timer(1.0).timeout
		print("[BOT] ENDING REACHED: ", id)
		if not OS.has_feature("web"):
			get_viewport().get_texture().get_image().save_png("res://_shots/ending_%s.png" % id)
			get_tree().quit()

func _process(_d: float) -> void:
	if done and Input.is_action_just_pressed("act"):
		done = false
		Sfx.stop_all_loops(1.0)
		_credits()

func _credits() -> void:
	for c in get_children():
		if c is Label or c is VBoxContainer:
			c.queue_free()
	var l := Label.new()
	l.text = "头　七\n\n策划 · 剧本 · 程序 · 像素美术 · 音效 · 音乐\nClaude（Anthropic）\n\n全部美术与声音均由代码实时生成\n引擎　Godot 4.7\n字体　Fusion Pixel Font（SIL OFL 1.1）\n\n感谢守灵。\n（守灵人：你。功德 +1）"
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.size = Vector2(480, 270)
	l.position = Vector2(0, 50)
	l.add_theme_color_override("font_color", Color("c8c2b4"))
	l.modulate.a = 0.0
	add_child(l)
	var tw := create_tween()
	tw.tween_property(l, "modulate:a", 1.0, 1.5)
	tw.tween_interval(5.0)
	tw.tween_property(l, "modulate:a", 0.0, 1.5)
	await tw.finished
	Game.goto("res://scenes/title.tscn")
