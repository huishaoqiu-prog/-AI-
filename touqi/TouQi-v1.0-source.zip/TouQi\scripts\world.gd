extends Node2D
## 主场景：林家老宅。地图、碰撞、光照、寻路、系统循环。

const T := 16
const MAP := [
	"####################+#######################",
	"#;;;;;;;;;;;;;;;;;;;;;;;;;;;;#:::::::::::::#",
	"#;;;;;;;;;;;;;;;;;;;;;;;;;;;;#:::::::::::::#",
	"#;;;;;;;;;;;;;;;;;;;;;;;;;;;;#:::::::::::::#",
	"#;;;;;;;;;;;;;;;;;;;;;;;;;;;;+:::::::::::::#",
	"#;;;;;;;;;;;;;;;;;;;;;;;;;;;;#:::::::::::::#",
	"#;;;;;;;;;;;;;;;;;;;;;;;;;;;;#:::::::::::::#",
	"#;;;;;;;;;;;;;;;;;;;;;;;;;;;;#:::::::::::::#",
	"############;;##############################",
	"#..........#,,#..............#.............#",
	"#..........#,,#..............#.............#",
	"#..........#,,#..............#.............#",
	"#..........#,,#..............#.............#",
	"#..........#,,#..............#.............#",
	"#..........#,,#..............#.............#",
	"#..........#,,#..............#.............#",
	"#..........#,,#..............#.............#",
	"#..........#,,#..............#.............#",
	"######+#####,,#######..#############+#######",
	"#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,#",
	"#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,#",
	"#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,#",
	"#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,#",
	"#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,#",
	"#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,#",
	"#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,#",
	"#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,#",
	"#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,#",
	"#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,#",
	"########+#########::::::::#########+########",
	"#................#::::::::#................#",
	"#................#::::::::#................#",
	"#................#::::::::#................#",
	"#................#::::::::#................#",
	"#................#::::::::#................#",
	"#................#::::::::#................#",
	"#####################++#####################",
]

const ROOMS := {
	"hall": Rect2i(15, 9, 14, 9),
	"west": Rect2i(1, 9, 10, 9),
	"east": Rect2i(30, 9, 13, 9),
	"yard": Rect2i(1, 19, 42, 10),
	"alley": Rect2i(12, 8, 2, 11),
	"back": Rect2i(1, 1, 28, 7),
	"shrine": Rect2i(30, 1, 13, 7),
	"shop": Rect2i(1, 30, 16, 6),
	"gatehall": Rect2i(18, 29, 8, 7),
	"kitchen": Rect2i(27, 30, 16, 6),
}
const ROOM_NAMES := {"hall": "堂屋·灵堂", "west": "西厢·小满的屋", "east": "东厢·奶奶的屋", "yard": "院子", "alley": "夹道",
	"back": "后院", "shrine": "祠堂", "shop": "扎纸铺", "gatehall": "门洞", "kitchen": "灶屋"}

var W := 0
var H := 0
var grid: Array = []
var astar := AStarGrid2D.new()
var objs := {}
var player: PlayerChar
var girl: Node2D
var shadow: Node2D
var ui: CanvasLayer
var story: Node
var cam: Camera2D
var ysort: Node2D
var decals: Node2D
var walls_body: StaticBody2D
var post: ShaderMaterial
var modulate_node: CanvasModulate
var lights := {}
var eternal_light: PointLight2D
var eternal_flame: Sprite2D

var fear := 0.0
var shake := 0.0
var flash := 0.0
var _player_tile := Vector2i(-1, -1)
var _cur_room := ""
var _girl_chase_seen := 0.0
var _eternal_warned := false
var _dead := false
var focus_obj: Node2D
var bot_input := Vector2.ZERO
var bot_sneak := false
var drain_paused := false
var roof_layer: CanvasLayer
var roof_sprite: Sprite2D

func _ready() -> void:
	randomize()
	grid = MAP.duplicate()
	H = grid.size()
	W = (grid[0] as String).length()
	for r in grid:
		assert((r as String).length() == W)
	_build_base()
	_build_walls()
	_build_astar()

	ysort = Node2D.new()
	ysort.y_sort_enabled = true
	add_child(ysort)

	modulate_node = CanvasModulate.new()
	modulate_node.color = Color("0e0d16")
	add_child(modulate_node)

	player = preload("res://scripts/player.gd").new()
	player.world = self
	ysort.add_child(player)

	girl = preload("res://scripts/girl.gd").new()
	girl.world = self
	girl.visible = false
	ysort.add_child(girl)

	shadow = preload("res://scripts/shadow.gd").new()
	shadow.world = self
	ysort.add_child(shadow)

	cam = Camera2D.new()
	cam.limit_left = 0
	cam.limit_top = -16
	cam.limit_right = W * T
	cam.limit_bottom = H * T + 8
	add_child(cam)
	cam.make_current()

	_build_post()
	ui = preload("res://scripts/ui.gd").new()
	ui.world = self
	add_child(ui)

	_build_objects()
	_build_lights()

	story = preload("res://scripts/story.gd").new()
	story.world = self
	add_child(story)
	story.setup()

	if Game.player_pos != Vector2.ZERO:
		player.global_position = Game.player_pos
	cam.global_position = player.global_position
	cam.reset_smoothing()

	Sfx.loop("amb", "amb_wind", -15.0, 2.0)
	Sfx.loop("amb2", "amb_drone", -17.0 if Game.chapter < 2 else -11.0, 3.0)
	if Game.chapter < 2:
		Sfx.loop("amb3", "amb_insects", -20.0, 2.0)
	else:
		Sfx.stop_loop("amb3", 1.0)
	Sfx.stop_loop("music", 1.0)
	Sfx.loop("fire", "lamp_fire", -26.0, 1.0)

	if Game.autotest:
		var bot = load("res://tools/autotest.gd").new()
		bot.world = self
		add_child(bot)
	story.begin()

# ================================================================ 构建
func _build_base() -> void:
	var img: Image = Art.build_map(grid)
	# 正立面窗户
	for w in [[16, 18, true], [18, 18, true], [25, 18, true], [27, 18, true], [3, 18, false], [9, 18, false],
			[32, 18, false], [40, 18, false], [18, 8, false], [25, 8, false], [5, 8, false], [37, 0, false]]:
		Art.draw_window(img, w[0], w[1], w[2])
	var spr := Sprite2D.new()
	spr.texture = ImageTexture.create_from_image(img)
	spr.centered = false
	spr.z_index = -20
	add_child(spr)
	# 屋顶：独立图层，不受夜色和光照影响，保证建筑轮廓始终可读
	roof_layer = CanvasLayer.new()
	roof_layer.layer = 1
	roof_layer.follow_viewport_enabled = true
	add_child(roof_layer)
	var roof := Sprite2D.new()
	roof.texture = ImageTexture.create_from_image(Art.roof_img)
	roof.centered = false
	roof.modulate = Color(0.62, 0.62, 0.7)
	roof_layer.add_child(roof)
	roof_sprite = roof
	decals = Node2D.new()
	decals.z_index = -10
	add_child(decals)

func is_wall(tx: int, ty: int) -> bool:
	if tx < 0 or ty < 0 or tx >= W or ty >= H:
		return true
	return (grid[ty] as String)[tx] == "#"

func _build_walls() -> void:
	walls_body = StaticBody2D.new()
	walls_body.collision_layer = 1
	add_child(walls_body)
	var occ_root := Node2D.new()
	add_child(occ_root)
	for ty in H:
		var tx := 0
		while tx < W:
			if not is_wall(tx, ty):
				tx += 1
				continue
			var start := tx
			while tx < W and is_wall(tx, ty):
				tx += 1
			var cs := CollisionShape2D.new()
			var r := RectangleShape2D.new()
			r.size = Vector2((tx - start) * T, T)
			cs.shape = r
			cs.position = Vector2((start + tx) * T / 2.0, ty * T + T / 2.0)
			walls_body.add_child(cs)
			# 遮光：有墙面的格只遮檐口，纯屋顶整格遮
			var seg := start
			while seg < tx:
				var face := not is_wall(seg, ty + 1)
				var e := seg
				while e < tx and (not is_wall(e, ty + 1)) == face:
					e += 1
				var y0 := ty * T
				var y1 := ty * T + (6 if face else T)
				_add_occluder(occ_root, Rect2(seg * T, y0, (e - seg) * T, y1 - y0))
				seg = e

func _add_occluder(parent: Node, r: Rect2) -> LightOccluder2D:
	var o := LightOccluder2D.new()
	var poly := OccluderPolygon2D.new()
	poly.polygon = PackedVector2Array([r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)])
	poly.cull_mode = OccluderPolygon2D.CULL_DISABLED
	o.occluder = poly
	parent.add_child(o)
	return o

func _build_astar() -> void:
	astar.region = Rect2i(0, 0, W, H)
	astar.cell_size = Vector2(T, T)
	astar.offset = Vector2(T / 2.0, T / 2.0)
	astar.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	astar.default_compute_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	astar.update()
	for ty in H:
		for tx in W:
			if is_wall(tx, ty):
				astar.set_point_solid(Vector2i(tx, ty), true)

func _build_post() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	var cr := ColorRect.new()
	cr.set_anchors_preset(Control.PRESET_FULL_RECT)
	cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	post = ShaderMaterial.new()
	post.shader = load("res://shaders/post.gdshader")
	cr.material = post
	layer.add_child(cr)

# ================================================================ 物件
func add(id: String, art: String, tile: Vector2i, o: Dictionary = {}) -> Node2D:
	var ob: Node2D = preload("res://scripts/obj.gd").new()
	ob.id = id
	ob.name = id
	var size: Vector2i = o.get("size", Vector2i(1, 1))
	ob.position = Vector2((tile.x + size.x / 2.0) * T, (tile.y + size.y) * T + o.get("dy", 0))
	if art != "":
		ob.set_art(art)
	ob.label = o.get("label", "")
	ob.verb = o.get("verb", "调查")
	ob.interact = o.get("interact", ob.label != "")
	ob.hide_spot = o.get("hide", false)
	ob.rect = Rect2(tile.x * T, tile.y * T, size.x * T, size.y * T)
	if o.get("solid", true):
		for y in size.y:
			for x in size.x:
				var t := Vector2i(tile.x + x, tile.y + y)
				ob.tiles.append(t)
				astar.set_point_solid(t, true)
		var cs := CollisionShape2D.new()
		var r := RectangleShape2D.new()
		r.size = Vector2(size.x * T - 2, size.y * T - 4)
		cs.shape = r
		cs.position = ob.rect.get_center() + Vector2(0, 2)
		walls_body.add_child(cs)
	if o.get("decal", false):
		decals.add_child(ob)
	elif o.get("wall", false):
		ob.z_index = -9
		add_child(ob)
	else:
		ysort.add_child(ob)
	objs[id] = ob
	return ob

func add_door(id: String, tile: Vector2i, vertical: bool, locked: bool, label: String, art_name: String = "") -> Node2D:
	var ob: Node2D = preload("res://scripts/obj.gd").new()
	ob.id = id
	ob.name = id
	ob.is_door = true
	ob.vertical = vertical
	ob.locked = locked
	ob.door_tile = tile
	ob.label = label
	ob.verb = "开门"
	ob.interact = true
	ob.position = Vector2(tile.x * T + T / 2.0, tile.y * T + T)
	ob.z_index = -9
	ob.set_art(art_name if art_name != "" else ("door_v" if vertical else "door_h"))
	ob.rect = Rect2(tile.x * T, tile.y * T, T, T)
	ob.body = StaticBody2D.new()
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(T, T)
	cs.shape = r
	cs.position = Vector2(tile.x * T + T / 2.0, tile.y * T + T / 2.0)
	ob.body.add_child(cs)
	add_child(ob.body)
	ob.occluder = _add_occluder(self, Rect2(tile.x * T, tile.y * T, T, 6 if not vertical else T))
	if locked:
		astar.set_point_solid(tile, true)
	add_child(ob)
	objs[id] = ob
	return ob

func set_door_locked(id: String, v: bool) -> void:
	var d: Node2D = objs[id]
	d.locked = v
	astar.set_point_solid(d.door_tile, v)

func open_door(id: String, silent: bool = false) -> void:
	var d: Node2D = objs[id]
	d.open_door(silent)
	astar.set_point_solid(d.door_tile, false)
	if not silent:
		noise(d.global_position, 100.0, "door")

func obj(id: String) -> Node2D:
	return objs.get(id)

func remove_obj(id: String) -> void:
	var o: Node2D = objs.get(id)
	if o == null:
		return
	for t in o.tiles:
		astar.set_point_solid(t, false)
	o.queue_free()
	objs.erase(id)

func decal(art: String, pos: Vector2, id: String = "") -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = Art.tex(art)
	s.position = pos
	decals.add_child(s)
	if id != "":
		s.name = id
	return s

func _build_objects() -> void:
	# ---------------- 堂屋（灵堂）
	add("portrait", "portrait", Vector2i(21, 8), {"size": Vector2i(2, 1), "dy": -1, "solid": false, "wall": true, "label": "奶奶的遗像"})
	add("altar", "altar", Vector2i(20, 9), {"size": Vector2i(4, 2), "dy": -4, "label": "供桌", "hide": true})
	add("eternal", "lamp", Vector2i(21, 10), {"size": Vector2i(2, 1), "dy": -14, "solid": false, "label": "长明灯", "verb": "添油"})
	objs["eternal"].z_index = 1
	add("candle_l", "candle", Vector2i(20, 9), {"dy": 3, "solid": false})
	add("candle_r", "candle", Vector2i(23, 9), {"dy": 3, "solid": false})
	objs["candle_l"].z_index = 1
	objs["candle_r"].z_index = 1
	add("coffin", "coffin", Vector2i(20, 12), {"size": Vector2i(4, 2), "dy": 0, "label": "棺材"})
	add("wreath1", "wreath", Vector2i(16, 9), {"label": "花圈"})
	add("wreath2", "wreath", Vector2i(27, 9), {"label": "花圈"})
	add("wreath3", "wreath", Vector2i(16, 16), {"label": "花圈"})
	add("wreath4", "wreath", Vector2i(27, 16), {"label": "花圈"})
	add("banner1", "banner", Vector2i(18, 9), {"solid": false})
	add("banner2", "banner", Vector2i(25, 9), {"solid": false})
	add("hall_chair1", "chair", Vector2i(15, 12))
	add("hall_chair2", "chair", Vector2i(28, 12))
	add("cushion", "money", Vector2i(21, 14), {"size": Vector2i(2, 1), "solid": false, "decal": true})
	decal("money", Vector2(300, 240))
	decal("money", Vector2(410, 222))
	decal("money", Vector2(352, 268))
	# ---------------- 西厢（小满的屋）
	add("west_bed", "bed_small", Vector2i(1, 9), {"size": Vector2i(2, 1), "label": "小床"})
	add("west_desk", "desk", Vector2i(5, 9), {"size": Vector2i(2, 1), "label": "书桌"})
	add("musicbox", "musicbox", Vector2i(6, 9), {"dy": -9, "solid": false, "label": "八音盒"})
	objs["musicbox"].z_index = 1
	add("west_wardrobe", "wardrobe", Vector2i(10, 10), {"label": "衣柜", "hide": true, "verb": "躲进去"})
	add("west_chair", "chair", Vector2i(5, 11))
	add("west_shelf", "shelf", Vector2i(9, 9), {"label": "架子"})
	add("drawing", "", Vector2i(3, 8), {"solid": false, "label": "墙上的画"})
	# ---------------- 东厢（奶奶的屋）
	add("east_bed", "bed", Vector2i(39, 9), {"size": Vector2i(2, 2), "label": "奶奶的床"})
	add("dresser", "dresser", Vector2i(31, 9), {"label": "梳妆台"})
	add("east_desk", "desk", Vector2i(34, 9), {"size": Vector2i(2, 1), "label": "桌子"})
	add("east_wardrobe", "wardrobe", Vector2i(42, 13), {"label": "衣柜", "hide": true, "verb": "躲进去"})
	add("east_table", "table", Vector2i(35, 13), {"label": "八仙桌"})
	add("east_chair", "chair", Vector2i(34, 13))
	add("east_shelf", "shelf", Vector2i(30, 13), {"label": "针线架"})
	# ---------------- 院子
	add("tree", "tree", Vector2i(9, 23), {"label": "老槐树"})
	add("yard_vat", "vat", Vector2i(31, 20), {"label": "水缸"})
	add("lantern1", "lantern", Vector2i(20, 18), {"solid": false, "wall": true, "dy": -2})
	add("lantern2", "lantern", Vector2i(23, 18), {"solid": false, "wall": true, "dy": -2})
	decal("money", Vector2(250, 360))
	decal("money", Vector2(520, 400))
	decal("money", Vector2(360, 440))
	# ---------------- 扎纸铺
	add("shop_boy", "effigy_boy", Vector2i(2, 30), {"label": "纸童"})
	add("shop_old", "effigy_old", Vector2i(4, 30), {"label": "纸人"})
	add("shop_rack", "rack", Vector2i(6, 30), {"label": "竹篾骨架"})
	add("stand", "stand", Vector2i(10, 30), {"label": "空架子"})
	add("horse", "horse", Vector2i(13, 30), {"size": Vector2i(2, 1), "label": "纸马"})
	add("shop_pile", "", Vector2i(3, 33), {"size": Vector2i(2, 1), "label": "纸人堆", "hide": true, "verb": "钻进去", "solid": false})
	add("shop_boy2", "effigy_boy", Vector2i(2, 33))
	add("shop_old2", "effigy_old", Vector2i(4, 34))
	add("shop_boy3", "effigy", Vector2i(3, 34), {"solid": false})
	add("workbench", "desk", Vector2i(8, 33), {"size": Vector2i(2, 1), "label": "工作台"})
	add("shop_shelf", "shelf", Vector2i(15, 31), {"label": "颜料架"})
	decal("paper_pile", Vector2(120, 520))
	decal("paper_pile", Vector2(200, 560))
	decal("paper_pile", Vector2(60, 500))
	# ---------------- 灶屋
	add("stove", "stove", Vector2i(28, 30), {"size": Vector2i(2, 1), "label": "灶台"})
	add("oilvat", "oilvat", Vector2i(31, 30), {"label": "油缸", "verb": "舀油"})
	add("kitchen_vat", "vat", Vector2i(33, 30), {"label": "水缸"})
	add("firewood", "firewood", Vector2i(40, 33), {"label": "柴堆", "hide": true, "verb": "躲到后面"})
	add("kitchen_shelf", "shelf", Vector2i(42, 30), {"label": "碗柜"})
	add("kitchen_table", "table", Vector2i(36, 33), {"label": "饭桌"})
	# ---------------- 门洞
	add("gate_lantern1", "lantern", Vector2i(19, 35), {"solid": false, "dy": -6})
	add("gate_lantern2", "lantern", Vector2i(24, 35), {"solid": false, "dy": -6})
	add("gate_wreath", "wreath", Vector2i(18, 31))
	add("gate_wreath2", "wreath", Vector2i(25, 31))
	# ---------------- 后院
	add("well", "well", Vector2i(6, 3), {"size": Vector2i(2, 2), "label": "井"})
	add("back_wood", "firewood", Vector2i(26, 1), {"label": "柴火"})
	add("back_vat", "vat", Vector2i(2, 1))
	# ---------------- 祠堂
	add("tablets", "tablets", Vector2i(35, 1), {"size": Vector2i(2, 1), "label": "牌位"})
	add("shrine_table", "table", Vector2i(35, 3), {"label": "供桌"})
	add("effigy_me", "effigy", Vector2i(40, 3), {"label": "纸人"})
	add("shrine_candle1", "candle", Vector2i(34, 1), {"solid": false})
	add("shrine_candle2", "candle", Vector2i(37, 1), {"solid": false})
	# ---------------- 门
	add_door("door_west", Vector2i(6, 18), false, true, "西厢的门")
	add_door("door_east", Vector2i(36, 18), false, true, "东厢的门")
	add_door("door_shop", Vector2i(8, 29), false, false, "扎纸铺的门")
	add_door("door_kitchen", Vector2i(35, 29), false, false, "灶屋的门")
	add_door("door_shrine", Vector2i(29, 4), true, true, "祠堂的门")
	add_door("backgate", Vector2i(20, 0), false, true, "后门", "backgate")
	# 大门（永远锁着，直到天亮）
	var g := add("gate", "gate", Vector2i(21, 35), {"size": Vector2i(2, 1), "dy": 14, "solid": false, "label": "大门"})
	g.z_index = 2
	for t in [Vector2i(21, 36), Vector2i(22, 36)]:
		astar.set_point_solid(t, true)

func _build_lights() -> void:
	# 月光
	for p in [Vector2(10 * T, 22 * T), Vector2(33 * T, 22 * T), Vector2(22 * T, 25 * T), Vector2(9 * T, 4 * T), Vector2(22 * T, 4 * T)]:
		var l := _mk_light(p, Color(0.45, 0.55, 0.85), 0.42, 4.2, true, "light_soft")
		l.z_index = 0
	# 长明灯
	eternal_light = _mk_light(objs["eternal"].global_position + Vector2(0, -6), Color(1.0, 0.7, 0.38), 1.3, 1.6, true)
	eternal_flame = Sprite2D.new()
	eternal_flame.texture = Art.tex("flame0")
	eternal_flame.position = objs["eternal"].global_position + Vector2(0, -10)
	eternal_flame.z_index = 2
	add_child(eternal_flame)
	# 蜡烛
	for id in ["candle_l", "candle_r", "shrine_candle1", "shrine_candle2"]:
		var c: Node2D = objs[id]
		lights[id] = _mk_light(c.global_position + Vector2(0, -12), Color(1.0, 0.75, 0.45), 0.8, 0.7, true)
		var f := Sprite2D.new()
		f.texture = Art.tex("flame0")
		f.position = Vector2(0, -12)
		f.z_index = 2
		f.name = "flame"
		c.add_child(f)
	# 白灯笼
	for id in ["lantern1", "lantern2", "gate_lantern1", "gate_lantern2"]:
		lights[id] = _mk_light(objs[id].global_position + Vector2(0, -8), Color(0.9, 0.85, 0.75), 0.55, 1.2, true)
	# 堂屋窗户透出的光
	for x in [16, 18, 25, 27]:
		_mk_light(Vector2(x * T + 8, 19 * T + 4), Color(1.0, 0.7, 0.4), 0.35, 0.5, false)
	# 灶膛余火
	lights["stove"] = _mk_light(objs["stove"].global_position + Vector2(-8, -4), Color(1.0, 0.35, 0.1), 0.5, 0.6, true)

func _mk_light(pos: Vector2, color: Color, energy: float, scale: float, shadows: bool, tex: String = "light_round") -> PointLight2D:
	var l := PointLight2D.new()
	l.texture = Art.tex(tex)
	l.color = color
	l.energy = energy
	l.texture_scale = scale
	l.shadow_enabled = shadows
	l.shadow_filter = Light2D.SHADOW_FILTER_NONE
	l.global_position = pos
	add_child(l)
	return l

func set_light(id: String, on: bool) -> void:
	if lights.has(id):
		lights[id].visible = on
	var o: Node2D = objs.get(id)
	if o and o.has_node("flame"):
		o.get_node("flame").visible = on

# ================================================================ 查询
func tile_of(p: Vector2) -> Vector2i:
	return Vector2i(int(floor(p.x / T)), int(floor(p.y / T)))

func room_at(p: Vector2) -> String:
	var t := tile_of(p)
	for k in ROOMS:
		if (ROOMS[k] as Rect2i).has_point(t):
			return k
	var ch := (grid[clampi(t.y, 0, H - 1)] as String)[clampi(t.x, 0, W - 1)]
	if t.y == 18:
		return "yard"
	return "yard" if ch == "," else ""

func floor_at(p: Vector2) -> String:
	var t := tile_of(p)
	var ch: String = Art._floor_kind(grid, t.x, t.y) if not is_wall(t.x, t.y) else "stone"
	match ch:
		"wood": return "wood"
		"dirt": return "dirt"
		_: return "stone"

func hall_center() -> Vector2:
	return Vector2(22 * T, 15 * T + 8)

func tile_center(t: Vector2i) -> Vector2:
	return Vector2(t.x * T + T / 2.0, t.y * T + T / 2.0)

func find_path(from: Vector2, to: Vector2) -> PackedVector2Array:
	var a := tile_of(from)
	var b := tile_of(to)
	if not astar.is_in_boundsv(a) or not astar.is_in_boundsv(b):
		return PackedVector2Array()
	if astar.is_point_solid(b):
		b = _nearest_open(b)
	var was_solid := astar.is_point_solid(a)
	if was_solid:
		astar.set_point_solid(a, false)
	var pts := astar.get_point_path(a, b, true)
	if was_solid:
		astar.set_point_solid(a, true)
	if pts.size() > 0:
		pts.remove_at(0)
	if pts.size() > 0 and b == tile_of(to) and not astar.is_point_solid(b):
		pts[pts.size() - 1] = to
	return pts

func _nearest_open(t: Vector2i) -> Vector2i:
	for r in range(1, 4):
		for dy in range(-r, r + 1):
			for dx in range(-r, r + 1):
				var n := t + Vector2i(dx, dy)
				if astar.is_in_boundsv(n) and not astar.is_point_solid(n):
					return n
	return t

func random_open_tile_in(room: String) -> Vector2i:
	var r: Rect2i = ROOMS[room]
	for k in 30:
		var t := Vector2i(randi_range(r.position.x, r.end.x - 1), randi_range(r.position.y, r.end.y - 1))
		if not astar.is_point_solid(t):
			return t
	return r.get_center()

func girl_wander_target(aggr: float) -> Vector2:
	if randf() < aggr:
		var pr := room_at(player.global_position)
		if pr != "" and not player.is_hidden:
			return tile_center(random_open_tile_in(pr))
		return player.global_position + Vector2(randf_range(-60, 60), randf_range(-40, 40))
	var rooms: Array = story.girl_rooms()
	return tile_center(random_open_tile_in(rooms[randi() % rooms.size()]))

func girl_touch_door(pt: Vector2) -> void:
	var t := tile_of(pt)
	for k in objs:
		var o: Node2D = objs[k]
		if o.is_door and o.door_tile == t and not o.is_open and not o.locked:
			open_door(k)

# ================================================================ 声音/恐惧
func noise(pos: Vector2, radius: float, kind: String = "") -> void:
	if girl.visible:
		girl.hear(pos, radius, kind)
	if radius >= 60.0:
		_ring(pos, radius)

func _ring(pos: Vector2, radius: float) -> void:
	var r := preload("res://scripts/ring.gd").new()
	r.position = pos + Vector2(0, -4)
	r.max_r = minf(radius * 0.45, 46.0)
	add_child(r)

func on_girl_chase() -> void:
	if Time.get_ticks_msec() / 1000.0 - _girl_chase_seen > 12.0:
		Sfx.play("sting_soft", -4.0)
	_girl_chase_seen = Time.get_ticks_msec() / 1000.0
	ui.toast("她听见你了")

# ================================================================ 主循环
func _process(delta: float) -> void:
	# 相机
	var look := player.facing * 10.0
	var target := player.global_position + Vector2(0, -12) + look
	if focus_obj != null and is_instance_valid(focus_obj):
		target = focus_obj.global_position + Vector2(0, -12)
	cam.global_position = cam.global_position.lerp(target, 1.0 - pow(0.001, delta))
	shake = maxf(0.0, shake - delta * 3.0)
	cam.offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * 4.0
	cam.offset = cam.offset.round()

	if Game.frozen == 0 and not _dead:
		_tick_lamps(delta)
		_tick_interact()
		var t := tile_of(player.global_position)
		if t != _player_tile:
			_player_tile = t
			var room := room_at(player.global_position)
			if room != _cur_room and room != "":
				_cur_room = room
				ui.room_name(ROOM_NAMES.get(room, ""))
			story.on_tile(t, room)
		story.tick(delta)
	else:
		ui.set_prompt(null)
	_tick_fear(delta)
	_tick_eternal_visual(delta)
	if Input.is_action_just_pressed("refill") and Game.frozen == 0 and not _dead:
		refill_hand_lamp()

func _tick_lamps(delta: float) -> void:
	if Game.chapter >= 1 and not drain_paused:
		Game.lamp = maxf(0.0, Game.lamp - delta * 0.30)
		var rate: float = [0.0, 0.20, 0.24, 0.26, 0.28, 0.30][Game.chapter]
		Game.eternal = maxf(0.0, Game.eternal - delta * rate)
		if Game.eternal < 25.0 and not _eternal_warned:
			_eternal_warned = true
			ui.toast("长明灯快灭了！回堂屋添油")
			Sfx.play("sting_soft", -10.0)
		if Game.eternal > 30.0:
			_eternal_warned = false
		if Game.eternal <= 0.0:
			player_caught("eternal")

func _tick_eternal_visual(_delta: float) -> void:
	var e := Game.eternal / 100.0
	var on := Game.eternal > 0.0
	eternal_flame.visible = on
	eternal_flame.texture = Art.tex("flame0" if int(Time.get_ticks_msec() / 130) % 2 == 0 else "flame1")
	eternal_light.texture_scale = lerpf(0.7, 1.9, e) + randf_range(-0.04, 0.04)
	eternal_light.energy = (1.2 + randf_range(-0.1, 0.1)) * (1.0 if e > 0.2 or randf() > 0.2 else 0.5)
	eternal_light.visible = on

func _tick_fear(delta: float) -> void:
	var f := 0.0
	if girl.visible and girl.state in ["wander", "investigate", "search", "chase"]:
		var d := girl.global_position.distance_to(player.global_position)
		f = clampf(1.0 - (d - 16.0) / 150.0, 0.0, 1.0) * 0.8
		if girl.state == "chase":
			f = maxf(f, 0.55) + 0.25
	if shadow.visible and shadow.state == "chase":
		var d2 := shadow.global_position.distance_to(player.global_position)
		f = maxf(f, clampf(1.0 - (d2 - 16.0) / 170.0, 0.0, 1.0) + 0.2)
	if Game.lamp <= 0.0:
		f += 0.15
	fear = lerpf(fear, clampf(f, 0.0, 1.0), 1.0 - pow(0.05, delta))
	flash = maxf(0.0, flash - delta * 2.0)
	post.set_shader_parameter("fear", fear)
	post.set_shader_parameter("flash", flash)
	post.set_shader_parameter("hidden", 1.0 if player.is_hidden else 0.0)
	if fear > 0.12:
		Sfx.loop("heart", "heartbeat_loop", lerpf(-26.0, -2.0, fear), 0.3)
	else:
		Sfx.stop_loop("heart", 0.8)

func _tick_interact() -> void:
	if player.is_hidden:
		ui.set_prompt(null)
		if Input.is_action_just_pressed("act") and Engine.get_process_frames() > Game.act_block:
			unhide()
		return
	var best := focus_target()
	ui.set_prompt(best)
	if best and Input.is_action_just_pressed("act") and Engine.get_process_frames() > Game.act_block:
		_do_interact(best)

## 玩家面前可调查的物件。距离相同（比如长明灯放在供桌上）时，小物件优先。
func focus_target() -> Node2D:
	var probe: Vector2 = player.global_position + Vector2(0, -4) + player.facing * 9.0
	var best: Node2D = null
	var bd := 11.0
	var barea := INF
	for k in objs:
		var o: Node2D = objs[k]
		if not o.interact or o.label == "":
			continue
		if o.is_door and o.is_open:
			continue
		var r: Rect2 = o.rect
		var cx := clampf(probe.x, r.position.x, r.end.x)
		var cy := clampf(probe.y, r.position.y, r.end.y)
		var d := probe.distance_to(Vector2(cx, cy))
		var area := r.get_area()
		if d < bd - 1.0 or (d < bd + 1.0 and area < barea):
			bd = d
			barea = area
			best = o
	return best

func _do_interact(o: Node2D) -> void:
	if o.is_door and not o.locked and o.id != "backgate":
		open_door(o.id)
		return
	story.interact(o)

# ================================================================ 动作
func refill_hand_lamp() -> void:
	if not Game.has("oil"):
		ui.toast("没有灯油了")
		Sfx.play("ui_back", -8.0)
		return
	if Game.lamp > 85.0:
		ui.toast("油灯还满着")
		return
	Game.take("oil")
	Game.lamp = 100.0
	Sfx.play("oil_pour", -4.0)
	ui.toast("给油灯添了油")

func hide_player(o: Node2D) -> void:
	player.is_hidden = true
	player.velocity = Vector2.ZERO
	Sfx.play("cloth", -6.0)
	ui.hide_overlay(true, o.verb)
	noise(player.global_position, 20.0, "hide")

func unhide() -> void:
	player.is_hidden = false
	Sfx.play("cloth", -8.0)
	ui.hide_overlay(false)

func player_caught(kind: String) -> void:
	if Game.autotest and has_node("Bot") and get_node("Bot").safe:
		return
	if _dead:
		return
	_dead = true
	Game.frozen += 1
	Game.deaths += 1
	story.on_caught(kind)

func do_shake(v: float) -> void:
	shake = maxf(shake, v)

func do_flash(v: float) -> void:
	flash = maxf(flash, v)

func retry() -> void:
	Game.load_checkpoint()
	Game.start_world()
