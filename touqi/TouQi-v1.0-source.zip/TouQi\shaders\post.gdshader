shader_type canvas_item;
// 后处理：胶片颗粒、暗角、恐惧（色差 + 去饱和 + 脉动）、躲藏时的狭窄视野、闪光

uniform sampler2D screen_tex : hint_screen_texture, filter_nearest;
uniform float fear = 0.0;
uniform float flash = 0.0;
uniform float hidden = 0.0;
uniform vec4 flash_color : source_color = vec4(0.6, 0.0, 0.0, 1.0);

float rand(vec2 co) {
	return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453);
}

void fragment() {
	vec2 uv = SCREEN_UV;
	vec2 px = SCREEN_PIXEL_SIZE;
	float t = TIME;
	float pulse = 0.5 + 0.5 * sin(t * (4.0 + fear * 6.0));
	// 色差
	float ab = fear * (1.0 + pulse) * 1.0;
	vec3 col;
	col.r = texture(screen_tex, uv + vec2(px.x * round(ab), 0.0)).r;
	col.g = texture(screen_tex, uv).g;
	col.b = texture(screen_tex, uv - vec2(px.x * round(ab), 0.0)).b;
	// 去饱和 + 偏冷
	float lum = dot(col, vec3(0.299, 0.587, 0.114));
	col = mix(col, vec3(lum) * vec3(0.92, 0.96, 1.08), fear * 0.55);
	// 暗角
	vec2 c = uv - 0.5;
	c.x *= 1.6;
	float vig = smoothstep(0.95 - fear * 0.25 - hidden * 0.35, 0.25 - hidden * 0.2, length(c));
	col *= mix(1.0, vig, 0.85);
	// 衣柜门缝
	if (hidden > 0.5) {
		float slit = step(abs(uv.x - 0.5), 0.09);
		col *= mix(0.12, 1.0, slit);
	}
	// 颗粒
	vec2 gp = floor(uv / px);
	float g = rand(gp + fract(t * 7.3) * 91.0) - 0.5;
	col += g * (0.045 + fear * 0.06);
	// 扫描行轻微抖动（高恐惧时）
	if (fear > 0.6 && rand(vec2(floor(t * 20.0), gp.y)) > 0.985) {
		col = texture(screen_tex, uv + vec2(px.x * 3.0, 0.0)).rgb;
	}
	col = mix(col, flash_color.rgb, flash * 0.7);
	COLOR = vec4(col, 1.0);
}
