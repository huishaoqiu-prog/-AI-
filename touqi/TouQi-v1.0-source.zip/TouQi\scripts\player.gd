class_name PlayerChar
extends CharacterBody2D
## 玩家：林默

const WALK := 46.0
const RUN := 80.0
const SNEAK := 24.0

var world: Node
var facing := Vector2.DOWN
var is_hidden := false
var moving := false
var mode := "walk"
var speed_mult := 1.0

var sprite: Sprite2D
var lamp_node: Node2D
var lamp_sprite: Sprite2D
var flame: Sprite2D
var light: PointLight2D
var glow: PointLight2D
var _anim := 0.0
var _step_dist := 0.0
var _flick := 0.0
var _flame_t := 0.0
var lamp_boost := 0.0

func _ready() -> void:
	collision_layer = 2
	collision_mask = 1
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(9, 5)
	cs.shape = r
	cs.position = Vector2(0, -2.5)
	add_child(cs)

	sprite = Sprite2D.new()
	sprite.texture = Art.tex("player_sheet")
	sprite.hframes = 4
	sprite.vframes = 3
	sprite.centered = false
	sprite.offset = Vector2(-8, -24)
	add_child(sprite)

	lamp_node = Node2D.new()
	add_child(lamp_node)
	lamp_sprite = Sprite2D.new()
	lamp_sprite.texture = Art.tex("handlamp")
	lamp_sprite.centered = false
	lamp_sprite.offset = Vector2(-3, -7)
	lamp_node.add_child(lamp_sprite)
	flame = Sprite2D.new()
	flame.texture = Art.tex("flame0")
	flame.centered = false
	flame.offset = Vector2(-2, -11)
	lamp_node.add_child(flame)

	light = PointLight2D.new()
	light.texture = Art.tex("light_round")
	light.color = Color(1.0, 0.74, 0.46)
	light.energy = 1.25
	light.shadow_enabled = true
	light.shadow_filter = Light2D.SHADOW_FILTER_NONE
	light.shadow_color = Color(0, 0, 0, 1)
	light.position = Vector2(0, -8)
	lamp_node.add_child(light)
	# 近身一圈柔光，保证玩家自己总能看清
	glow = PointLight2D.new()
	glow.texture = Art.tex("light_soft")
	glow.color = Color(1.0, 0.8, 0.6)
	glow.energy = 0.35
	glow.texture_scale = 0.3
	glow.position = Vector2(0, -10)
	add_child(glow)
	_update_lamp_pos()

func _physics_process(delta: float) -> void:
	var inp := Vector2.ZERO
	var can_move := Game.frozen == 0 and not is_hidden and not get_tree().paused
	if can_move:
		inp = Input.get_vector("left", "right", "up", "down")
		if Game.autotest and world.bot_input != Vector2.ZERO:
			inp = world.bot_input
	moving = inp.length() > 0.2
	mode = "walk"
	if Input.is_action_pressed("sneak") or (Game.autotest and world.bot_sneak):
		mode = "sneak"
	elif Input.is_action_pressed("run") and not (Game.autotest and world.bot_sneak):
		mode = "run"
	var spd: float = {"walk": WALK, "run": RUN, "sneak": SNEAK}[mode] * speed_mult
	if moving:
		if abs(inp.x) > abs(inp.y) + 0.1:
			facing = Vector2(sign(inp.x), 0)
		elif abs(inp.y) > 0.1:
			facing = Vector2(0, sign(inp.y))
		velocity = inp.normalized() * spd
	else:
		velocity = Vector2.ZERO
	var before := global_position
	move_and_slide()
	var moved := global_position.distance_to(before)
	if moving and moved > 0.05:
		_anim += delta * (spd / 46.0) * 7.0
		_step_dist += moved
		var stride := 13.0 if mode != "run" else 17.0
		if _step_dist > stride:
			_step_dist = 0.0
			_footstep()
	else:
		_anim = 0.0
	_update_sprite()
	_update_lamp(delta)
	Game.player_pos = global_position

func _footstep() -> void:
	var kind: String = world.floor_at(global_position)
	var vol := -12.0
	var radius := 34.0
	if mode == "run":
		vol = -4.0
		radius = 120.0
	elif mode == "sneak":
		vol = -24.0
		radius = 0.0
	Sfx.play("step_" + kind, vol, randf_range(0.9, 1.1))
	if radius > 0.0:
		world.noise(global_position, radius, "step")

func _update_sprite() -> void:
	var row := 0
	if facing.y < 0:
		row = 1
	elif facing.x != 0:
		row = 2
	var f := 0
	if moving:
		f = int(_anim) % 4
	sprite.frame = row * 4 + f
	sprite.flip_h = facing.x < 0
	sprite.visible = not is_hidden
	lamp_node.visible = not is_hidden
	_update_lamp_pos()

func _update_lamp_pos() -> void:
	if lamp_node == null:
		return
	if facing.y > 0:
		lamp_node.position = Vector2(5, -6)
		lamp_node.z_index = 0
	elif facing.y < 0:
		lamp_node.position = Vector2(-5, -7)
		lamp_node.z_index = -1
	else:
		lamp_node.position = Vector2(6 * facing.x, -6)
		lamp_node.z_index = 0
	if moving:
		lamp_node.position.y += sin(_anim * PI) * 0.6

func light_radius() -> float:
	var r := lerpf(34.0, 112.0, clampf(Game.lamp / 100.0, 0.0, 1.0))
	if Game.lamp <= 0.0:
		r = 14.0
	return r + lamp_boost

func _update_lamp(delta: float) -> void:
	_flick -= delta
	if _flick <= 0.0:
		_flick = randf_range(0.05, 0.14)
		var base := light_radius()
		var jitter := randf_range(-2.0, 2.0)
		if Game.lamp < 15.0 and randf() < 0.15:
			jitter -= randf_range(4.0, 10.0)
		light.texture_scale = (base + jitter) * 2.0 / 128.0
		light.energy = randf_range(1.1, 1.3) * (0.55 if Game.lamp <= 0.0 else 1.0)
	_flame_t += delta
	flame.texture = Art.tex("flame0" if int(_flame_t * 8.0) % 2 == 0 else "flame1")
	flame.visible = Game.lamp > 0.0
