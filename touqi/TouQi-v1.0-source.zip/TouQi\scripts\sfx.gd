extends Node
## 《头七》 procedural audio. Every sound/music track is synthesized at startup
## into mono 16-bit 22050 Hz AudioStreamWAV (no audio files). Rendering runs in
## parallel on the WorkerThreadPool; some music parts render at a reduced
## internal rate and are upsampled.

const SR := 22050
const SRF := 22050.0
const CR := 32 # control-rate block size

const LOOP_NAMES := [
	"music_ending", "music_lullaby", "music_tension", "amb_wind", "amb_drone",
	"amb_insects", "lamp_fire", "heartbeat_loop",
]
const SHOT_NAMES := [
	"bell_deep", "chime", "sting", "music_box_open", "sting_soft", "burn", "rooster",
	"laugh", "whisper", "drip", "fire_whoosh", "knock", "scrape", "oil_pour", "breath",
	"door_open", "glass", "tear", "paper_rustle", "thud", "cloth", "paper_page",
	"door_locked", "pickup", "step_paper", "ui_ok", "ui_back", "step_dirt", "step_wood",
	"step_stone", "ui_move", "type_blip",
]
# Sounds assembled from several parallel parts (rendered in phase 1, mixed in phase 2).
const PARTS := {
	"music_lullaby": ["lul_notes", "lul_drone"],
	"music_ending": ["end_lead", "end_pad"],
}
# Loops rendered and stored at a reduced rate (SR / div); Godot resamples on playback.
const RATE_DIV := {
	"music_lullaby": 2, "music_ending": 2, "music_tension": 4, "amb_wind": 4, "amb_drone": 4,
}

var gen_ms := 0.0
var _sounds: Dictionary = {}
var _bufs: Dictionary = {}
var _mtx := Mutex.new()
var _pool: Array[AudioStreamPlayer] = []
var _pool2d: Array[AudioStreamPlayer2D] = []
var _pi := 0
var _pi2 := 0
var _channels: Dictionary = {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 12:
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		_pool.append(p)
	for i in 10:
		var p2 := AudioStreamPlayer2D.new()
		p2.bus = "Master"
		p2.max_distance = 420.0
		p2.attenuation = 1.5
		add_child(p2)
		_pool2d.append(p2)
	_generate_all()


# ------------------------------------------------------------------ public API

func play(sname: String, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	var st: AudioStream = _sounds.get(sname)
	if st == null:
		push_warning("Sfx: unknown sound '%s'" % sname)
		return
	var p: AudioStreamPlayer = _pool[_pi]
	for k in _pool.size():
		var c: AudioStreamPlayer = _pool[(_pi + k) % _pool.size()]
		if not c.playing:
			p = c
			_pi = (_pi + k) % _pool.size()
			break
	_pi = (_pi + 1) % _pool.size()
	p.stop()
	p.stream = st
	p.volume_db = volume_db
	p.pitch_scale = maxf(pitch, 0.01)
	p.play()


func play_at(sname: String, pos: Vector2, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	var st: AudioStream = _sounds.get(sname)
	if st == null:
		push_warning("Sfx: unknown sound '%s'" % sname)
		return
	var p: AudioStreamPlayer2D = _pool2d[_pi2]
	for k in _pool2d.size():
		var c: AudioStreamPlayer2D = _pool2d[(_pi2 + k) % _pool2d.size()]
		if not c.playing:
			p = c
			_pi2 = (_pi2 + k) % _pool2d.size()
			break
	_pi2 = (_pi2 + 1) % _pool2d.size()
	p.stop()
	p.stream = st
	p.global_position = pos
	p.volume_db = volume_db
	p.pitch_scale = maxf(pitch, 0.01)
	p.play()


func loop(channel: String, sname: String, volume_db: float = 0.0, fade: float = 1.0) -> void:
	if not _sounds.has(sname):
		push_warning("Sfx: unknown sound '%s'" % sname)
		return
	var ch: Dictionary = _channels.get(channel, {})
	if not ch.is_empty():
		var op: AudioStreamPlayer = ch["player"]
		if ch["name"] == sname and is_instance_valid(op) and op.playing:
			_fade_to(ch, volume_db, fade, false)
			return
		_fade_to(ch, -80.0, fade, true)
	var p := AudioStreamPlayer.new()
	p.bus = "Master"
	p.stream = _sounds[sname]
	p.volume_db = -80.0
	add_child(p)
	p.play()
	var nch := {"name": sname, "player": p, "tween": null}
	_channels[channel] = nch
	_fade_to(nch, volume_db, fade, false)


func stop_loop(channel: String, fade: float = 1.0) -> void:
	if not _channels.has(channel):
		return
	_fade_to(_channels[channel], -80.0, fade, true)
	_channels.erase(channel)


func set_loop_volume(channel: String, volume_db: float, fade: float = 0.3) -> void:
	if _channels.has(channel):
		_fade_to(_channels[channel], volume_db, fade, false)


## Extra helper: change playback speed of a loop channel (e.g. heartbeat).
func set_loop_pitch(channel: String, pitch: float) -> void:
	if _channels.has(channel):
		var p: AudioStreamPlayer = _channels[channel]["player"]
		if is_instance_valid(p):
			p.pitch_scale = maxf(pitch, 0.01)


func stop_all_loops(fade: float = 0.5) -> void:
	for c in _channels.keys():
		stop_loop(c, fade)


func has_sound(sname: String) -> bool:
	return _sounds.has(sname)


func _fade_to(ch: Dictionary, db: float, t: float, free_after: bool) -> void:
	var p: AudioStreamPlayer = ch["player"]
	if not is_instance_valid(p):
		return
	var old: Tween = ch["tween"]
	if old != null and old.is_valid():
		old.kill()
	var to := 0.0 if free_after else db_to_linear(db)
	if t <= 0.0:
		if free_after:
			p.queue_free()
		else:
			p.volume_db = db
		return
	var tw := create_tween()
	tw.tween_method(_set_lin.bind(p), db_to_linear(p.volume_db), to, t)
	if free_after:
		tw.tween_callback(p.queue_free)
	ch["tween"] = tw


func _set_lin(v: float, p: AudioStreamPlayer) -> void:
	if is_instance_valid(p):
		p.volume_db = linear_to_db(maxf(v, 0.0001))


# ------------------------------------------------------------------ generation

func _generate_all() -> void:
	var t0 := Time.get_ticks_usec()
	var jobs: Array[String] = []
	var finals: Array[String] = []
	for nm in LOOP_NAMES + SHOT_NAMES:
		finals.append(nm)
		if PARTS.has(nm):
			for pt in PARTS[nm]:
				jobs.push_front(pt)
		else:
			jobs.append(nm)
	var g1 := WorkerThreadPool.add_group_task(func(i: int) -> void:
		var b: PackedFloat32Array = call("_g_" + jobs[i])
		_mtx.lock()
		_bufs[jobs[i]] = b
		_mtx.unlock(), jobs.size(), -1, true, "sfx_render")
	WorkerThreadPool.wait_for_group_task_completion(g1)
	var g2 := WorkerThreadPool.add_group_task(func(i: int) -> void:
		var nm: String = finals[i]
		var b: PackedFloat32Array
		if nm == "music_lullaby":
			b = _post_lullaby()
		elif nm == "music_ending":
			b = _post_ending()
		else:
			b = _bufs[nm]
		var w := _to_wav(b, nm in LOOP_NAMES, RATE_DIV.get(nm, 1))
		_mtx.lock()
		_sounds[nm] = w
		_mtx.unlock(), finals.size(), -1, true, "sfx_encode")
	WorkerThreadPool.wait_for_group_task_completion(g2)
	_bufs.clear()
	gen_ms = (Time.get_ticks_usec() - t0) / 1000.0


static func _to_wav(b: PackedFloat32Array, looped: bool, div: int = 1) -> AudioStreamWAV:
	var n := b.size()
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	for i in n:
		var v := b[i]
		if v != v:
			v = 0.0
		bytes.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = int(SR / float(div))
	w.stereo = false
	w.data = bytes
	if looped:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = n
	return w


# ------------------------------------------------------------------ DSP helpers

static func _rng(sd: int) -> RandomNumberGenerator:
	var r := RandomNumberGenerator.new()
	r.seed = sd
	return r


static func _zeros(n: int) -> PackedFloat32Array:
	var b := PackedFloat32Array()
	b.resize(n)
	b.fill(0.0)
	return b


static func _ns(sec: float) -> int:
	return int(sec * SRF)


static func _nctl(n: int) -> int:
	return int(n / float(CR)) + 2


static func _noise(n: int, sd: int) -> PackedFloat32Array:
	var b := _zeros(n)
	var s: int = (sd * 7919 + 17) & 0x7fffffff
	for i in n:
		s = (s * 1103515245 + 12345) & 0x7fffffff
		b[i] = float(s) / 1073741824.0 - 1.0
	return b


## Piecewise-linear curve from flat [t0, v0, t1, v1, ...], sampled every dt seconds.
static func _pl(pts: Array, count: int, dt: float) -> PackedFloat32Array:
	var out := _zeros(count)
	var np := pts.size() >> 1
	if np == 1:
		out.fill(float(pts[1]))
		return out
	var seg := 0
	for k in count:
		var t := k * dt
		while seg < np - 2 and t >= float(pts[seg * 2 + 2]):
			seg += 1
		var ta: float = pts[seg * 2]
		var va: float = pts[seg * 2 + 1]
		var tb: float = pts[seg * 2 + 2]
		var vb: float = pts[seg * 2 + 3]
		var u := 0.0
		if tb > ta:
			u = clampf((t - ta) / (tb - ta), 0.0, 1.0)
		out[k] = va + (vb - va) * u
	return out


static func _env(n: int, pts: Array, sr: float = SRF) -> PackedFloat32Array:
	return _pl(pts, n, 1.0 / sr)


static func _wander(nc: int, r: RandomNumberGenerator, lo: float, hi: float, p: float, sm: float) -> PackedFloat32Array:
	var out := _zeros(nc)
	var v := (lo + hi) * 0.5
	var tg := r.randf_range(lo, hi)
	for k in nc:
		if r.randf() < p:
			tg = r.randf_range(lo, hi)
		v += (tg - v) * sm
		out[k] = v
	return out


static func _mul(b: PackedFloat32Array, e: PackedFloat32Array) -> void:
	for i in mini(b.size(), e.size()):
		b[i] *= e[i]


## Multiply by a control-rate curve with linear interpolation.
static func _mulc(b: PackedFloat32Array, ctl: PackedFloat32Array) -> void:
	var n := b.size()
	var nc := ctl.size()
	var i := 0
	var k := 0
	while i < n:
		var v := ctl[mini(k, nc - 1)]
		var d := (ctl[mini(k + 1, nc - 1)] - v) / CR
		var e := mini(i + CR, n)
		for j in range(i, e):
			b[j] *= v
			v += d
		i = e
		k += 1


static func _mix(dst: PackedFloat32Array, src: PackedFloat32Array, gain: float, off: int = 0) -> void:
	var e := mini(src.size(), dst.size() - off)
	for j in e:
		dst[off + j] += src[j] * gain


static func _mixw(dst: PackedFloat32Array, src: PackedFloat32Array, gain: float, off: int) -> void:
	var n := dst.size()
	off = off % n
	var a := mini(src.size(), n - off)
	for j in a:
		dst[off + j] += src[j] * gain
	for j in range(a, src.size()):
		dst[(off + j) % n] += src[j] * gain


static func _lp1(b: PackedFloat32Array, fc: float, sr: float = SRF, prime: bool = false) -> void:
	var a := 1.0 - exp(-TAU * fc / sr)
	var y := 0.0
	var n := b.size()
	if prime:
		for i in range(maxi(0, n - 2048), n):
			y += a * (b[i] - y)
	for i in n:
		y += a * (b[i] - y)
		b[i] = y


static func _hp1(b: PackedFloat32Array, fc: float, sr: float = SRF) -> void:
	var a := 1.0 - exp(-TAU * fc / sr)
	var y := 0.0
	for i in b.size():
		y += a * (b[i] - y)
		b[i] = b[i] - y


## TPT state-variable filter; ctl = cutoff per CR block. mode 0 LP, 1 BP (unity peak), 2 HP.
static func _svf_c(b: PackedFloat32Array, ctl: PackedFloat32Array, q: float, mode: int, sr: float = SRF) -> PackedFloat32Array:
	var n := b.size()
	var out := _zeros(n)
	var k := 1.0 / q
	var ic1 := 0.0
	var ic2 := 0.0
	var nc := ctl.size()
	var i := 0
	var blk := 0
	while i < n:
		var fc := clampf(ctl[mini(blk, nc - 1)], 10.0, sr * 0.45)
		var g := tan(PI * fc / sr)
		var a1 := 1.0 / (1.0 + g * (g + k))
		var a2 := g * a1
		var a3 := g * a2
		var e := mini(i + CR, n)
		for j in range(i, e):
			var v0 := b[j]
			var v3 := v0 - ic2
			var v1 := a1 * ic1 + a2 * v3
			var v2 := ic2 + a2 * ic1 + a3 * v3
			ic1 = 2.0 * v1 - ic1
			ic2 = 2.0 * v2 - ic2
			if mode == 0:
				out[j] = v2
			elif mode == 1:
				out[j] = k * v1
			else:
				out[j] = v0 - k * v1 - v2
		i = e
		blk += 1
	return out


static func _svf(b: PackedFloat32Array, fc: float, q: float, mode: int, sr: float = SRF) -> PackedFloat32Array:
	return _svf_c(b, PackedFloat32Array([fc]), q, mode, sr)


static func _svf_p(b: PackedFloat32Array, pts: Array, q: float, mode: int, sr: float = SRF) -> PackedFloat32Array:
	return _svf_c(b, _pl(pts, _nctl(b.size()), CR / sr), q, mode, sr)


## Exponentially decaying sine partial added at sample offset (recurrence oscillator).
static func _ring(dst: PackedFloat32Array, off: int, f: float, amp: float, tau: float, wr: bool = false, sr: float = SRF) -> void:
	var w := TAU * f / sr
	if w >= PI * 0.95 or amp <= 0.0:
		return
	var n := dst.size()
	var ln := int(tau * sr * 5.3)
	if not wr:
		ln = mini(ln, n - off)
	var r := exp(-1.0 / (tau * sr))
	var c := 2.0 * r * cos(w)
	var r2 := r * r
	var za := 0.0
	var zb := r * sin(w) * amp
	if not wr:
		for j in range(off, off + ln):
			dst[j] += za
			var zc := c * zb - r2 * za
			za = zb
			zb = zc
		return
	for j in ln:
		dst[(off + j) % n] += za
		var zc := c * zb - r2 * za
		za = zb
		zb = zc


## Decaying noise click (differentiated -> bright).
static func _click(dst: PackedFloat32Array, off: int, ln: int, tau: float, amp: float, r: RandomNumberGenerator, wr: bool = false) -> void:
	var n := dst.size()
	var pv := 0.0
	var d := exp(-1.0 / maxf(tau * SRF, 1.0))
	var e := amp
	for j in ln:
		var k := off + j
		if k >= n:
			if not wr:
				return
			k = k % n
		var v := r.randf_range(-1.0, 1.0) * e
		dst[k] += v - pv * 0.6
		pv = v
		e *= d


## Random crackle gate: grains of random amplitude with fast exponential decay.
static func _grains(n: int, rate: float, r: RandomNumberGenerator, tmin: float = 0.001, tmax: float = 0.006) -> PackedFloat32Array:
	var out := _zeros(n)
	var g := 0.0
	var d := 0.9
	var p := rate / SRF
	for i in n:
		g *= d
		if r.randf() < p:
			var ga := r.randf()
			g = maxf(g, ga * ga)
			d = exp(-1.0 / (r.randf_range(tmin, tmax) * SRF))
		out[i] = g
	return out


## Cheap Schroeder reverb; the wet path runs at half rate. Returns dry+wet with tail.
static func _reverb(b: PackedFloat32Array, wet: float, fb: float, damp: float, tail: float, size: float = 1.0, sr: float = SRF) -> PackedFloat32Array:
	var bn := b.size()
	var hn := (bn + 1) >> 1
	var h := _zeros(hn)
	for i in hn:
		var j := i * 2
		var v := b[j]
		if j + 1 < bn:
			v = (v + b[j + 1]) * 0.5
		h[i] = v
	var wb := _rev_core(h, fb, damp, tail, size, sr * 0.5)
	var wn := wb.size()
	var n := mini(bn + int(tail * sr), wn * 2)
	var out := _zeros(n)
	for i in bn:
		out[i] = b[i]
	for i in wn:
		var k := i * 2
		if k >= n:
			break
		var a := wb[i] * wet
		out[k] += a
		if k + 1 < n:
			var c := a
			if i + 1 < wn:
				c = wb[i + 1] * wet
			out[k + 1] += (a + c) * 0.5
	return out


## 4 damped combs + 2 allpasses; returns wet signal only.
static func _rev_core(b: PackedFloat32Array, fb: float, damp: float, tail: float, size: float, sr: float) -> PackedFloat32Array:
	var bn := b.size()
	var n := bn + int(tail * sr)
	var out := _zeros(n)
	var sc := size * sr / SRF
	var l0 := maxi(int(557 * sc), 4)
	var l1 := maxi(int(593 * sc), 4)
	var l2 := maxi(int(641 * sc), 4)
	var l3 := maxi(int(709 * sc), 4)
	var la := maxi(int(277 * sc), 4)
	var lb := maxi(int(113 * sc), 4)
	var d0 := _zeros(l0)
	var d1 := _zeros(l1)
	var d2 := _zeros(l2)
	var d3 := _zeros(l3)
	var da := _zeros(la)
	var db := _zeros(lb)
	var i0 := 0
	var i1 := 0
	var i2 := 0
	var i3 := 0
	var ia := 0
	var ib := 0
	var s0 := 0.0
	var s1 := 0.0
	var s2 := 0.0
	var s3 := 0.0
	var dn := 1.0 - damp
	for i in n:
		var x := 0.0
		if i < bn:
			x = b[i]
		var y0 := d0[i0]
		s0 = y0 * dn + s0 * damp
		d0[i0] = x + s0 * fb
		i0 += 1
		if i0 == l0:
			i0 = 0
		var y1 := d1[i1]
		s1 = y1 * dn + s1 * damp
		d1[i1] = x + s1 * fb
		i1 += 1
		if i1 == l1:
			i1 = 0
		var y2 := d2[i2]
		s2 = y2 * dn + s2 * damp
		d2[i2] = x + s2 * fb
		i2 += 1
		if i2 == l2:
			i2 = 0
		var y3 := d3[i3]
		s3 = y3 * dn + s3 * damp
		d3[i3] = x + s3 * fb
		i3 += 1
		if i3 == l3:
			i3 = 0
		var s := (y0 + y1 + y2 + y3) * 0.25
		var ya := da[ia]
		var oa := ya - s
		da[ia] = s + ya * 0.5
		ia += 1
		if ia == la:
			ia = 0
		var yb := db[ib]
		var ob := yb - oa
		db[ib] = oa + yb * 0.5
		ib += 1
		if ib == lb:
			ib = 0
		out[i] = ob
	return out


## Crossfade the tail (beyond n) into the head -> seamless loop of length n.
static func _xloop(b: PackedFloat32Array, n: int) -> PackedFloat32Array:
	var x := b.size() - n
	var out := b.slice(0, n)
	for i in x:
		var t := float(i) / x
		out[i] = b[i] * sqrt(t) + b[n + i] * sqrt(1.0 - t)
	return out


## Wrap-add the tail (beyond n) onto the head.
static func _fold(b: PackedFloat32Array, n: int) -> PackedFloat32Array:
	var out := b.slice(0, n)
	for i in range(n, b.size()):
		out[(i - n) % n] += b[i]
	return out


## Linear-interpolation upsample by integer factor.
static func _up(b: PackedFloat32Array, f: int, wr: bool) -> PackedFloat32Array:
	var n := b.size()
	var out := _zeros(n * f)
	var inv := 1.0 / f
	for i in n:
		var a := b[i]
		var c := 0.0
		if i + 1 < n:
			c = b[i + 1]
		elif wr:
			c = b[0]
		var d := (c - a) * inv
		var k := i * f
		for j in f:
			out[k + j] = a + d * j
	return out


static func _peak(b: PackedFloat32Array) -> float:
	var mx := 0.0
	for i in b.size():
		var v := absf(b[i])
		if v > mx:
			mx = v
	return mx


static func _norm(b: PackedFloat32Array, peak: float) -> void:
	var mx := _peak(b)
	if mx > 1e-9 and is_finite(mx):
		var g := peak / mx
		for i in b.size():
			b[i] *= g


## Fade in/out (seconds) and normalize.
static func _fin(b: PackedFloat32Array, peak: float, fi: float, fo: float) -> PackedFloat32Array:
	var n := b.size()
	var a := mini(_ns(fi), n)
	for i in a:
		b[i] *= float(i) / a
	var c := mini(_ns(fo), n)
	for i in c:
		b[n - 1 - i] *= float(i) / c
	_norm(b, peak)
	return b


static func _soft(b: PackedFloat32Array, drive: float) -> void:
	for i in b.size():
		b[i] = tanh(b[i] * drive)


## Music-box tine: fundamental + beating copy + inharmonic partials.
static func _mbox(dst: PackedFloat32Array, off: int, f: float, amp: float, wr: bool, sr: float) -> void:
	_ring(dst, off, f, amp, 0.8, wr, sr)
	_ring(dst, off, f + 0.8, amp * 0.3, 0.6, wr, sr)
	_ring(dst, off, f * 2.01, amp * 0.32, 0.42, wr, sr)
	_ring(dst, off, f * 3.0, amp * 0.15, 0.25, wr, sr)
	_ring(dst, off, f * 4.2, amp * 0.14, 0.12, wr, sr)
	_ring(dst, off, f * 6.75, amp * 0.06, 0.05, wr, sr)


# ------------------------------------------------------------------ loops

func _g_amb_wind() -> PackedFloat32Array:
	var sr := SRF * 0.25
	var n := int(8.0 * sr)
	var m := n + int(1.5 * sr)
	var r := _rng(11)
	var w := _noise(m, 101)
	var nc := _nctl(m)
	var cut := _wander(nc, r, 280.0, 850.0, 0.02, 0.012)
	var lo := _svf_c(w, cut, 0.7, 0, sr)
	lo = _svf_c(lo, cut, 0.55, 0, sr)
	var wh := _svf_c(w, _wander(nc, r, 450.0, 1100.0, 0.008, 0.006), 10.0, 1, sr)
	var g := _zeros(nc)
	g.fill(0.35)
	var dt := CR / sr
	for gi in 4:
		var c := r.randf_range(0.5, m / sr - 0.5)
		var wd := r.randf_range(0.8, 2.0)
		var a := r.randf_range(0.4, 0.75)
		for k in nc:
			var u := (k * dt - c) / wd
			if absf(u) < 1.0:
				g[k] += a * (0.5 + 0.5 * cos(PI * u))
	var g2 := g.duplicate()
	for k in nc:
		g2[k] = g[k] * g[k]
	_mulc(lo, g)
	_mulc(wh, g2)
	_mix(lo, wh, 0.3)
	return _fin(_xloop(lo, n), 0.8, 0.0, 0.0)


func _g_amb_drone() -> PackedFloat32Array:
	var sr := SRF * 0.25
	var n := int(10.0 * sr)
	var m := n + int(1.0 * sr)
	var out := _zeros(m)
	var gl := _zeros(m)
	var fr := [55.0, 55.37, 58.27, 82.41, 82.86, 110.3, 1318.5, 1976.0]
	var am := [0.5, 0.42, 0.2, 0.3, 0.22, 0.07, 0.012, 0.007]
	for p in fr.size():
		_ring(out if p < 6 else gl, 0, fr[p], am[p], 1000.0, false, sr)
	var nc := _nctl(m)
	var lf := _zeros(nc)
	var sw := _zeros(nc)
	for k in nc:
		var t := k * CR / sr
		lf[k] = 0.75 + 0.25 * sin(TAU * 0.1 * t)
		sw[k] = 0.5 - 0.5 * cos(TAU * 0.1 * t + 2.0)
	_mulc(out, lf)
	_mulc(gl, sw)
	_mix(out, gl, 1.0)
	var nz := _noise(m, 7)
	_lp1(nz, 90.0, sr)
	_lp1(nz, 90.0, sr)
	_mix(out, nz, 1.2)
	_lp1(out, 1800.0, sr)
	return _fin(_xloop(out, n), 0.8, 0.0, 0.0)


func _g_amb_insects() -> PackedFloat32Array:
	var n := _ns(6.0)
	var out := _zeros(n)
	var r := _rng(23)
	for cr in 2:
		var f0 := 4550.0 if cr == 0 else 4120.0
		var gain := 1.0 if cr == 0 else 0.55
		var t := r.randf_range(0.0, 0.6)
		while t < 6.0:
			var pulses := r.randi_range(3, 4)
			var ga := gain * r.randf_range(0.6, 1.0)
			for q in pulses:
				var st := int((t + q * 0.048) * SRF)
				var ln := _ns(0.026)
				var w := TAU * (f0 + r.randf_range(-40.0, 40.0)) / SRF
				for j in ln:
					var e := sin(PI * float(j) / ln)
					out[(st + j) % n] += sin(w * j) * e * e * ga
			if cr == 0:
				t += r.randf_range(0.7, 1.6)
			else:
				t += r.randf_range(1.2, 2.6)
	var m := n + _ns(0.5)
	var bed := _noise(m, 29)
	_lp1(bed, 600.0)
	_hp1(bed, 150.0)
	_mix(out, _xloop(bed, n), 0.12)
	return _fin(out, 0.45, 0.0, 0.0)


func _g_lamp_fire() -> PackedFloat32Array:
	var n := _ns(4.0)
	var m := n + _ns(0.5)
	var r := _rng(31)
	var w := _noise(m, 31)
	_lp1(w, 140.0)
	_lp1(w, 140.0)
	_mulc(w, _wander(_nctl(m), r, 0.35, 1.0, 0.02, 0.01))
	_norm(w, 0.3)
	var out := _xloop(w, n)
	for k in 30:
		var a := r.randf()
		_click(out, r.randi_range(0, n - 1), r.randi_range(40, 120), r.randf_range(0.0004, 0.0012), a * a * 0.9 + 0.05, r, true)
	for k in 4:
		_ring(out, r.randi_range(0, n - 1), r.randf_range(1100.0, 1700.0), 0.12, 0.004, true)
	return _fin(out, 0.6, 0.0, 0.0)


func _g_heartbeat_loop() -> PackedFloat32Array:
	var n := _ns(1.6)
	var out := _zeros(n)
	var r := _rng(37)
	var beats := [0.0, 1.0, 0.27, 0.65, 0.8, 1.0, 1.07, 0.65]
	for b in 4:
		var st := int(float(beats[b * 2]) * SRF)
		var a: float = beats[b * 2 + 1]
		var ph := 0.0
		for j in _ns(0.55):
			var t := j / SRF
			ph += (34.0 + 26.0 * exp(-t / 0.035)) / SRF
			var v := sin(TAU * ph) * (1.0 - exp(-t / 0.003)) * exp(-t / 0.075)
			if j < 120:
				v += r.randf_range(-1.0, 1.0) * exp(-j / 25.0) * 0.2
			out[(st + j) % n] += v * a
	_lp1(out, 900.0, SRF, true)
	return _fin(out, 0.85, 0.0, 0.0)


# Lullaby: D pentatonic, 3/4, quarter = 0.8 s, 8 bars = 19.2 s. [freq, beats, late]
const LUL_MEL := [
	440.0, 2, 0.0, 369.99, 1, 0.0,
	329.63, 1, 0.0, 293.66, 1, 0.0, 329.63, 1, 0.0,
	369.99, 2, 0.0, 440.0, 1, 0.15,
	329.63, 3, 0.0,
	587.33, 2, 0.1, 493.88, 1, 0.0,
	440.0, 1, 0.0, 369.99, 1, 0.0, 440.0, 1, 0.0,
	493.88, 1, 0.0, 440.0, 1, 0.22, 329.63, 1, 0.0,
	293.66, 3, 0.06,
]
const LUL_BASS := [146.83, 110.0, 146.83, 110.0, 123.47, 146.83, 110.0, 146.83]
const LUL_Q := 0.8


func _g_lul_notes() -> PackedFloat32Array:
	var sr := SRF * 0.5
	var n := int(19.2 * sr)
	var out := _zeros(n)
	var r := _rng(41)
	var tmpl := {}
	var beat := 0.0
	for i in int(LUL_MEL.size() / 3.0):
		var f: float = LUL_MEL[i * 3]
		var bl: float = LUL_MEL[i * 3 + 1]
		var late: float = LUL_MEL[i * 3 + 2]
		_place_box(out, tmpl, f, (beat * LUL_Q + late) * sr, 0.5 + r.randf_range(-0.06, 0.06), r, sr)
		beat += bl
	for b in 8:
		_place_box(out, tmpl, LUL_BASS[b], b * 3 * LUL_Q * sr + 0.03 * sr, 0.3, r, sr)
	return out


## Places a cached music-box tine (one template per pitch, fixed random detune).
static func _place_box(out: PackedFloat32Array, tmpl: Dictionary, f: float, off: float, amp: float, r: RandomNumberGenerator, sr: float) -> void:
	if not tmpl.has(f):
		var tb := _zeros(int(3.4 * sr))
		_mbox(tb, 0, f * (1.0 + r.randf_range(-0.007, 0.007)), 1.0, false, sr)
		var fl := int(0.4 * sr)
		var tn := tb.size()
		for j in fl:
			tb[tn - 1 - j] *= float(j) / fl
		tmpl[f] = tb
	_mixw(out, tmpl[f], amp, int(off))


func _g_lul_drone() -> PackedFloat32Array:
	var sr := SRF * 0.25
	var n := int(19.2 * sr)
	var m := n + int(1.5 * sr)
	var out := _zeros(m)
	var fr := [73.42, 73.7, 110.0, 146.83]
	var am := [0.5, 0.35, 0.3, 0.08]
	for p in fr.size():
		var w: float = TAU * float(fr[p]) / sr
		var c := 2.0 * cos(w)
		var za := 0.0
		var zb: float = sin(w) * float(am[p])
		for i in m:
			out[i] += za
			var zc := c * zb - za
			za = zb
			zb = zc
	var nz := _noise(m, 43)
	_lp1(nz, 120.0, sr)
	_lp1(nz, 120.0, sr)
	_mix(out, nz, 0.8)
	var nc := _nctl(m)
	var lfo := _zeros(nc)
	for k in nc:
		lfo[k] = 0.65 + 0.35 * sin(TAU * k * CR / sr / 9.6)
	_mulc(out, lfo)
	return _xloop(out, n)


func _post_lullaby() -> PackedFloat32Array:
	var sr := SRF * 0.5
	var notes: PackedFloat32Array = _bufs["lul_notes"]
	var n := notes.size()
	var d := _up(_bufs["lul_drone"], 2, true)
	var mixb := _mix2(notes, 0.7 / maxf(_peak(notes), 1e-6), d, 0.12 / maxf(_peak(d), 1e-6))
	var out := _fold(_reverb(mixb, 0.5, 0.8, 0.45, 2.5, 1.3, sr), n)
	_norm(out, 0.8)
	return out


## a*ga + b*gb (length of a).
static func _mix2(a: PackedFloat32Array, ga: float, b: PackedFloat32Array, gb: float) -> PackedFloat32Array:
	var n := a.size()
	var out := _zeros(n)
	var m := mini(n, b.size())
	for i in m:
		out[i] = a[i] * ga + b[i] * gb
	for i in range(m, n):
		out[i] = a[i] * ga
	return out


func _g_music_tension() -> PackedFloat32Array:
	var sr := SRF * 0.25
	var n := int(8.0 * sr)
	var m := n + int(0.8 * sr)
	var s := _zeros(m)
	var fr := [73.42, 77.78, 110.0, 116.54]
	var am := [0.5, 0.45, 0.35, 0.3]
	for p in fr.size():
		var inc: float = float(fr[p]) / sr
		var ph := p * 0.23
		var a: float = am[p]
		for i in m:
			ph += inc
			if ph >= 1.0:
				ph -= 1.0
			s[i] += (2.0 * ph - 1.0) * a
	var nc := _nctl(m)
	var cut := _zeros(nc)
	var amc := _zeros(nc)
	for k in nc:
		var pu := exp(-fposmod(k * CR / sr, 0.8) / 0.16)
		cut[k] = 160.0 + 650.0 * pu
		amc[k] = 0.55 + 0.45 * pu
	var lp := _svf_c(s, cut, 1.4, 0, sr)
	_mulc(lp, amc)
	# sub thump on each pulse + faint dissonant high whine
	var sub := _zeros(m)
	_ring(sub, 0, 36.71, 1.0, 1000.0, false, sr)
	var hi := _zeros(m)
	_ring(hi, 0, 1244.5, 1.0, 1000.0, false, sr)
	_ring(hi, 0, 1318.5, 1.0, 1000.0, false, sr)
	var sc := _zeros(nc)
	var hc := _zeros(nc)
	for k in nc:
		var t := k * CR / sr
		sc[k] = 0.55 * exp(-fposmod(t, 0.8) / 0.12)
		hc[k] = 0.018 * (0.5 - 0.5 * cos(TAU * t / 8.0)) * (0.8 + 0.2 * sin(TAU * 5.0 * t))
	_mulc(sub, sc)
	_mulc(hi, hc)
	_mix(lp, sub, 1.0)
	_mix(lp, hi, 1.0)
	return _fin(_xloop(lp, n), 0.8, 0.0, 0.0)


# Ending: D pentatonic, 4/4, quarter = 0.6 s, 8 bars = 19.2 s. [freq, beats] (0 = rest)
const END_MEL := [
	440.0, 2, 493.88, 1, 440.0, 1,
	369.99, 3, 329.63, 1,
	293.66, 1, 329.63, 1, 369.99, 1, 440.0, 1,
	329.63, 4,
	369.99, 2, 440.0, 1, 493.88, 1,
	587.33, 2, 493.88, 1, 440.0, 1,
	369.99, 1, 329.63, 1, 293.66, 1, 329.63, 1,
	293.66, 3, 0.0, 1,
]
const END_Q := 0.6


func _g_end_lead() -> PackedFloat32Array:
	var sr := SRF * 0.5
	var n := int(19.2 * sr)
	var raw := _zeros(n)
	var bow := _noise(n, 53)
	_lp1(bow, 2500.0, sr)
	_norm(bow, 0.1)
	var gl := 1.0 - exp(-1.0 / (0.05 * sr))
	var f := 440.0
	var ph := 0.0
	var beat := 0.0
	var cnt := int(END_MEL.size() / 2.0)
	for ni in cnt:
		var tg: float = END_MEL[ni * 2]
		var bl: float = END_MEL[ni * 2 + 1]
		var st := int(beat * END_Q * sr)
		var dur := bl * END_Q
		beat += bl
		if tg <= 0.0:
			continue
		var last := ni >= cnt - 2
		var en := mini(st + int(dur * sr), n)
		for i in range(st, en):
			var tn := (i - st) / sr
			f += (tg - f) * gl
			var dep := 0.007 * clampf((tn - 0.2) / 0.4, 0.0, 1.0)
			var inc := f * (1.0 + dep * sin(TAU * 5.3 * tn)) / sr
			var a := minf(tn / 0.14, 1.0) * (1.0 - 0.15 * tn / dur)
			var rem := dur - tn
			if last:
				a *= clampf(rem / (dur * 0.6), 0.0, 1.0)
			elif rem < 0.07:
				a *= 0.55 + 0.45 * rem / 0.07
			ph += inc
			if ph >= 1.0:
				ph -= 1.0
			var s := 2.0 * ph - 1.0
			if ph < inc:
				var u := ph / inc
				s -= u + u - u * u - 1.0
			elif ph > 1.0 - inc:
				var u := (ph - 1.0) / inc
				s -= u * u + u + u + 1.0
			raw[i] = (s + bow[i]) * a
	# one SVF: resonant body (BP) + warm lowpass
	var out := _zeros(n)
	var k := 1.0 / 1.3
	var g := tan(PI * 1100.0 / sr)
	var a1 := 1.0 / (1.0 + g * (g + k))
	var a2 := g * a1
	var a3 := g * a2
	var ic1 := 0.0
	var ic2 := 0.0
	for i in n:
		var v3 := raw[i] - ic2
		var v1 := a1 * ic1 + a2 * v3
		var v2 := ic2 + a2 * ic1 + a3 * v3
		ic1 = 2.0 * v1 - ic1
		ic2 = 2.0 * v2 - ic2
		out[i] = v2 * 0.55 + k * v1 * 0.9
	_lp1(out, 3000.0, sr)
	return out


func _g_end_pad() -> PackedFloat32Array:
	var sr := SRF * 0.125
	var n := int(19.2 * sr)
	var out := _zeros(n)
	var chords := [
		[146.83, 220.0, 293.66, 369.99],
		[123.47, 246.94, 293.66, 369.99],
		[164.81, 246.94, 293.66, 329.63],
		[110.0, 220.0, 293.66, 329.63],
	]
	var cl := 4.8
	var ln := int((cl + 2.2) * sr)
	var env := _zeros(ln)
	for j in ln:
		var t := j / sr
		var e := 1.0
		if t < 1.5:
			e = sin(t / 1.5 * PI * 0.5)
			e *= e
		elif t > cl:
			e = exp(-(t - cl) / 0.6)
		env[j] = e
	for ci in 4:
		var st := int(ci * cl * sr)
		for fv in chords[ci]:
			for dt in 2:
				var w: float = TAU * (float(fv) + dt * 0.35) / sr
				var c := 2.0 * cos(w)
				var za := 0.0
				var zb := sin(w)
				for j in ln:
					out[(st + j) % n] += za * env[j]
					var zc := c * zb - za
					za = zb
					zb = zc
	return out


func _post_ending() -> PackedFloat32Array:
	var sr := SRF * 0.5
	var lead: PackedFloat32Array = _bufs["end_lead"]
	var n := lead.size()
	var pad := _up(_bufs["end_pad"], 4, true)
	var mixb := _mix2(lead, 0.7 / maxf(_peak(lead), 1e-6), pad, 0.3 / maxf(_peak(pad), 1e-6))
	var out := _fold(_reverb(mixb, 0.4, 0.8, 0.45, 2.5, 1.4, sr), n)
	_norm(out, 0.8)
	return out


# ------------------------------------------------------------------ one-shots

func _g_step_wood() -> PackedFloat32Array:
	var n := _ns(0.09)
	var out := _zeros(n)
	var ph := 0.0
	for i in n:
		var t := i / SRF
		ph += (85.0 + 70.0 * exp(-t / 0.012)) / SRF
		out[i] = sin(TAU * ph) * exp(-t / 0.022) * 0.9
	var nz := _noise(n, 41)
	for i in n:
		nz[i] *= exp(-i / (0.008 * SRF))
	_mix(out, _svf(nz, 900.0, 1.8, 1), 0.8)
	_mix(out, nz, 0.12)
	_lp1(out, 3500.0)
	return _fin(out, 0.8, 0.0, 0.015)


func _g_step_stone() -> PackedFloat32Array:
	var n := _ns(0.06)
	var nz := _noise(n, 43)
	for i in n:
		nz[i] *= exp(-i / (0.005 * SRF))
	var out := _svf(nz, 2400.0, 2.0, 1)
	_mix(out, _svf(nz, 4100.0, 3.0, 1), 0.5)
	_ring(out, 0, 140.0, 0.25, 0.01)
	return _fin(out, 0.7, 0.0, 0.01)


func _g_step_dirt() -> PackedFloat32Array:
	var n := _ns(0.1)
	var r := _rng(45)
	var nz := _noise(n, 45)
	var gr := _grains(n, 900.0, r, 0.0008, 0.003)
	for i in n:
		var t := i / SRF
		nz[i] *= (0.25 + gr[i]) * minf(t / 0.005, 1.0) * exp(-t / 0.028)
	_lp1(nz, 1500.0)
	_lp1(nz, 2500.0)
	_ring(nz, 0, 70.0, 0.12, 0.02)
	return _fin(nz, 0.7, 0.0, 0.015)


func _g_step_paper() -> PackedFloat32Array:
	var n := _ns(0.14)
	var r := _rng(47)
	var nz := _noise(n, 47)
	var gr := _grains(n, 700.0, r)
	for i in n:
		nz[i] *= (0.3 + gr[i]) * exp(-i / (0.03 * SRF))
	var out := _svf(nz, 1800.0, 0.9, 1)
	_hp1(nz, 2500.0)
	_mix(out, nz, 0.6)
	var ph := 0.0
	for i in n:
		var t := i / SRF
		ph += 95.0 / SRF
		out[i] += sin(TAU * ph) * exp(-t / 0.025) * minf(t / 0.003, 1.0) * 0.35
	return _fin(out, 0.7, 0.0, 0.02)


func _g_paper_rustle() -> PackedFloat32Array:
	var n := _ns(0.6)
	var r := _rng(49)
	var nz := _noise(n, 49)
	var gr := _grains(n, 120.0, r, 0.002, 0.008)
	var env := _env(n, [0.0, 0.0, 0.05, 1.0, 0.2, 0.5, 0.3, 0.9, 0.5, 0.3, 0.6, 0.0])
	for i in n:
		nz[i] *= (0.2 + gr[i]) * env[i]
	var out := _svf(nz, 3000.0, 0.8, 1)
	_hp1(nz, 4000.0)
	_mix(out, nz, 0.4)
	return _fin(out, 0.7, 0.005, 0.03)


func _g_door_open() -> PackedFloat32Array:
	var n := _ns(1.25)
	var r := _rng(51)
	var exc := _zeros(n)
	var fc := _env(n, [0.0, 160.0, 0.15, 320.0, 0.4, 480.0, 0.6, 260.0, 0.75, 200.0])
	var env := _env(n, [0.0, 0.0, 0.05, 1.0, 0.3, 0.8, 0.5, 1.0, 0.68, 0.6, 0.76, 0.0])
	var ph := 0.0
	var jit := 1.0
	for i in n:
		ph += fc[i] * jit / SRF
		if ph >= 1.0:
			ph -= 1.0
			jit = 1.0 + r.randf_range(-0.09, 0.09)
			exc[i] = r.randf_range(0.5, 1.0) * env[i]
		exc[i] += r.randf_range(-0.03, 0.03) * env[i]
	var out := _svf(exc, 700.0, 4.0, 1)
	_mix(out, _svf(exc, 1500.0, 5.0, 1), 0.6)
	_mix(out, _svf(exc, 2600.0, 6.0, 1), 0.3)
	_norm(out, 0.6)
	var st := _ns(0.78)
	var ph2 := 0.0
	for j in n - st:
		var t := j / SRF
		ph2 += (70.0 + 40.0 * exp(-t / 0.02)) / SRF
		out[st + j] += sin(TAU * ph2) * exp(-t / 0.06) * minf(t / 0.002, 1.0) * 0.7
	_click(out, st, 300, 0.004, 0.3, r)
	var rv := _reverb(out, 0.2, 0.6, 0.5, 0.3)
	return _fin(rv, 0.8, 0.0, 0.1)


func _g_door_locked() -> PackedFloat32Array:
	var n := _ns(0.5)
	var out := _zeros(n)
	var r := _rng(53)
	var ts := [0.0, 1.0, 0.07, 0.7, 0.19, 0.9, 0.25, 0.6, 0.36, 0.8]
	for k in 5:
		var st := int(float(ts[k * 2]) * SRF)
		var a: float = ts[k * 2 + 1]
		_click(out, st, 60, 0.0008, a * 0.6, r)
		for f in [2300.0, 3650.0, 5200.0]:
			_ring(out, st, f * r.randf_range(0.97, 1.03), a * 0.25, r.randf_range(0.02, 0.035))
		_ring(out, st, 160.0, a * 0.35, 0.02)
	var rv := _reverb(out, 0.15, 0.5, 0.5, 0.2)
	return _fin(rv, 0.75, 0.0, 0.05)


func _g_knock() -> PackedFloat32Array:
	var n := _ns(1.1)
	var out := _zeros(n)
	var r := _rng(55)
	var nz := _noise(_ns(0.1), 55)
	var bp := _svf(nz, 320.0, 1.5, 1)
	var ts := [0.0, 1.0, 0.33, 0.95, 0.66, 1.05]
	for k in 3:
		var st := int(float(ts[k * 2]) * SRF)
		var a: float = ts[k * 2 + 1]
		var ph := 0.0
		for j in _ns(0.3):
			var t := j / SRF
			ph += (70.0 + 35.0 * exp(-t / 0.015)) / SRF
			var v := sin(TAU * ph) * exp(-t / 0.07) * minf(t / 0.0015, 1.0)
			if j < bp.size():
				v += bp[j] * exp(-t / 0.03) * 1.5
			out[st + j] += v * a
		_click(out, st, 80, 0.002, a * 0.25, r)
	var rv := _reverb(out, 0.35, 0.7, 0.4, 0.5)
	return _fin(rv, 0.85, 0.0, 0.1)


func _g_pickup() -> PackedFloat32Array:
	var n := _ns(0.9)
	var out := _zeros(n)
	var f := 1975.5
	_ring(out, 0, f, 0.5, 0.35)
	_ring(out, 0, f * 2.76, 0.2, 0.12)
	_ring(out, 0, f * 5.4, 0.1, 0.05)
	var d := _ns(0.06)
	_ring(out, d, 2637.0, 0.25, 0.25)
	_ring(out, d, 2637.0 * 2.76, 0.08, 0.08)
	return _fin(out, 0.55, 0.002, 0.1)


func _g_paper_page() -> PackedFloat32Array:
	var n := _ns(0.45)
	var r := _rng(57)
	var nz := _noise(n, 57)
	var out := _svf_p(nz, [0.0, 1200.0, 0.25, 3800.0, 0.45, 2500.0], 1.0, 1)
	_mul(out, _env(n, [0.0, 0.0, 0.08, 1.0, 0.2, 0.6, 0.4, 0.0]))
	var gr := _grains(n, 60.0, r)
	_hp1(nz, 3000.0)
	for i in n:
		out[i] += nz[i] * gr[i] * 0.4
	return _fin(out, 0.65, 0.0, 0.03)


static func _blip(n: int, notes: Array) -> PackedFloat32Array:
	var out := _zeros(n)
	for k in int(notes.size() / 3.0):
		var off := int(float(notes[k * 3]) * SRF)
		var f: float = notes[k * 3 + 1]
		var tau: float = notes[k * 3 + 2]
		_ring(out, off, f, 1.0, tau)
		_ring(out, off, f * 3.0, 0.1, tau * 0.5)
		_ring(out, off, f * 2.0, 0.06, tau * 0.7)
	_lp1(out, 5000.0)
	return out


func _g_ui_move() -> PackedFloat32Array:
	return _fin(_blip(_ns(0.07), [0.0, 880.0, 0.018]), 0.4, 0.002, 0.01)


func _g_ui_ok() -> PackedFloat32Array:
	return _fin(_blip(_ns(0.24), [0.0, 659.25, 0.05, 0.07, 987.77, 0.06]), 0.45, 0.002, 0.03)


func _g_ui_back() -> PackedFloat32Array:
	return _fin(_blip(_ns(0.22), [0.0, 783.99, 0.045, 0.06, 523.25, 0.06]), 0.42, 0.002, 0.03)


func _g_type_blip() -> PackedFloat32Array:
	var n := _ns(0.03)
	var out := _zeros(n)
	_ring(out, 0, 1500.0, 1.0, 0.005)
	_click(out, 0, 25, 0.0004, 0.3, _rng(59))
	_lp1(out, 6000.0)
	return _fin(out, 0.3, 0.0005, 0.008)


func _g_chime() -> PackedFloat32Array:
	var n := _ns(4.5)
	var out := _zeros(n)
	var f := 466.16
	var rt := [1.0, 1.004, 2.76, 2.772, 5.40, 8.93, 13.3]
	var am := [0.6, 0.4, 0.35, 0.25, 0.18, 0.08, 0.04]
	var ta := [1.6, 1.5, 0.9, 0.85, 0.45, 0.25, 0.12]
	for k in rt.size():
		_ring(out, 0, f * float(rt[k]), am[k], ta[k])
	var r := _rng(61)
	var nz := _noise(_ns(0.01), 61)
	var bp := _svf(nz, 2000.0, 1.0, 1)
	for j in bp.size():
		out[j] += bp[j] * exp(-j / 40.0) * 0.3 * r.randf_range(0.9, 1.0)
	var rv := _reverb(out, 0.25, 0.75, 0.4, 1.0, 1.3)
	return _fin(rv, 0.8, 0.001, 0.4)


func _g_bell_deep() -> PackedFloat32Array:
	var sr := SRF * 0.25
	var lo := _zeros(int(4.8 * sr))
	var f := 98.0
	var rt := [0.5, 1.0, 1.006, 1.19, 1.5, 2.0, 2.006, 2.52, 3.0, 4.0]
	var am := [0.4, 0.6, 0.35, 0.35, 0.25, 0.45, 0.25, 0.2, 0.15, 0.08]
	var ta := [2.2, 1.8, 1.6, 1.4, 1.1, 1.0, 0.9, 0.6, 0.45, 0.3]
	for k in rt.size():
		_ring(lo, 0, f * float(rt[k]), am[k], ta[k], false, sr)
	var out := _up(lo, 4, false)
	_ring(out, 0, f * 5.4, 0.05, 0.15)
	_ring(out, 0, f * 6.8, 0.03, 0.1)
	var nz := _noise(_ns(0.08), 63)
	var bp := _svf(nz, 400.0, 1.2, 1)
	for j in bp.size():
		out[j] += bp[j] * exp(-j / (0.02 * SRF)) * 0.8
	_click(out, 0, 60, 0.001, 0.25, _rng(63))
	var rv := _reverb(out, 0.3, 0.8, 0.45, 1.4, 1.6)
	return _fin(rv, 0.85, 0.001, 0.6)


func _g_sting() -> PackedFloat32Array:
	var n := _ns(1.8)
	var r := _rng(65)
	var nz := _noise(n, 65)
	for i in n:
		var t := i / SRF
		nz[i] *= minf(t / 0.003, 1.0) * exp(-t / 0.25)
	_lp1(nz, 3000.0)
	var out := nz
	var ph := 0.0
	for i in n:
		var t := i / SRF
		ph += (30.0 + 30.0 * exp(-t / 0.15)) / SRF
		out[i] += sin(TAU * ph) * exp(-t / 0.4) * minf(t / 0.004, 1.0) * 0.9
	var fr := [1480.0, 1568.0, 1661.0, 2217.0]
	var scr := _zeros(n)
	for p in fr.size():
		var f0: float = fr[p]
		var ph2 := r.randf()
		var vp := r.randf() * TAU
		var vr := r.randf_range(6.0, 8.5)
		var i := 0
		while i < n:
			var t := i / SRF
			var pf := 1.0 - 0.45 * (1.0 - exp(-t / 0.6))
			var inc := f0 * pf * (1.0 + 0.015 * sin(TAU * vr * t + vp)) / SRF
			var g := minf(t / 0.01, 1.0) * exp(-t / 0.7) * 0.22
			for j in range(i, mini(i + CR, n)):
				ph2 += inc
				if ph2 >= 1.0:
					ph2 -= 1.0
				var s := 2.0 * ph2 - 1.0
				if ph2 < inc:
					var u := ph2 / inc
					s -= u + u - u * u - 1.0
				elif ph2 > 1.0 - inc:
					var u := (ph2 - 1.0) / inc
					s -= u * u + u + u + 1.0
				scr[j] += s * g
			i += CR
	_lp1(scr, 4000.0)
	_lp1(scr, 6000.0)
	_mix(out, scr, 1.0)
	_soft(out, 1.6)
	var rv := _reverb(out, 0.3, 0.7, 0.4, 0.6)
	return _fin(rv, 0.85, 0.0, 0.3)


func _g_sting_soft() -> PackedFloat32Array:
	var n := _ns(2.5)
	var nz := _noise(n, 67)
	_lp1(nz, 1200.0)
	_lp1(nz, 1800.0)
	var out := _zeros(n)
	for f in [65.41, 69.3, 98.0, 103.83]:
		_ring(out, 0, f, 0.25, 1000.0)
	_ring(out, 0, 2600.0, 0.01, 1000.0)
	var e := _zeros(n)
	var ec := _zeros(n)
	for i in n:
		var t := i / SRF
		var v := 0.0
		if t < 2.2:
			v = t / 2.2
			v = v * v * v
		else:
			v = maxf(1.0 - (t - 2.2) / 0.3, 0.0)
		e[i] = v
		ec[i] = sqrt(v)
	_mul(out, ec)
	_mul(nz, e)
	_mix(out, nz, 1.4)
	var rv := _reverb(out, 0.3, 0.7, 0.4, 0.5)
	return _fin(rv, 0.75, 0.0, 0.2)


func _g_whisper() -> PackedFloat32Array:
	var n := _ns(1.5)
	var r := _rng(69)
	var nz := _noise(n, 69)
	var nc := _nctl(n)
	var f1 := _svf_c(nz, _wander(nc, r, 400.0, 900.0, 0.05, 0.05), 5.0, 1)
	var f2 := _svf_c(nz, _wander(nc, r, 1300.0, 2600.0, 0.05, 0.05), 6.0, 1)
	var out := _zeros(n)
	_mix(out, f1, 0.6)
	_mix(out, f2, 0.8)
	var br := nz.duplicate()
	_hp1(br, 2000.0)
	_mix(out, br, 0.12)
	var env := _zeros(n)
	var t := 0.05
	while t < 1.35:
		var ln := r.randf_range(0.12, 0.22)
		var a := r.randf_range(0.5, 1.0)
		var st := _ns(t)
		var ls := _ns(ln)
		for j in mini(ls, n - st):
			env[st + j] = maxf(env[st + j], a * sin(PI * float(j) / ls))
		t += ln + r.randf_range(0.0, 0.08)
	_mul(out, env)
	var sib := _noise(n, 71)
	_hp1(sib, 4500.0)
	_hp1(sib, 4500.0)
	for k in 2:
		var st := _ns(r.randf_range(0.1, 1.2))
		var ls := _ns(0.08)
		for j in mini(ls, n - st):
			out[st + j] += sib[st + j] * sin(PI * float(j) / ls) * 0.5
	_lp1(out, 6000.0)
	var rv := _reverb(out, 0.25, 0.6, 0.5, 0.4)
	return _fin(rv, 0.6, 0.02, 0.15)


func _g_breath() -> PackedFloat32Array:
	var n := _ns(1.3)
	var nz := _noise(n, 73)
	var out := _svf_p(nz, [0.0, 900.0, 1.2, 550.0], 0.9, 1)
	var lo := nz.duplicate()
	_lp1(lo, 400.0)
	_mix(out, lo, 0.5)
	var env := _env(n, [0.0, 0.0, 0.25, 1.0, 0.6, 0.7, 1.2, 0.0])
	for i in n:
		out[i] *= env[i] * env[i]
	return _fin(out, 0.55, 0.0, 0.05)


func _g_scrape() -> PackedFloat32Array:
	var n := _ns(1.3)
	var r := _rng(75)
	var exc := _zeros(n)
	var fc := _env(n, [0.0, 35.0, 0.3, 55.0, 0.9, 45.0, 1.2, 30.0])
	var env := _env(n, [0.0, 0.0, 0.1, 1.0, 1.0, 0.85, 1.25, 0.0])
	var ph := 0.0
	var jit := 1.0
	for i in n:
		ph += fc[i] * jit / SRF
		if ph >= 1.0:
			ph -= 1.0
			jit = 1.0 + r.randf_range(-0.25, 0.25)
			exc[i] = r.randf_range(0.3, 1.0) * env[i]
	var out := _svf(exc, 180.0, 3.0, 1)
	_mix(out, _svf(exc, 420.0, 4.0, 1), 0.6)
	_mix(out, _svf(exc, 1100.0, 2.0, 1), 0.2)
	_norm(out, 0.6)
	var nz := _noise(n, 76)
	_lp1(nz, 700.0)
	_lp1(nz, 900.0)
	_mul(nz, env)
	_norm(nz, 0.3)
	_mix(out, nz, 1.0)
	var rv := _reverb(out, 0.2, 0.6, 0.5, 0.3)
	return _fin(rv, 0.8, 0.0, 0.1)


func _g_fire_whoosh() -> PackedFloat32Array:
	var n := _ns(1.6)
	var r := _rng(77)
	var nz := _noise(n, 77)
	var out := _svf_p(nz, [0.0, 200.0, 0.35, 2600.0, 0.8, 1400.0, 1.6, 400.0], 0.9, 0)
	var env := _env(n, [0.0, 0.0, 0.3, 1.0, 0.7, 0.6, 1.6, 0.0])
	var lo := nz.duplicate()
	_lp1(lo, 150.0)
	_lp1(lo, 150.0)
	_norm(lo, 0.6)
	var gr := _grains(n, 40.0, r)
	var hi := _noise(n, 78)
	_hp1(hi, 2500.0)
	for i in n:
		out[i] = (out[i] + lo[i] + hi[i] * gr[i] * 0.5) * env[i]
	return _fin(out, 0.8, 0.0, 0.05)


func _g_oil_pour() -> PackedFloat32Array:
	var n := _ns(1.3)
	var r := _rng(79)
	var out := _zeros(n)
	var t := 0.05
	while t < 1.15:
		var f0 := r.randf_range(280.0, 650.0)
		var a := r.randf_range(0.4, 1.0)
		var st := _ns(t)
		var ln := _ns(0.06)
		var ph := 0.0
		for j in mini(ln, n - st):
			var tt := j / SRF
			ph += f0 * (1.0 + 1.5 * tt / 0.06) / SRF
			out[st + j] += sin(TAU * ph) * minf(tt / 0.002, 1.0) * exp(-tt / 0.018) * a
		t += r.randf_range(0.05, 0.12)
	var bed := _svf(_noise(n, 80), 700.0, 0.7, 1)
	_mul(bed, _env(n, [0.0, 0.0, 0.08, 1.0, 1.1, 0.8, 1.3, 0.0]))
	_mix(out, bed, 0.12)
	_lp1(out, 3500.0)
	var rv := _reverb(out, 0.2, 0.5, 0.5, 0.2, 0.6)
	return _fin(rv, 0.75, 0.0, 0.05)


func _g_music_box_open() -> PackedFloat32Array:
	var r := _rng(81)
	var hs := SRF * 0.5
	var lo := _zeros(int(3.2 * hs))
	var ts := [0.4, 440.0, 0.95, 369.99, 1.6, 329.63, 2.1, 293.66]
	for k in 4:
		_mbox(lo, int(float(ts[k * 2]) * hs), float(ts[k * 2 + 1]) * r.randf_range(0.995, 1.005), 0.45, false, hs)
	var out := _up(lo, 2, false)
	_click(out, 0, 70, 0.0008, 0.6, r)
	_ring(out, 0, 2900.0, 0.2, 0.01)
	_ring(out, 0, 180.0, 0.35, 0.025)
	var rv := _reverb(out, 0.3, 0.72, 0.45, 0.8)
	return _fin(rv, 0.8, 0.0, 0.5)


func _g_rooster() -> PackedFloat32Array:
	var n := _ns(1.6)
	var r := _rng(83)
	var fc := _env(n, [0.0, 420.0, 0.12, 560.0, 0.16, 520.0, 0.2, 470.0, 0.24, 560.0, 0.36, 640.0, 0.4, 600.0,
		0.45, 560.0, 0.55, 780.0, 0.75, 820.0, 1.1, 760.0, 1.35, 560.0, 1.45, 450.0])
	var env := _env(n, [0.0, 0.0, 0.03, 0.8, 0.13, 0.7, 0.17, 0.1, 0.22, 0.1, 0.26, 0.85, 0.37, 0.75, 0.42, 0.15,
		0.47, 0.2, 0.55, 1.0, 1.1, 0.85, 1.35, 0.5, 1.5, 0.0])
	var src := _zeros(n)
	var ph := 0.0
	var sub := 1.0
	var jit := 0.0
	for i in n:
		jit += (r.randf_range(-1.0, 1.0) - jit) * 0.02
		var inc := fc[i] * (1.0 + 0.03 * jit) / SRF
		ph += inc
		if ph >= 1.0:
			ph -= 1.0
			sub = -sub
		var s := 2.0 * ph - 1.0
		if ph < inc:
			var u := ph / inc
			s -= u + u - u * u - 1.0
		elif ph > 1.0 - inc:
			var u := (ph - 1.0) / inc
			s -= u * u + u + u + 1.0
		src[i] = s * env[i] * (1.0 + 0.25 * sub)
	var out := _svf(src, 900.0, 3.0, 1)
	_mix(out, _svf(src, 1900.0, 4.0, 1), 0.7)
	_mix(out, _svf(src, 3100.0, 5.0, 1), 0.35)
	var rv := _reverb(out, 0.3, 0.65, 0.5, 0.5)
	return _fin(rv, 0.75, 0.005, 0.1)


func _g_laugh() -> PackedFloat32Array:
	var n := _ns(1.6)
	var r := _rng(85)
	var src := _zeros(n)
	var ts := [0.0, 0.17, 0.33, 0.48, 0.63, 0.8, 1.0]
	var ph := 0.0
	for k in ts.size():
		var st := int(float(ts[k]) * SRF)
		var dur := r.randf_range(0.11, 0.16)
		var ls := _ns(dur)
		var f0 := 230.0 - k * 11.0
		var a := 1.0 - k * 0.08
		for j in mini(ls, n - st):
			var t := j / SRF
			var inc := f0 * (1.0 - 0.08 * t / dur) / SRF
			ph += inc
			if ph >= 1.0:
				ph -= 1.0
			var e := minf(t / 0.015, 1.0) * exp(-t / (dur * 0.45))
			src[st + j] += ((2.0 * ph - 1.0) * 0.7 + r.randf_range(-0.35, 0.35)) * e * a
	var out := _svf(src, 520.0, 4.0, 1)
	_mix(out, _svf(src, 1750.0, 6.0, 1), 0.6)
	_lp1(out, 2500.0)
	var rv := _reverb(out, 0.45, 0.72, 0.5, 0.8, 1.2)
	return _fin(rv, 0.5, 0.005, 0.2)


func _g_thud() -> PackedFloat32Array:
	var n := _ns(0.6)
	var out := _zeros(n)
	var r := _rng(87)
	var ph := 0.0
	for i in n:
		var t := i / SRF
		ph += (38.0 + 37.0 * exp(-t / 0.05)) / SRF
		out[i] = sin(TAU * ph) * exp(-t / 0.14) * minf(t / 0.002, 1.0)
	var nz := _noise(n, 87)
	_lp1(nz, 250.0)
	_lp1(nz, 250.0)
	for i in n:
		nz[i] *= exp(-i / (0.06 * SRF))
	_norm(nz, 0.6)
	_mix(out, nz, 1.0)
	_click(out, 0, 70, 0.0015, 0.15, r)
	var rv := _reverb(out, 0.2, 0.6, 0.5, 0.3)
	return _fin(rv, 0.85, 0.0, 0.1)


func _g_cloth() -> PackedFloat32Array:
	var n := _ns(0.5)
	var nz := _noise(n, 89)
	var out := _svf_p(nz, [0.0, 700.0, 0.15, 2800.0, 0.4, 1500.0], 0.7, 1)
	var env := _env(n, [0.0, 0.0, 0.06, 0.6, 0.14, 1.0, 0.3, 0.4, 0.45, 0.0])
	_hp1(nz, 3000.0)
	for i in n:
		out[i] = (out[i] + nz[i] * 0.2) * env[i] * (0.8 + 0.2 * sin(TAU * 28.0 * i / SRF))
	return _fin(out, 0.6, 0.0, 0.03)


func _g_glass() -> PackedFloat32Array:
	var n := _ns(0.9)
	var out := _zeros(n)
	var r := _rng(91)
	var t := 0.0
	var gap := 0.08
	for k in 11:
		var a := 1.0 if k == 0 else r.randf_range(0.25, 0.7)
		var st := _ns(t)
		_click(out, st, r.randi_range(20, 60), 0.0006, a * 0.7, r)
		for q in 3:
			_ring(out, st, r.randf_range(2500.0, 7000.0), a * 0.3, r.randf_range(0.02, 0.07))
		t += gap * r.randf_range(0.5, 1.3)
		gap *= 0.8
	for k in 2:
		_ring(out, _ns(r.randf_range(0.4, 0.6)), r.randf_range(4000.0, 6000.0), 0.15, 0.15)
	var rv := _reverb(out, 0.2, 0.55, 0.4, 0.3, 0.8)
	return _fin(rv, 0.75, 0.0, 0.1)


func _g_drip() -> PackedFloat32Array:
	var n := _ns(0.3)
	var out := _zeros(n)
	var ph := 0.0
	var st := _ns(0.02)
	for j in n - st:
		var t := j / SRF
		ph += 750.0 * (1.0 + 0.9 * exp(-t / 0.01)) / SRF
		out[st + j] = sin(TAU * ph) * minf(t / 0.001, 1.0) * exp(-t / 0.06)
	var rv := _reverb(out, 0.6, 0.82, 0.35, 1.4, 2.2)
	return _fin(rv, 0.6, 0.0, 0.3)


func _g_burn() -> PackedFloat32Array:
	var n := _ns(2.0)
	var r := _rng(93)
	var hi := _noise(n, 93)
	var gr := _grains(n, 80.0, r, 0.0008, 0.004)
	var ramp := _env(n, [0.0, 0.1, 0.5, 0.7, 2.0, 1.0])
	for i in n:
		hi[i] *= gr[i] * ramp[i]
	_hp1(hi, 1500.0)
	var lo := _noise(n, 94)
	_lp1(lo, 300.0)
	_lp1(lo, 300.0)
	_mul(lo, _env(n, [0.0, 0.0, 0.6, 0.7, 2.0, 1.0]))
	_norm(lo, 0.35)
	var hs := _noise(n, 95)
	_hp1(hs, 5000.0)
	_mul(hs, ramp)
	var out := hi
	_norm(out, 0.8)
	_mix(out, lo, 1.0)
	_mix(out, hs, 0.04)
	for k in 6:
		_ring(out, r.randi_range(0, n - 1), r.randf_range(900.0, 1500.0), 0.15, 0.005)
	return _fin(out, 0.75, 0.05, 0.3)


func _g_tear() -> PackedFloat32Array:
	var n := _ns(0.8)
	var r := _rng(97)
	var nz := _noise(n, 97)
	var env := _env(n, [0.0, 0.0, 0.02, 0.8, 0.3, 1.0, 0.35, 0.3, 0.42, 1.0, 0.7, 0.7, 0.8, 0.0])
	var ph := 0.0
	var f := 120.0
	var duty := 0.5
	var a := 1.0
	for i in n:
		ph += f / SRF
		if ph >= 1.0:
			ph -= 1.0
			f = r.randf_range(60.0, 180.0)
			duty = r.randf_range(0.2, 0.6)
			a = r.randf_range(0.4, 1.0)
		var g := a if ph < duty else 0.1 * a
		nz[i] *= g * env[i]
	var out := _svf(nz, 2500.0, 0.8, 1)
	_hp1(nz, 1200.0)
	_mix(out, nz, 0.5)
	return _fin(out, 0.75, 0.0, 0.03)
