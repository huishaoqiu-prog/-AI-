extends Node
## 自动化通关测试：godot --path . -- --autotest [--ending=true|sub|paper]
## 逐章推进剧情，在关键节点截图到 res://_shots/

var world: Node
var safe := true
var mode := "true"
var _dresser_n := 0
var log_lines: Array = []

func _ready() -> void:
	name = "Bot"
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--ending="):
			mode = a.get_slice("=", 1)
	_run()

func L(s: String) -> void:
	var line := "[BOT %.1fs ch%d] %s" % [Time.get_ticks_msec() / 1000.0, Game.chapter, s]
	print(line)
	log_lines.append(line)

func next_choice(q: String, opts: Array) -> int:
	L("choice: %s %s" % [q, str(opts)])
	if "不出声" in opts:
		return 1
	if "拉开抽屉" in opts:
		_dresser_n += 1
		return 0 if _dresser_n == 1 else 1
	if "给它点上眼睛" in opts:
		return 0 if mode == "sub" else 1
	return 0

func next_tear() -> int:
	return 3

func next_code() -> String:
	return "1208"

func until(cond: Callable, timeout: float = 30.0) -> bool:
	var t := 0.0
	while not cond.call():
		await get_tree().process_frame
		t += get_process_delta_time()
		if t > timeout:
			L("TIMEOUT waiting frozen=%d busy=%s paused=%s hidden=%s dead=%s" % [Game.frozen, world.ui.busy, get_tree().paused, world.player.is_hidden, world._dead])
			return false
	return true

func idle() -> void:
	if not is_inside_tree():
		return
	await get_tree().process_frame
	await until(func(): return Game.frozen == 0 and not world.ui.busy)
	await get_tree().create_timer(0.15).timeout

func shot(n: String) -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	var img := get_viewport().get_texture().get_image()
	img.save_png("res://_shots/%s.png" % n)
	L("shot " + n)

func tp(t: Vector2i, face: Vector2 = Vector2.UP) -> void:
	world.player.global_position = world.tile_center(t) + Vector2(0, 6)
	world.player.facing = face
	world.cam.global_position = world.player.global_position
	await get_tree().process_frame
	await idle()

func use(id: String) -> void:
	var o: Node2D = world.obj(id)
	if o == null:
		L("MISSING obj " + id)
		return
	L("use " + id)
	var ft: Node2D = world.focus_target()
	if ft != o:
		L("FOCUS MISMATCH: wanted %s, picker gives %s" % [id, ft.id if ft else "none"])
	if o.is_door and not o.locked and id != "backgate":
		world.open_door(id)
	else:
		await world.story.interact(o)
	await idle()

func walk_to(t: Vector2i, timeout: float = 25.0) -> bool:
	var target: Vector2 = world.tile_center(t)
	var el := 0.0
	while el < timeout:
		var p: Vector2 = world.player.global_position
		if p.distance_to(target) < 6.0:
			world.bot_input = Vector2.ZERO
			return true
		var path: PackedVector2Array = world.find_path(p, target)
		var nxt := target if path.is_empty() else path[0]
		var d := nxt - p
		world.bot_input = d.normalized() if d.length() > 1.0 else Vector2.ZERO
		await get_tree().physics_frame
		el += get_physics_process_delta_time()
	world.bot_input = Vector2.ZERO
	L("walk_to TIMEOUT %s at %s" % [str(t), str(world.tile_of(world.player.global_position))])
	return false

func keep_alive() -> void:
	Game.lamp = maxf(Game.lamp, 70.0)
	Game.eternal = maxf(Game.eternal, 70.0)

func _process(_d: float) -> void:
	if safe:
		keep_alive()

func _run() -> void:
	await get_tree().create_timer(0.5).timeout
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--ai="):
			await _ai_test(a.get_slice("=", 2) if a.count("=") > 1 else "walk")
			return
	await until(func(): return Game.flag("intro0") and Game.frozen == 0, 60)
	await shot("c0_01_gate")
	# ---- 戌时：走路去灵堂
	var ok := await walk_to(Vector2i(21, 15))
	L("walk to hall ok=%s" % ok)
	await idle()
	await shot("c0_02_hall")
	await tp(Vector2i(21, 11))
	await use("eternal")
	await until(func(): return Game.flag("intro1"))
	await idle()
	# ---- 亥时
	await tp(Vector2i(30, 32))
	await shot("c1_01_kitchen")
	await tp(Vector2i(31, 31))
	await use("oilvat")
	await tp(Vector2i(8, 31))
	await shot("c1_02_shop")
	await tp(Vector2i(10, 31))
	await use("stand")
	await tp(Vector2i(22, 26), Vector2.LEFT)
	await get_tree().create_timer(0.4).timeout
	await shot("c1_03_sighting")
	await idle()
	await tp(Vector2i(21, 11))
	await use("eternal")
	await until(func(): return Game.flag("intro2"))
	await idle()
	# ---- 子时
	await tp(Vector2i(22, 22))
	await idle()
	await get_tree().create_timer(0.5).timeout
	await idle()
	L("knocked=%s girl=%s at %s" % [Game.flag("knocked"), world.girl.state, str(world.tile_of(world.girl.global_position))])
	world.girl.global_position = world.player.global_position + Vector2(40, 10)
	await get_tree().create_timer(0.2).timeout
	await shot("c2_01_girl_near")
	world.girl.global_position = world.tile_center(Vector2i(4, 32))
	await tp(Vector2i(22, 14))
	await use("coffin")
	L("key=%s" % Game.has("key_east"))
	await tp(Vector2i(36, 19))
	await use("door_east")
	await tp(Vector2i(36, 14))
	await shot("c2_02_east")
	await tp(Vector2i(34, 10))
	await use("east_desk")
	await until(func(): return Game.flag("intro3"))
	await idle()
	# ---- 丑时
	await tp(Vector2i(22, 15))
	await shot("c3_01_hall_dark")
	await tp(Vector2i(39, 11))
	await use("east_bed")
	await tp(Vector2i(31, 10))
	await use("dresser")
	await use("dresser")
	await shot("c3_02_mirror")
	await world.ui.show_rules(true)
	await until(func(): return Game.flag("intro4"))
	await idle()
	# ---- 寅时
	await tp(Vector2i(6, 19))
	await use("door_west")
	await tp(Vector2i(9, 11), Vector2.RIGHT)
	world.hide_player(world.obj("west_wardrobe"))
	safe = true
	await get_tree().create_timer(2.0).timeout
	await shot("c4_01_hiding")
	world.unhide()
	world.girl.set_state("wander")
	world.girl.global_position = world.tile_center(Vector2i(38, 33))
	await tp(Vector2i(2, 10))
	await use("west_bed")
	await tp(Vector2i(6, 10))
	await use("musicbox")
	await tp(Vector2i(5, 10))
	await use("brush_obj")
	await use("west_desk")
	await shot("c4_02_west")
	await tp(Vector2i(28, 4), Vector2.RIGHT)
	await use("door_shrine")
	await tp(Vector2i(35, 5))
	await shot("c4_03_shrine")
	await tp(Vector2i(36, 2))
	await use("tablets")
	await tp(Vector2i(34, 2), Vector2.RIGHT)
	await use("cinnabar")
	await tp(Vector2i(35, 4))
	await use("shrine_table")
	await until(func(): return Game.flag("intro5"), 40)
	await idle()
	# ---- 卯时
	await shot("c5_01_shadow")
	if mode == "paper":
		safe = true
		world.story._rooster = 3.0
		await until(func(): return get_tree().root.has_node("AutotestEnding_paper"), 90)
		return
	if mode == "sub":
		await tp(Vector2i(39, 4))
		await use("effigy_me")
		await until(func(): return get_tree().root.has_node("AutotestEnding_substitute"), 90)
		return
	await tp(Vector2i(11, 25), Vector2.LEFT)
	await use("girl_proxy")
	await shot("c5_02_sister")
	if not Game.has("oil"):
		Game.give("oil")
	await tp(Vector2i(21, 11))
	await use("eternal")
	await get_tree().create_timer(1.0).timeout
	await shot("c5_03_dawn")
	await tp(Vector2i(20, 1))
	world.story.interact(world.obj("backgate"))
	return
	await until(func(): return get_tree().root.has_node("AutotestEnding_true"), 60)
	await get_tree().create_timer(0.5).timeout
	await shot("c6_ending")

## 潜行平衡测试：机器人在院子里随机走动，统计被纸人发现/抓住的情况
func _ai_test(style: String) -> void:
	safe = false
	world.bot_sneak = style == "sneak"
	var start := Time.get_ticks_msec() / 1000.0
	L("AI TEST start deaths=%d style=%s" % [Game.deaths, style])
	var rooms := ["yard", "kitchen", "shop", "hall", "back", "gatehall", "east", "west"]
	var last_state := ""
	var chases := 0
	var idx := 0
	while Time.get_ticks_msec() / 1000.0 - start < 70.0:
		var room: String = rooms[randi() % rooms.size()]
		var t: Vector2i = world.random_open_tile_in(room)
		var tw := Time.get_ticks_msec()
		var el := 0.0
		var target: Vector2 = world.tile_center(t)
		while el < 20.0 and not world._dead:
			var p: Vector2 = world.player.global_position
			if p.distance_to(target) < 6.0:
				break
			var path: PackedVector2Array = world.find_path(p, target)
			var nxt := target if path.is_empty() else path[0]
			world.bot_input = (nxt - p).normalized()
			await get_tree().physics_frame
			el += get_physics_process_delta_time()
			var gs: String = world.girl.state
			if gs != last_state:
				if gs == "chase":
					chases += 1
				L("girl %s -> %s  dist=%.0f" % [last_state, gs, world.girl.global_position.distance_to(p)])
				last_state = gs
		world.bot_input = Vector2.ZERO
		if world._dead:
			L("CAUGHT after %.1fs (chases=%d)" % [Time.get_ticks_msec() / 1000.0 - start, chases])
			return
		idx += 1
		if idx % 3 == 0:
			await shot("ai_%02d" % idx)
	L("AI TEST survived 70s, chases=%d, deaths=%d" % [chases, Game.deaths])
	get_tree().quit()