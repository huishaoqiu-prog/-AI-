extends Node2D
## 标题画面：风中摇晃的白灯笼、飘落的纸钱、童谣

var lantern: Sprite2D
var light: PointLight2D
var menu: VBoxContainer
var items: Array = []
var idx := 0
var t := 0.0
var ready_input := false
var ending_view := false
var info_lbl: Label

func _ready() -> void:
	var cm := CanvasModulate.new()
	cm.color = Color("16141c")
	add_child(cm)
	# 背景：屋檐与墙
	var bg := Sprite2D.new()
	var img := Image.create(480, 270, false, Image.FORMAT_RGBA8)
	img.fill(Color("0a090e"))
	for x in 480:
		for y in range(0, 26):
			var lane := x % 4
			var c := Color("2a2832") if lane != 0 else Color("1c1a22")
			img.set_pixel(x, y, c)
		img.set_pixel(x, 26, Color("1a1820"))
		img.set_pixel(x, 27, Color("3a3844") if x % 4 != 0 else Color("1a1820"))
		for y in range(28, 200):
			var c2 := Color("4a4640").lerp(Color("55514a"), Art.hsh(x / 3, y / 4, 5))
			if Art.hsh(x, 0, 25) > 0.85 and y < 60 + int(Art.hsh(x, 1, 26) * 50):
				c2 = c2.darkened(0.15)
			img.set_pixel(x, y, c2)
		for y in range(200, 270):
			var c3 := Color("2c2e34").lerp(Color("34363c"), Art.hsh(x / 8, y / 4, 7))
			if y % 4 == 3 or (x + (4 if (y / 4) % 2 == 1 else 0)) % 8 == 7:
				c3 = Color("1e2024")
			img.set_pixel(x, y, c3)
	# 一扇贴了白纸的门
	for y in range(80, 200):
		for x in range(30, 130):
			img.set_pixel(x, y, Color("3a1010") if x != 80 else Color("1a0404"))
	for y in range(100, 140):
		for x in range(40, 60):
			img.set_pixel(x, y, Color("8a8880"))
		for x in range(100, 120):
			img.set_pixel(x, y, Color("8a8880"))
	bg.texture = ImageTexture.create_from_image(img)
	bg.centered = false
	add_child(bg)

	lantern = Sprite2D.new()
	lantern.texture = Art.tex("lantern_big")
	lantern.offset = Vector2(-22, 0)
	lantern.centered = false
	lantern.position = Vector2(360, 24)
	add_child(lantern)
	light = PointLight2D.new()
	light.texture = Art.tex("light_round")
	light.texture_scale = 3.2
	light.energy = 1.2
	light.color = Color(1.0, 0.9, 0.75)
	add_child(light)
	var l2 := PointLight2D.new()
	l2.texture = Art.tex("light_soft")
	l2.texture_scale = 5.0
	l2.energy = 0.25
	l2.color = Color(0.5, 0.6, 0.9)
	l2.position = Vector2(80, 60)
	add_child(l2)

	# 纸钱
	var p := CPUParticles2D.new()
	p.texture = _coin_tex()
	p.amount = 18
	p.lifetime = 9.0
	p.preprocess = 9.0
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(260, 4)
	p.position = Vector2(240, -10)
	p.direction = Vector2(0.3, 1)
	p.spread = 20.0
	p.gravity = Vector2(4, 14)
	p.initial_velocity_min = 4.0
	p.initial_velocity_max = 10.0
	p.angular_velocity_min = -90.0
	p.angular_velocity_max = 90.0
	add_child(p)

	var layer := CanvasLayer.new()
	add_child(layer)
	var post := ColorRect.new()
	post.set_anchors_preset(Control.PRESET_FULL_RECT)
	post.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var mat := ShaderMaterial.new()
	mat.shader = load("res://shaders/post.gdshader")
	post.material = mat
	layer.add_child(post)
	var ui := CanvasLayer.new()
	ui.layer = 10
	add_child(ui)
	var title := Label.new()
	title.text = "头七"
	title.add_theme_font_size_override("font_size", 48)
	title.add_theme_color_override("font_color", Color("e8e2d4"))
	title.position = Vector2(150, 40)
	ui.add_child(title)
	var sub := Label.new()
	sub.text = "—— 长明灯，不能灭 ——"
	sub.add_theme_color_override("font_color", Color("a03a34"))
	sub.position = Vector2(150, 100)
	ui.add_child(sub)
	menu = VBoxContainer.new()
	menu.position = Vector2(168, 140)
	menu.add_theme_constant_override("separation", 4)
	ui.add_child(menu)
	info_lbl = Label.new()
	info_lbl.position = Vector2(8, 252)
	info_lbl.add_theme_color_override("font_color", Color("5e584e"))
	info_lbl.text = ["建议佩戴耳机　WASD 移动　E 确认　F11 全屏", "建议佩戴耳机（胆小的话，建议戴两副）　E 确认", "本故事纯属虚构。如有雷同，那你家院子是挺吓人的。"][randi() % 3]
	ui.add_child(info_lbl)
	var fade := ColorRect.new()
	fade.color = Color.BLACK
	fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(fade)
	create_tween().tween_property(fade, "color:a", 0.0, 2.0)
	_build_menu()
	Sfx.stop_all_loops(0.5)
	Sfx.loop("music", "music_lullaby", -10.0, 2.0)
	Sfx.loop("amb", "amb_wind", -18.0, 2.0)
	get_tree().create_timer(0.4).timeout.connect(func(): ready_input = true)
	if Game.autotest:
		get_tree().create_timer(2.6).timeout.connect(func():
			get_viewport().get_texture().get_image().save_png("res://_shots/title.png")
			Game.new_game()
			for a in OS.get_cmdline_user_args():
				if a.begins_with("--ai="):
					Game.chapter = int(a.get_slice("=", 1))
					for k in ["intro0", "intro1", "intro2", "intro3", "intro4", "knocked", "girl_seen", "east_open", "west_open"]:
						Game.flags[k] = true
					Game.player_pos = Vector2(22 * 16, 15 * 16)
					Game.save_checkpoint()
			Game.start_world())

func _coin_tex() -> Texture2D:
	var i := Image.create(5, 5, false, Image.FORMAT_RGBA8)
	for y in 5:
		for x in 5:
			var d := Vector2(x - 2, y - 2).length()
			if d <= 2.3 and not (x == 2 and y == 2):
				i.set_pixel(x, y, Color("d8cc9a"))
	return ImageTexture.create_from_image(i)

func _build_menu() -> void:
	items = []
	if Game.has_save():
		items.append(["继续守灵（%s）" % Game.CHAPTERS[int(Game.checkpoint.chapter)].name, "continue"])
	items.append(["开始守灵", "new"])
	if not Game.endings_seen.is_empty():
		items.append(["结局（%d/3）" % Game.endings_seen.size(), "endings"])
	items.append(["离开", "quit"])
	idx = 0
	_render()

func _render() -> void:
	for c in menu.get_children():
		c.queue_free()
	for k in items.size():
		var l := Label.new()
		l.text = ("▶ " if k == idx else "   ") + items[k][0]
		l.add_theme_color_override("font_color", Color("f0d090") if k == idx else Color("8e887c"))
		menu.add_child(l)

func _process(delta: float) -> void:
	t += delta
	lantern.rotation = sin(t * 0.9) * 0.07 + sin(t * 2.3) * 0.015
	light.position = lantern.position + Vector2(0, 30).rotated(lantern.rotation)
	light.energy = 1.15 + randf_range(-0.06, 0.06)
	if not ready_input:
		return
	if ending_view:
		if Input.is_action_just_pressed("act") or Input.is_action_just_pressed("pause"):
			ending_view = false
			info_lbl.text = "建议佩戴耳机　WASD 移动　E 确认　F11 全屏"
			_build_menu()
		return
	if Input.is_action_just_pressed("up"):
		idx = (idx - 1 + items.size()) % items.size()
		Sfx.play("ui_move", -12.0)
		_render()
	elif Input.is_action_just_pressed("down"):
		idx = (idx + 1) % items.size()
		Sfx.play("ui_move", -12.0)
		_render()
	elif Input.is_action_just_pressed("act"):
		Sfx.play("ui_ok", -6.0)
		match items[idx][1]:
			"new":
				ready_input = false
				Sfx.play("bell_deep", -6.0)
				Sfx.stop_all_loops(1.5)
				Game.new_game()
				await get_tree().create_timer(1.2).timeout
				Game.start_world()
			"continue":
				ready_input = false
				Sfx.stop_all_loops(1.0)
				Game.load_checkpoint()
				Game.start_world()
			"endings":
				ending_view = true
				for c in menu.get_children():
					c.queue_free()
				for id in Game.ENDINGS:
					var l := Label.new()
					var e: Dictionary = Game.ENDINGS[id]
					l.text = ("◆ " + e.name + "　" + e.desc) if Game.endings_seen.has(id) else "◇ ？？？"
					l.add_theme_color_override("font_color", Color("c8c2b4") if Game.endings_seen.has(id) else Color("5e584e"))
					menu.add_child(l)
				menu.position.x = 60
				info_lbl.text = "E 返回"
			"quit":
				get_tree().quit()
	if not ending_view:
		menu.position.x = 168
