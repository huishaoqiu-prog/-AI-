extends Node2D
## "那个东西"：穿奶奶寿衣的影子。看得见你，怕光。

var world: Node
var state := "idle"   # idle / chase / held / burn
var path := PackedVector2Array()
var speed := 50.0
var sprite: Sprite2D
var _anim := 0.0
var _repath := 0.0
var _whisper := 3.0
var held_by_sister := false

func _ready() -> void:
	sprite = Sprite2D.new()
	sprite.texture = Art.tex("shadow_0")
	sprite.centered = false
	sprite.offset = Vector2(-8, -32)
	add_child(sprite)
	visible = false

func activate() -> void:
	state = "chase"
	visible = true

func _physics_process(delta: float) -> void:
	_anim += delta * 3.0
	sprite.texture = Art.tex("shadow_%d" % (int(_anim) % 2))
	if state == "idle" or state == "burn" or Game.frozen > 0:
		return
	var p: PlayerChar = world.player
	var dp := global_position.distance_to(p.global_position)
	speed = 47.0
	# 在灯光里会慢下来
	var to_me := global_position - p.global_position
	if dp < p.light_radius() * 0.9 and to_me.normalized().dot(p.facing) > 0.3 and Game.lamp > 0.0:
		speed = 27.0
		sprite.modulate = Color(1.4, 1.2, 1.2)
	else:
		sprite.modulate = Color.WHITE
	if held_by_sister:
		speed *= 0.45
	_repath -= delta
	if _repath <= 0.0:
		_repath = 0.3
		if p.is_hidden and dp > 70.0:
			path = world.find_path(global_position, world.hall_center())
		else:
			path = world.find_path(global_position, p.global_position)
	_whisper -= delta
	if _whisper <= 0.0:
		_whisper = randf_range(3.0, 6.0)
		Sfx.play_at("whisper", global_position, -4.0, randf_range(0.7, 0.9))
	if not path.is_empty():
		var tgt := path[0]
		world.girl_touch_door(tgt)
		var d := global_position.distance_to(tgt)
		var step := speed * delta
		if d <= step:
			global_position = tgt
			path.remove_at(0)
		else:
			global_position += (tgt - global_position) / d * step
	sprite.position.x = randf_range(-0.5, 0.5)
	if dp < 11.0 and (not p.is_hidden or dp < 6.0):
		world.player_caught("shadow")
