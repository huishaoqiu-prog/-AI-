# 头七

> 头七夜，独自守灵。长明灯不能灭，规矩不能破——可这些规矩，真的都是奶奶写的吗？

一款中式民俗恐怖解谜游戏。**策划、剧本、程序、像素美术、音效、音乐全部由 AI（Claude）完成**，所有美术与声音都由代码实时生成，项目里没有一张外部图片、一个音频文件。

![标题](docs/screenshots/title.png)

## 简介

二〇〇三年，腊月。槐荫村。

奶奶走了七天。按村里的老规矩，头七这一夜，要留一个孝孙守灵。
三叔把奶奶生前写下的规矩交到林默手里，锁上大门，走了。

「长明灯不能灭。」
「夜里有人叫你的名字，不要应。」
「子时以后，不要照镜子。」

奶奶是村里最后一个扎纸匠。灵堂里摆着她的棺材，扎纸铺里站满了没画眼睛的纸人。
西厢的门上贴着一道封了二十年的黄符。
而院子里，有什么东西，正踩着纸片沙沙作响。

它看不见你，但它听得见。

## 截图

| | |
|---|---|
| ![灵堂](docs/screenshots/c0_02_hall.png) | ![扎纸铺](docs/screenshots/c1_02_shop.png) |
| ![躲藏](docs/screenshots/c4_01_hiding.png) | ![槐树下](docs/screenshots/c5_02_sister.png) |

## 特色

- 中式民俗恐怖：头七、守灵、纸扎、叫魂、点睛
- 规则怪谈 + 推理：从日记和遗物里拼出真相
- 听声潜行：慢走、潜行、躲藏，别被它听见
- 六个时辰章节，三个结局，初次游玩约 25–40 分钟
- 实时 2D 光影与阴影、胶片颗粒、恐惧值驱动的画面效果

## 运行

1. 安装 [Godot 4.7](https://godotengine.org/)（标准版即可，不需要 .NET 版）
2. 用 Godot 打开本目录下的 `project.godot`，按 F5 运行

或者命令行：

```bash
godot --path .
```

建议佩戴耳机，按 F11 全屏。

## 操作

| 按键 | 作用 |
|---|---|
| WASD / 方向键 | 移动 |
| Shift | 跑（很吵） |
| Ctrl / C | 潜行（几乎无声） |
| E / 空格 | 调查、确认 |
| Q | 给油灯添油 |
| R | 查看规矩 |
| Tab | 笔记 |
| Esc | 暂停 |

卡关了可以看 [攻略.md](攻略.md)（有剧透）。设计文档见 [策划.md](策划.md)。

## 项目结构

```
scripts/
  art.gd      全部像素美术（逐像素字符画 + 程序化绘制）
  sfx.gd      全部音效与音乐（运行时合成）
  world.gd    地图、碰撞、光照、寻路、系统循环
  story.gd    剧情、事件、所有文本
  player.gd / girl.gd / shadow.gd   玩家与两个敌人
  ui.gd       界面
shaders/post.gdshader   后处理
tools/autotest.gd       自动通关测试机器人
```

自动测试（会打开游戏窗口，自动跑完一个结局并截图到 `_shots/`）：

```bash
godot --path . -- --autotest                 # 真结局
godot --path . -- --autotest --ending=sub    # 替身结局
godot --path . -- --autotest --ending=paper  # 纸衣结局
```

## 致谢

- 字体：[Fusion Pixel Font](https://github.com/TakWolf/fusion-pixel-font)（SIL OFL 1.1，见 `fonts/OFL_fusion-pixel.txt`）
- 引擎：[Godot Engine](https://godotengine.org/)
