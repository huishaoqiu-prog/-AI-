extends SceneTree
## 生成美术预览大图：godot --headless --path . --script res://tools/art_preview.gd

func _init() -> void:
	var art = load("res://scripts/art.gd").new()
	var names := ["player_sheet", "uncle_sheet", "girl", "girl_eyes", "girl_back", "effigy", "effigy_eyes", "effigy_boy", "effigy_old",
		"shadow_0", "shadow_1", "coffin", "coffin_open", "altar", "portrait", "portrait_turned", "candle", "lamp", "handlamp", "flame0",
		"wreath", "banner", "money", "bed", "bed_small", "wardrobe", "table", "chair", "desk", "dresser", "dresser_open", "stove", "vat",
		"oilvat", "firewood", "shelf", "well", "tree", "horse", "stand", "tablets", "musicbox", "lantern", "lantern_big", "door_h",
		"door_h_open", "door_v", "gate", "backgate", "backgate_open", "seal", "footprint", "jar", "brush", "bowl_red", "page", "photo",
		"lock", "paper_pile", "rack", "i_oil", "i_key", "i_page", "i_brush", "i_cinnabar", "i_photo", "i_note"]
	var sc := 3
	var W := 1400
	var sheet := Image.create(W, 900, false, Image.FORMAT_RGBA8)
	sheet.fill(Color("3a3a44"))
	var x := 4
	var y := 4
	var rowh := 0
	for n in names:
		var i: Image = art.img(n).duplicate()
		i.resize(i.get_width() * sc, i.get_height() * sc, Image.INTERPOLATE_NEAREST)
		if x + i.get_width() > W:
			x = 4
			y += rowh + 6
			rowh = 0
		sheet.blend_rect(i, Rect2i(Vector2i.ZERO, i.get_size()), Vector2i(x, y))
		x += i.get_width() + 6
		rowh = max(rowh, i.get_height())
	sheet.save_png("res://_shots/art_sheet.png")
	print("saved art sheet, height used ", y + rowh)
	quit()
